import { useEffect, useRef, useState } from 'react'

type Screen = 'home' | 'fridge' | 'add' | 'stats' | 'friends'
type FoodStatus = 'fresh' | 'soon' | 'expired'

type FoodItem = {
  name: string
  days: string
  status: FoodStatus
  tip: string
  senses: string
  icon: string
}

const foodItems: FoodItem[] = [
  {
    name: 'leftover pasta',
    days: 'expired',
    status: 'expired',
    tip: 'cool quickly and use within four days.',
    senses: 'discard if slimy or unusually sour.',
    icon: 'pasta',
  },
  {
    name: 'chicken thighs',
    days: 'today',
    status: 'soon',
    tip: 'keep sealed on the lowest shelf.',
    senses: 'fresh smells mild and feels firm.',
    icon: 'drumstick',
  },
  {
    name: 'shrimp',
    days: '1 day',
    status: 'soon',
    tip: 'keep sealed on ice in the coldest spot.',
    senses: 'fresh shrimp smell clean and feel firm.',
    icon: 'shrimp',
  },
  {
    name: 'strawberries',
    days: '1 day',
    status: 'soon',
    tip: 'keep dry and wash only before eating.',
    senses: 'fresh berries smell sweet and stay bright.',
    icon: 'strawberry',
  },
  {
    name: 'spinach',
    days: '2 days',
    status: 'soon',
    tip: 'add a dry paper towel to the bag.',
    senses: 'fresh leaves are crisp with no sour smell.',
    icon: 'spinach',
  },
  {
    name: 'salmon',
    days: '2 days',
    status: 'soon',
    tip: 'keep tightly wrapped on the lowest shelf.',
    senses: 'fresh salmon smells mild and looks glossy.',
    icon: 'fish',
  },
  {
    name: 'bananas',
    days: '3 days',
    status: 'fresh',
    tip: 'keep on the counter away from other fruit.',
    senses: 'good bananas smell sweet with firm skins.',
    icon: 'banana',
  },
  {
    name: 'avocado',
    days: '4 days',
    status: 'fresh',
    tip: 'refrigerate once it feels slightly soft.',
    senses: 'ripe avocado yields gently without mushiness.',
    icon: 'avocado',
  },
  {
    name: 'bread',
    days: '5 days',
    status: 'fresh',
    tip: 'keep sealed or freeze half the loaf.',
    senses: 'fresh bread smells warm with no visible mold.',
    icon: 'bread',
  },
  {
    name: 'oat milk',
    days: '6 days',
    status: 'fresh',
    tip: 'store in the coldest part, not the door.',
    senses: 'fresh oat milk smells neutral and pours smooth.',
    icon: 'milk-carton',
  },
  {
    name: 'broccoli',
    days: '6 days',
    status: 'fresh',
    tip: 'keep loosely wrapped in the crisper.',
    senses: 'fresh broccoli is firm with tight florets.',
    icon: 'broccoli',
  },
  {
    name: 'butter',
    days: '14 days',
    status: 'fresh',
    tip: 'keep covered away from strong-smelling foods.',
    senses: 'fresh butter smells clean and looks even.',
    icon: 'butter',
  },
]

const statusLabel: Record<FoodStatus, string> = {
  fresh: 'fresh',
  soon: 'use soon',
  expired: 'expired',
}

function Artwork({ name, className = '' }: { name: string; className?: string }) {
  if (name.startsWith('fullness-')) {
    return (
      <picture>
        <source media="(max-width: 767px)" srcSet={`/illustrations/trimmed/${name}.png`} />
        <img className={className} src={`/illustrations/${name}.png`} alt="" aria-hidden="true" />
      </picture>
    )
  }

  const source = name.startsWith('fullness-')
    ? `/illustrations/${name}.png`
    : `/illustrations/trimmed/${name}.png`

  return (
    <img
      className={className}
      src={source}
      alt=""
      aria-hidden="true"
      onError={(event) => {
        event.currentTarget.style.visibility = 'hidden'
      }}
    />
  )
}

function Leekly({
  scene = false,
  variant,
  className = '',
}: {
  scene?: boolean
  variant?: 'point' | 'photo'
  className?: string
}) {
  const fileName = variant === 'point' ? 'leekly-point' : variant === 'photo' ? 'photoleek' : scene ? 'leekly-fridge' : 'leekly'

  return (
    <img
      className={className}
      src={`/illustrations/mascot/${fileName}.png`}
      alt=""
      aria-hidden="true"
    />
  )
}

function EmptyState({ message }: { message: string }) {
  return (
    <div className="empty-state">
      <Leekly scene className="empty-state-art" />
      <p>{message}</p>
    </div>
  )
}

function Header({
  screen,
  onNavigate,
}: {
  screen: Screen
  onNavigate: (screen: Screen) => void
}) {
  const cameraInputRef = useRef<HTMLInputElement>(null)
  const pageTitle: Record<Screen, string> = {
    home: 'today',
    fridge: 'my fridge',
    add: 'scan',
    stats: 'stats',
    friends: 'friends',
  }

  return (
    <header className="topbar">
      <button className="brand" onClick={() => onNavigate('fridge')} aria-label="Freshy fridge">
        <img
          className="logo-mark"
          src="/brand/fridge-logo.png"
          alt=""
          aria-hidden="true"
        />
        <span>freshy</span>
      </button>
      <span className="mobile-page-title">{pageTitle[screen]}</span>
      <nav aria-label="Primary navigation">
        <button
          className={`nav-link nav-fridge ${screen === 'fridge' ? 'active' : ''}`}
          onClick={() => onNavigate('fridge')}
        >
          fridge
        </button>
        <button
          className={`nav-link nav-scan ${screen === 'add' ? 'active' : ''}`}
          onClick={() => onNavigate('add')}
        >
          <span className="desktop-label">scan receipt</span>
          <span className="mobile-label">scan</span>
        </button>
        <button
          className={`nav-link nav-stats ${screen === 'stats' ? 'active' : ''}`}
          onClick={() => onNavigate('stats')}
        >
          stats
        </button>
        <span className="nav-camera-spacer" aria-hidden="true" />
        <button
          className={`nav-link nav-friends ${screen === 'friends' ? 'active' : ''}`}
          onClick={() => onNavigate('friends')}
        >
          friends
        </button>
        <button
          className="camera-tab"
          aria-label="Scan a receipt"
          onClick={() => {
            onNavigate('add')
            cameraInputRef.current?.click()
          }}
        >
          <svg viewBox="0 0 32 26" aria-hidden="true">
            <path d="M3 7.5h6l2.2-3h9.4l2.3 3H29v16H3z" />
            <path d="M11 15.4c0-3 2.2-5.3 5.1-5.3s5.1 2.3 5.1 5.3-2.2 5.2-5.1 5.2-5.1-2.2-5.1-5.2z" />
          </svg>
        </button>
        <button
          className={`nav-link nav-me ${screen === 'home' ? 'active' : ''}`}
          onClick={() => onNavigate('home')}
        >
          me
        </button>
        <input
          ref={cameraInputRef}
          className="camera-tab-input"
          type="file"
          accept="image/*"
          capture="environment"
          onChange={(event) => {
            const file = event.target.files?.[0]
            if (file) window.dispatchEvent(new CustomEvent('freshy-camera-file', { detail: file }))
            event.currentTarget.value = ''
          }}
        />
      </nav>
    </header>
  )
}

function HomeScreen({ onNavigate }: { onNavigate: (screen: Screen) => void }) {
  const [checked, setChecked] = useState<number[]>([])
  const tasks = [
    ['cook chicken thighs', 'try with spinach tonight', 'drumstick'],
    ['snack on strawberries', 'before tomorrow morning', 'strawberry'],
    ['use up spinach', 'toss into dinner', 'spinach'],
  ]

  const toggle = (index: number) => {
    setChecked((current) =>
      current.includes(index) ? current.filter((item) => item !== index) : [...current, index],
    )
  }

  return (
    <main className="home-screen">
      <section className="home-intro">
        <div>
          <p className="eyebrow">monday, october 21</p>
          <h1>use soon.</h1>
          <p className="hero-subtitle">three small things to save today.</p>
        </div>
        <Leekly scene className="home-mascot" />
        <button className="add-button" onClick={() => onNavigate('add')}>
          <span>+</span> add an item
        </button>
      </section>

      <section className="daily-list" aria-label="Use soon list">
        {tasks.map(([title, note, icon], index) => {
          const isChecked = checked.includes(index)
          return (
            <label className={`daily-task ${isChecked ? 'is-checked' : ''}`} key={title}>
              <input type="checkbox" checked={isChecked} onChange={() => toggle(index)} />
              <span className="large-check" aria-hidden="true">
                {isChecked ? '✓' : ''}
              </span>
              <span className="task-number">0{index + 1}</span>
              <Artwork name={icon} className="task-icon" />
              <span className="task-copy">
                <strong>{title}</strong>
                <small>{note}</small>
              </span>
            </label>
          )
        })}
      </section>

      <button className="quiet-link" onClick={() => onNavigate('fridge')}>
        everything in my fridge <span>→</span>
      </button>
    </main>
  )
}

function FoodCard({
  item,
  expanded,
  onExpand,
  onReviewExpired,
}: {
  item: FoodItem
  expanded: boolean
  onExpand: () => void
  onReviewExpired: () => void
}) {
  return (
    <article
      className={`food-card food-card--${item.status} ${expanded ? 'is-expanded' : ''}`}
      onMouseEnter={() => {
        if (window.matchMedia('(min-width: 768px)').matches) onExpand()
      }}
    >
      <button className="card-summary" onClick={onExpand} aria-expanded={expanded}>
        <Artwork name={item.icon} className="food-icon" />
        <span className="card-info">
          <span className="card-title">{item.name}</span>
          <span className="card-meta">
            <span className="status-pill">{statusLabel[item.status]}</span>
            <span className="days-left">{item.days}</span>
          </span>
        </span>
        <span className="expand-mark">{expanded ? '−' : '+'}</span>
      </button>
      <div className="card-details">
        <div className="illustration-slot">
          <Artwork name={item.icon} className="expanded-food-icon" />
        </div>
        <div className="detail-line">
          <span>store</span>
          <p>{item.tip}</p>
        </div>
        <div className="detail-line">
          <span>check</span>
          <p>{item.senses}</p>
        </div>
        <button
          className="used-button"
          onClick={item.status === 'expired' ? onReviewExpired : undefined}
        >
          {item.status === 'expired' ? 'review expired item' : 'mark as used'}
        </button>
      </div>
    </article>
  )
}

function FridgeScreen({ onReviewExpired }: { onReviewExpired: () => void }) {
  const [expanded, setExpanded] = useState<string | null>(null)
  const [showAll, setShowAll] = useState(false)
  const stages = {
    10: {
      label: 'nearly empty.',
      stocked: 'fruit, grains',
      empty: 'vegetables, protein, dairy, frozen foods',
    },
    40: {
      label: 'getting low.',
      stocked: 'fruit, protein, grains',
      empty: 'vegetables, dairy, frozen foods',
    },
    70: {
      label: 'well stocked.',
      stocked: 'vegetables, fruit, protein, dairy, grains',
      empty: 'frozen foods',
    },
    100: {
      label: 'fully stocked.',
      stocked: 'vegetables, fruit, protein, dairy, grains',
      empty: 'frozen foods',
    },
  } as const
  const [fullness, setFullness] = useState<keyof typeof stages>(70)
  const [showGroups, setShowGroups] = useState(false)
  const visibleItems = showAll ? foodItems : foodItems.slice(0, 4)

  return (
    <main className="fridge-screen">
      <section className="page-heading">
        <div
          className="fullness-preview"
          onMouseEnter={() => setShowGroups(true)}
          onMouseLeave={() => setShowGroups(false)}
        >
          <button
            type="button"
            className="fullness-art"
            aria-label={`Show food groups for ${fullness}% stocked`}
            aria-expanded={showGroups}
            onClick={() => setShowGroups((value) => !value)}
          >
            {([10, 40, 70, 100] as const).map((stage) => (
              <img
                key={stage}
                className={`fullness-stage ${fullness === stage ? 'is-visible' : ''}`}
                src={`/illustrations/fullness/stage-${stage}.png`}
                alt=""
                aria-hidden="true"
              />
            ))}
          </button>
          {showGroups && (
            <div className="stock-tooltip">
              <p><strong>stocked</strong> {stages[fullness].stocked}</p>
              <p><strong>empty</strong> {stages[fullness].empty}</p>
            </div>
          )}
        </div>
        <div className="fridge-title">
          <p className="eyebrow">sorted by urgency</p>
          <h1>everything in my fridge.</h1>
          <p className="stock-label">{stages[fullness].label}</p>
          <div className="stage-toggle" aria-label="Prototype fullness preview">
            {([10, 40, 70, 100] as const).map((stage) => (
              <button
                type="button"
                key={stage}
                className={fullness === stage ? 'active' : ''}
                aria-pressed={fullness === stage}
                onClick={() => setFullness(stage)}
              >
                {stage}
              </button>
            ))}
          </div>
        </div>
        <p className="item-count">{String(foodItems.length).padStart(2, '0')} items</p>
      </section>
      <div className="fridge-list-stage">
        <div className="food-list">
          {visibleItems.map((item) => (
            <FoodCard
              key={item.name}
              item={item}
              expanded={expanded === item.name}
              onExpand={() => setExpanded(expanded === item.name ? null : item.name)}
              onReviewExpired={onReviewExpired}
            />
          ))}
        </div>
        <Leekly variant="point" className="leek-point fridge-leek-point" />
      </div>
      {foodItems.length === 0 && <EmptyState message="your fridge is ready for something fresh." />}
      {!showAll && (
        <button className="quiet-link centered" onClick={() => setShowAll(true)}>
          see all {foodItems.length} <span>→</span>
        </button>
      )}
    </main>
  )
}

function AddScreen({ onDone }: { onDone: () => void }) {
  const [step, setStep] = useState(1)
  const [receipt, setReceipt] = useState<string | null>(null)
  const [reading, setReading] = useState(false)
  const parsedItems = ['eggs', 'bananas', 'cilantro', 'mystery greens']

  const handleReceipt = (file?: File) => {
    if (file) {
      setReceipt(URL.createObjectURL(file))
      setReading(true)
      window.setTimeout(() => {
        setReading(false)
        setStep(2)
      }, 850)
    }
  }

  useEffect(() => {
    const receiveCameraFile = (event: Event) => {
      handleReceipt((event as CustomEvent<File>).detail)
    }
    window.addEventListener('freshy-camera-file', receiveCameraFile)
    return () => window.removeEventListener('freshy-camera-file', receiveCameraFile)
  }, [])

  return (
    <main className="add-screen">
      <div className="step-count">0{step} / 03</div>
      {reading && (
        <section className="receipt-loading">
          <Leekly variant="photo" className="loading-photoleek" />
          <p>reading your receipt...</p>
        </section>
      )}
      {!reading && step === 1 && (
        <section className="step-panel">
          <p className="eyebrow">scan receipt</p>
          <h1>show us your receipt.</h1>
          <div className="receipt-options">
            <label className="receipt-choice">
              <input
                type="file"
                accept="image/*"
                capture="environment"
                onChange={(event) => handleReceipt(event.target.files?.[0])}
              />
              <Leekly variant="photo" className="scan-mascot" />
              <span className="camera-choice-copy">
                <svg viewBox="0 0 32 32" aria-hidden="true">
                  <path d="M4 10h6l2-3h8l2 3h6v16H4z" />
                  <circle cx="16" cy="18" r="5" />
                </svg>
                <strong>take a photo</strong>
                <small>open your camera</small>
              </span>
            </label>
            <label className="receipt-choice">
              <input
                type="file"
                accept="image/*,.pdf"
                onChange={(event) => handleReceipt(event.target.files?.[0])}
              />
              <span className="receipt-icon">↑</span>
              <svg className="upload-file-icon" viewBox="0 0 24 24" aria-hidden="true">
                <path d="M5 2h9l5 5v15H5zM14 2v5h5" />
              </svg>
              <strong>upload from files</strong>
              <small>photo or pdf</small>
            </label>
          </div>
        </section>
      )}
      {!reading && step === 2 && (
        <section className="step-panel receipt-step">
          <p className="eyebrow">receipt captured</p>
          <h1>take a quick look.</h1>
          <div className="receipt-preview">
            {receipt && <img src={receipt} alt="Captured receipt preview" />}
            <Leekly variant="photo" className="preview-photoleek" />
            <div>
              <button
                className="outline-button"
                onClick={() => {
                  setReceipt(null)
                  setStep(1)
                }}
              >
                retake
              </button>
              <button className="add-button" onClick={() => setStep(3)}>
                continue
              </button>
            </div>
          </div>
        </section>
      )}
      {!reading && step === 3 && (
        <section className="step-panel">
          <p className="eyebrow">looks like you bought</p>
          <h1>check the list.</h1>
          <div className="parsed-list">
            {parsedItems.map((item, index) => (
              <div className="parsed-row" key={item}>
                <span>{item}</span>
                <label>
                  good for
                  <input defaultValue={index === 0 ? '14 days' : index === 1 ? '5 days' : '7 days'} />
                </label>
              </div>
            ))}
          </div>
          <div className="tip-card">
            <span>unknown food tip</span>
            <strong>mystery greens</strong>
            <p>try storing the stems in a jar of water.</p>
          </div>
          <button className="add-button mobile-pinned-action" onClick={onDone}>
            add to fridge
          </button>
        </section>
      )}
    </main>
  )
}

function StatCircle({
  value,
  label,
  tooltip,
  positive = false,
}: {
  value: string
  label: string
  tooltip: string
  positive?: boolean
}) {
  const [drawKey, setDrawKey] = useState(0)
  const [showTooltip, setShowTooltip] = useState(false)

  const redraw = () => {
    setDrawKey((key) => key + 1)
    setShowTooltip(true)
  }

  return (
    <button
      className={`stat-circle ${positive ? 'positive' : ''}`}
      onMouseEnter={redraw}
      onMouseLeave={() => setShowTooltip(false)}
      onClick={redraw}
    >
      <span className="circle-art">
        <svg viewBox="0 0 300 300" aria-hidden="true">
          <path
            key={drawKey}
            className="circle-stroke"
            d="M153 12C224 9 283 65 288 137C294 211 239 278 165 287C91 296 24 247 13 174C2 101 48 33 119 16C133 12 145 11 158 13C166 14 171 16 177 20"
          />
        </svg>
        <strong>{value}</strong>
      </span>
      <span className="stat-label">
        {label.split(' ').map((word, index) => (
          <span key={word}>
            {index > 0 && <br className="mobile-stat-break" />}
            {word}
            {index === 0 && <span className="desktop-stat-space"> </span>}
          </span>
        ))}
      </span>
      {showTooltip && <span className="stat-tooltip">{tooltip}</span>}
    </button>
  )
}

function StatsScreen() {
  const [showValues, setShowValues] = useState(false)
  const weeks = [
    ['this week', '9', '0.4'],
    ['last week', '11', '0.8'],
    ['oct 7–13', '8', '1.2'],
    ['sep 30–oct 6', '10', '1.8'],
  ]

  useEffect(() => {
    const timer = window.setTimeout(() => setShowValues(true), 250)
    return () => window.clearTimeout(timer)
  }, [])

  return (
    <main className="stats-page">
      <section className="compact-heading stats-heading">
        <h1>your numbers.</h1>
        <Leekly className="stats-mascot" />
      </section>
      <section className="stats-screen">
        <StatCircle
          value={showValues ? '12' : '00'}
          label="items rescued"
          tooltip="foods you finished before they expired"
          positive
        />
        <StatCircle
          value={showValues ? '3.5' : '00'}
          label="lbs wasted"
          tooltip="estimated food discarded this month"
        />
        <StatCircle
          value={showValues ? '7' : '00'}
          label="day streak"
          tooltip="days in a row with no expired food"
          positive
        />
      </section>
      <div className="thin-list week-list">
        <div className="thin-row list-labels">
          <span>week</span>
          <span>
            <span className="desktop-table-label">items rescued</span>
            <span className="mobile-table-label">rescued</span>
          </span>
          <span>
            <span className="desktop-table-label">lbs wasted</span>
            <span className="mobile-table-label">lbs</span>
          </span>
        </div>
        {weeks.map(([week, rescued, wasted]) => (
          <button className="thin-row" key={week}>
            <strong>{week}</strong>
            <span>{rescued}</span>
            <span>{wasted}<span className="desktop-unit"> lbs</span></span>
          </button>
        ))}
      </div>
    </main>
  )
}

function FriendsScreen() {
  const friends = [
    ['01', 'maya', '0.2', '18'],
    ['02', 'you', '0.4', '12'],
    ['03', 'theo', '0.7', '9'],
    ['04', 'dev', '1.1', '6'],
    ['05', 'nina', '1.4', '4'],
  ]

  return (
    <main className="friends-page">
      <section className="compact-heading heading-with-action">
        <div>
          <p className="eyebrow">this week</p>
          <h1>you + friends.</h1>
        </div>
        <button className="outline-button">+ add a friend</button>
      </section>
      <div className="friends-stage">
        <div className="thin-list friends-list">
          <div className="thin-row list-labels friend-columns">
            <span>rank</span>
            <span>name</span>
            <span>
              <span className="desktop-table-label">lbs wasted</span>
              <span className="mobile-table-label">lbs</span>
            </span>
            <span>streak</span>
            <span>drawing</span>
          </div>
          {friends.map(([rank, name, wasted, streak]) => (
            <button className={`thin-row friend-columns ${name === 'you' ? 'is-you' : ''}`} key={name}>
              <span>{rank}</span>
              <strong>{name}</strong>
              <span>{wasted}<span className="desktop-unit"> lbs</span></span>
              <span>{streak}<span className="desktop-unit"> days</span></span>
              <span className="friend-drawing" aria-label="Future custom drawing" />
            </button>
          ))}
        </div>
        <Leekly variant="point" className="leek-point friends-leek-point" />
      </div>
    </main>
  )
}

function SwipeTakeover({ onClose }: { onClose: () => void }) {
  const [result, setResult] = useState<'used' | 'wasted' | null>(null)
  const touchStartX = useRef<number | null>(null)

  const choose = (choice: 'used' | 'wasted') => {
    setResult(choice)
    window.setTimeout(onClose, 650)
  }

  return (
    <div className={`swipe-takeover ${result ? `result-${result}` : ''}`} role="dialog" aria-modal>
      <p className="eyebrow">quick check-in</p>
      <span className="swipe-edge swipe-edge--left">wasted</span>
      <span className="swipe-edge swipe-edge--right">used</span>
      <div
        className={`swipe-card ${result ? `swipe-${result}` : ''}`}
        onTouchStart={(event) => {
          touchStartX.current = event.touches[0]?.clientX ?? null
        }}
        onTouchEnd={(event) => {
          if (touchStartX.current === null) return
          const distance = (event.changedTouches[0]?.clientX ?? touchStartX.current) - touchStartX.current
          if (distance > 55) choose('used')
          if (distance < -55) choose('wasted')
          touchStartX.current = null
        }}
      >
        <span className="status-pill">expired</span>
        <p>leftover pasta</p>
        <Artwork name="bread" className="swipe-food-art" />
        <Leekly className="swipe-mascot" />
        <h1>{result === 'used' ? 'nice save.' : result === 'wasted' ? 'noted.' : 'did you use it?'}</h1>
        {!result && (
          <div className="swipe-actions">
            <button onClick={() => choose('wasted')}>← wasted</button>
            <button className="used-choice" onClick={() => choose('used')}>
              used →
            </button>
          </div>
        )}
      </div>
      {!result && <small>swipe left or right</small>}
    </div>
  )
}

export default function App() {
  const [screen, setScreen] = useState<Screen>('home')
  const [showSwipe, setShowSwipe] = useState(false)

  return (
    <div className="app-shell">
      <Header screen={screen} onNavigate={setScreen} />
      {screen === 'home' && <HomeScreen onNavigate={setScreen} />}
      {screen === 'fridge' && <FridgeScreen onReviewExpired={() => setShowSwipe(true)} />}
      {screen === 'add' && <AddScreen onDone={() => setScreen('fridge')} />}
      {screen === 'stats' && <StatsScreen />}
      {screen === 'friends' && <FriendsScreen />}
      {showSwipe && <SwipeTakeover onClose={() => setShowSwipe(false)} />}
      <footer>
        <p>spoil less eat fresh!</p>
        <span>freshy © 2025</span>
      </footer>
    </div>
  )
}
