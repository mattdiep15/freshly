# Navigation, Community Merge, and Grocery Page Plan

## Goal

Restructure the app into four user-facing destinations—Fridge, Recipes, Grocery, and Community—while merging the existing Stats and Friends experiences into Community and adding a stateful grocery list. Preserve the current black/white visual language, `#258007` green, lowercase button typography with `0.04em` letter spacing, fixed shared tags, original hand-drawn assets, mobile camera clearance, and invisible mobile scrollbars.

## Confirmed Product Decisions

- New primary navigation order: `fridge`, `recipes`, `grocery`, `community`.
- The raised mobile camera remains centered over the empty third slot and continues opening the existing Add/scan flow.
- Grocery is not a scanner; desktop scanning remains accessible from Fridge’s green `+ add item` button.
- Community defaults to `my numbers`.
- Community’s selected subview is saved to `sessionStorage`, so it survives route changes and reloads in the same tab, then resets with the browser session.
- Grocery hint priority follows the brief’s order:
  1. previously wasted
  2. already in fridge
  3. pairs with a soon-to-expire food
- Grocery duplicates are not created:
  - adding an existing active item moves it to the top
  - adding a completed item restores it to active at the top
- Grocery empty state: standalone Leekly at about 120px with `nothing on the list.`
- Grocery list state remains in `App` so it survives navigation during the current app session.

## Repository Facts

- The app is a single React/Vite client in `src/App.tsx`; navigation is local `Screen` state, not React Router.
- Current screen values are `fridge`, `recipes`, `add`, `stats`, and `friends`.
- Stats and Friends are standalone components with their own page headings.
- Stats currently receives `rescued` and `wasted`; App initializes them to 12 and 3.5 but mutates them after swipe decisions.
- Friends currently owns incoming-request visibility, pending outgoing friends, add-friend modal state, and leaderboard state.
- Header cannot currently see pending friend requests because that state is local to `FriendsScreen`.
- The current shared `FoodIcon` already resolves specific drawings first and deterministic grocery bag fallbacks second.
- Grocery bag 2 already exists at `/illustrations/trimmed/bag-2.png`.
- `knownFoods` and the existing manual-entry autocomplete supply names, icons, and stable grocery-bag fallbacks.
- Mobile uses one `.mobile-page-scroll` wrapper plus `.mobile-page-end-spacer`; Stats currently has a special no-scroll exception that must be removed when Stats moves into scrollable Community.
- No test framework is configured. Verification uses `pnpm build` plus responsive preview checks.

## Implementation Plan

### 1. Replace the public screen model and add compatibility navigation

Change the user-facing screen model to:

```ts
type Screen = 'fridge' | 'recipes' | 'grocery' | 'community' | 'add'
type CommunityView = 'numbers' | 'friends'
type LegacyDestination = 'stats' | 'friends'
```

Add an App-level navigation helper:

```ts
navigate(destination: Screen | LegacyDestination)
```

Behavior:

- `stats` maps to `community` and selects `numbers`.
- `friends` maps to `community` and selects `friends`.
- Other destinations set the requested screen.
- This is the compatibility layer for any existing internal “old links”; the app has no URL router/deep-link layer to migrate.
- Logo continues navigating to `fridge`.
- `add` remains internal and has no primary nav button.

Update the mobile title map for `grocery` and `community`; remove Stats/Friends destination titles.

### 2. Persist Community subview and expose pending-request state

Lift these states to `App`:

- `communityView`
- `incomingFriendRequestVisible`

Initialize `communityView` from `sessionStorage` key such as `freshy-community-view`, validating that the stored value is `numbers` or `friends`; otherwise default to `numbers`.

Whenever the switch changes:

- update App state
- update `sessionStorage`

The incoming Theo request starts visible, as it does now. Accepting or ignoring it sets `incomingFriendRequestVisible` to false. Header receives:

```ts
hasPendingFriendRequest={incomingFriendRequestVisible}
```

The Community nav dot therefore disappears immediately after either response.

Keep outgoing friend-request/add-friend state stable when switching Community views by mounting both Community panels continuously and toggling active/inactive classes rather than unmounting `FriendsView`.

### 3. Rebuild Header navigation

Markup order:

1. Fridge
2. Recipes
3. camera spacer
4. Grocery
5. Community
6. raised camera button/input

Desktop:

- Render the four text links only.
- 16px labels, 40px gaps.
- Active destination gets the existing 2px underline.
- No border, box, or persistent focus outline on click.
- Use:
  - `:focus:not(:focus-visible) { outline: none; box-shadow: none; }`
  - `:focus-visible` keyboard-only outline with a clear offset.
- Hide camera spacer/button/input visually on desktop.

Mobile:

- Exact five-column equal grid:
  - Fridge: column 1
  - Recipes: column 2
  - empty spacer: column 3
  - Grocery: column 4
  - Community: column 5
- Labels are 13px, centered, lowercase, and active labels receive a 2px underline.
- Keep the camera at `left: 50%`, with its current raised positioning and safe-area behavior.

Community pending dot:

- Add an explicit decorative span in the Community button.
- 8px circle, `#258007`.
- Position beside/above the label without changing grid width.
- Hide when no incoming request exists.
- Include a visually hidden “pending request” label or an accessible nav label update so the state is not color-only.

Remove all rendered Stats/Friends nav buttons and obsolete final nav selectors that can conflict with the new grid.

### 4. Split existing Stats and Friends into reusable Community views

Refactor:

- `StatsScreen` → `NumbersView`
- `FriendsScreen` → `FriendsView`
- Add `CommunityScreen`

#### Community shell

Render:

- page heading `community.`
  - 56px desktop
  - 40px mobile
- two-option switch immediately below:
  - `my numbers`
  - `friends`

Switch:

- Mobile: full width, two equal 48px buttons, shared 1px black outline.
- Desktop: preserve the same selected/unselected visual language at a suitable content width.
- Selected option: solid black, white text.
- Unselected: white, black text.
- Buttons retain lowercase `0.04em` text style.
- On mobile, switch uses `position: sticky; top: 0` within `.mobile-page-scroll`, with white background and sufficient z-index.
- The main Community heading scrolls normally; the switch sticks after reaching the top.

Panels:

- Keep both mounted to preserve Friend state and random Stats mascot.
- Active panel receives `.is-active`.
- Apply a 150ms opacity animation/cross-fade on activation.
- Inactive panel uses `display: none` after its inactive state; the practical transition is a 150ms fade-in of the newly selected mounted panel, avoiding duplicate layout height and duplicate accessibility content.
- Add `aria-hidden` to inactive panel and connect switch buttons with `aria-controls`/`aria-selected`.

Community page is the single mobile scroller. Remove the old mobile Stats no-scroll exception.

### 5. Numbers view content

Retain:

- random `cool` or `number-one` mascot, selected once per mounted Community session
- three hand-drawn SVG circles
- count-up and draw animations
- tooltips/replay behavior
- four-week table

Remove the standalone Stats page heading.

Add a 20px section label `your numbers.` above the Stats content.

Use fixed demo values in Community regardless of swipe actions:

- 12 items rescued
- 3.5 lbs wasted
- 7 day streak

This intentionally decouples the Community demo display from App’s mutable swipe counters, matching “same demo values on every screen.” Existing decision tracking may remain internally for toasts/flow, but the merged view receives constants.

### 6. Friends view content

Retain:

- friends Leek illustration
- `this week` eyebrow
- `+ add a friend`
- incoming Theo request row
- add-friend modal and search/copy/share behavior
- leaderboard
- pending outgoing friend rows

Remove the standalone Friends page heading.

Add a 20px section label `you + friends.` above the content. Arrange the illustration, eyebrow, section label, and add button with the existing responsive composition, but do not render another page-sized heading.

Incoming row:

- Accept and Ignore call the App-owned visibility setter.
- Either action removes the row and Community nav dot.

Leaderboard header:

- Keep `streak` in its own column.
- Replace the final literal `drawing` header with an empty `<span aria-hidden="true" />`.
- Preserve the drawing column width and row placeholders.

Mobile clearance:

- Community/Friends content gets page bottom padding equal to the bottom bar/camera zone plus at least 40px.
- This prevents the first/last leaderboard content from sitting under the raised camera.

### 7. Add Grocery data model and App-level state

Add:

```ts
type GroceryItem = {
  id: string
  name: string
  completed: boolean
}
```

Seed in the specified order:

1. eggs
2. strawberries
3. oat milk
4. salmon
5. rice
6. garlic
7. soy sauce

All start active.

Store `groceryItems` in `App` and pass state/actions to `GroceryScreen`.

Add `wastedFoodNames` to App:

- initialize with `strawberries` to demonstrate the personal waste hint
- when swipe review commits a `wasted` decision, add that normalized food name
- retain unique normalized names

Grocery actions:

- Add:
  - trim outer whitespace
  - collapse repeated internal whitespace
  - normalize duplicate comparison case-insensitively
  - reject empty input
  - active duplicate: move existing item to top
  - completed duplicate: mark active and move to top
  - new item: create with `crypto.randomUUID()`, insert at top
- Toggle complete:
  - update `completed`
  - active list and completed section derive from state
- Clear completed:
  - remove all completed items

### 8. Build Grocery header and add/autocomplete field

`GroceryScreen` receives:

- grocery items/actions
- live fridge `items`
- `wastedFoodNames`

Header:

- eyebrow `next trip`, 14px, wide-spaced
- `grocery list.`
  - 56px desktop
  - 40px mobile
- left aligned
- bag 2 uses the existing exact uploaded asset through `Artwork name="bag-2"`:
  - about 200px desktop
  - about 100px mobile
- two-column/flex heading composition with `min-width: 0`; artwork never overlaps text

Add form:

- semantic `<form>` so Enter and Add share one submit path
- input:
  - 52px desktop
  - 48px mobile
  - 2px black outline
  - placeholder `add something...`
- green Add button at matching height
- lowercase, `0.04em`
- clear input and close suggestions after successful add

Autocomplete:

- Extract/reuse a shared food-suggestion-list component from the manual entry card rather than duplicating rendering.
- Inputs:
  - query
  - filtered `knownFoods`
  - active index
  - selection callback
- Preserve current hover/keyboard-active black background, white text, and inverted suggestion artwork.
- Reuse `FoodIcon`, so all specific drawings and stable bag fallback rules apply.
- Arrow Up/Down, Enter, and Escape behavior match manual entry.
- Selecting a suggestion fills the field; submitting adds it.

### 9. Grocery hint derivation

For each active grocery item, derive at most one hint.

1. Waste history:
   - if normalized name is in `wastedFoodNames`
   - text: `you wasted some last time. buy less.`

2. In fridge:
   - exact normalized-name matches in live fridge items
   - sum `quantity ?? 1`
   - text with grammar:
     - `you still have 1 in your fridge.`
     - `you still have 2 in your fridge.`
   - show outlined `in fridge` tag using the shared fixed-tag dimensions/style

3. Pairing:
   - use a small deterministic pairing map, only if the paired food currently has `status === 'soon'`
   - examples:
     - eggs → spinach
     - garlic → spinach
     - rice → salmon
     - soy sauce → salmon
     - oat milk → strawberries
   - choose the first qualifying pair
   - text: `goes well with {food}.`

If nothing qualifies, render no hint line; keep row alignment stable.

### 10. Grocery rows and completed section

Active list rows:

- 72px desktop / 64px mobile
- 1px bottom dividers
- stable horizontal layout:
  1. 44px checkbox hit area containing 28px square
  2. 48px `FoodIcon`
  3. min-width-zero copy block
  4. optional fixed tag associated with the hint
- title 20px
- hint 14px, black at 70%
- use exact food drawing or deterministic bag fallback
- no unrelated generic icons

Checking:

- checkbox fills `#258007`
- checkmark turns white
- title gets thin strikethrough
- item immediately leaves active rows and appears in completed collection

Completed:

- bottom section header:
  - `got it {count}`
  - toggle control to expand/collapse
  - underlined 14px `clear`
- collapsed by default whenever completed items first appear
- completed rows are hidden while collapsed
- expanded completed rows reuse row geometry and checked styling
- Clear removes all completed rows

Empty state:

- Show only when both active and completed arrays are empty.
- Standalone Leekly at about 120px.
- Exact text: `nothing on the list.`

### 11. Responsive spacing and mobile scrolling

Grocery mobile page bottom padding:

```css
calc(
  64px
  + max(env(safe-area-inset-bottom), 24px)
  + 52px
  + 24px
)
```

This is the bottom bar zone plus 52px camera clearance plus 24px breathing room.

Community receives equivalent camera-safe padding, with at least 40px beyond the last Friends row.

No nested full-page scrollers:

- `.mobile-page-scroll` remains the single page scroll owner.
- Grocery autocomplete may have its own bounded suggestion-list overflow.
- Community switch is sticky inside the shared scroller.
- Preserve scrollbar hiding on all mobile page surfaces.

### 12. CSS cleanup and regression protection

Add authoritative final styles for:

- `nav-grocery`
- `nav-community`
- Community dot
- Community switch/panels
- Grocery header/form/rows/completed section

Remove or neutralize obsolete final selectors for:

- `nav-stats`
- `nav-friends`
- separate Stats/Friends page navigation positions
- Stats mobile no-scroll special case

Keep unchanged:

- fridge status strips and filters
- expired inversion/background-based artwork rules
- shared fixed tag dimensions
- recipes interactions
- Add/scan flow
- raised camera geometry
- hand-drawn source assets

## Component and State Shape

Recommended structure:

```txt
App
├── Header
├── FridgeScreen
├── RecipesScreen
├── GroceryScreen
├── CommunityScreen
│   ├── NumbersView
│   └── FriendsView
└── AddScreen / overlays / toasts
```

App-owned state:

- `screen`
- `communityView`
- `incomingFriendRequestVisible`
- `items`
- `groceryItems`
- `wastedFoodNames`
- existing review/add/toast state

Community-owned state:

- random Stats mascot (one pick)

FriendsView-owned state:

- add-friend modal/search fields
- pending outgoing friends
- copied state

GroceryScreen-owned UI state:

- input query
- suggestion active index/open state
- completed-section expanded state

## Edge Cases

- Invalid Community value in `sessionStorage`: fall back to `numbers`.
- `sessionStorage` unavailable: catch access errors and keep in-memory state.
- Incoming request accepted/ignored while Community Friends is active: row and nav dot disappear together.
- Old Stats/Friends internal destination: maps to Community and correct subview.
- Grocery add with only whitespace: no-op.
- Duplicate with different capitalization/spacing: reuse normalized existing row.
- Re-adding completed item: restore and move to top.
- Unknown grocery food: stable deterministic bag through `FoodIcon`.
- Known pantry food: uses garlic/grains/honey/oil/rice specific drawing.
- Multiple grocery hints: apply fixed priority; never render two.
- Fridge quantity missing: count as one.
- No soon pair: omit pairing hint.
- No active rows but completed rows exist: show the completed section, not the global empty state.
- Clear completed resulting in zero total rows: show empty state.
- Long grocery name/hint: copy block uses `min-width: 0`; prevent horizontal overflow and allow natural truncation/wrapping within row height.
- Mobile Community/Friends last row and Grocery last row remain above camera.

## Verification

Run:

```sh
pnpm build
```

Then verify in the existing preview below and above 768px.

### Navigation

- Exact order: Fridge, Recipes, Grocery, Community.
- Desktop labels 16px with 40px gaps and 2px active underline.
- Mobile exact five-slot layout with camera centered over slot 3.
- No Stats/Friends primary tabs remain.
- Mouse click shows no nav focus box; keyboard Tab shows `:focus-visible`.
- Pending green dot appears initially and clears after Accept/Ignore.
- Legacy Stats/Friends navigation helper opens the correct Community view.

### Community

- Defaults to My Numbers on a fresh session.
- Switch persists through navigation and same-tab reload.
- Switch sticks on mobile while the whole page scrolls.
- View activation fades in over 150ms.
- Numbers shows random existing mascot, animations, 12 / 3.5 / 7, and four-week table.
- Friends keeps illustration, eyebrow, add flow, incoming row, leaderboard, and pending rows.
- Section labels are 20px; duplicate large headings are gone.
- Final drawing-column header is empty.
- Mobile Friends content clears the camera and bottom bar.

### Grocery

- Bag 2 header art is unchanged and correctly sized.
- Add button and Enter insert at the top.
- Manual-style autocomplete supports pointer and keyboard selection.
- Duplicate active/completed behavior matches the plan.
- Rows render correct specific drawings or stable bag fallback.
- Hint priority and dynamic fridge quantities are correct.
- Checkbox moves row to collapsed Got It section.
- Got It expands/collapses and Clear empties it.
- Empty state appears only when no active/completed rows remain.
- Mobile page uses the exact requested bottom clearance and has no visible scrollbar.

### Regression

- Fridge desktop `+ add item` still opens scan/manual entry.
- Mobile camera still opens capture.
- Recipes, fridge row expansion, status filters, swipe review, add-friend modal, toasts, and footers still work.
- Existing illustrations remain unchanged.
