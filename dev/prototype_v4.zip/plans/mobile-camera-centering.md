# Plan: Center the Mobile Bottom-Bar Camera Button

## Goal

Fix the mobile bottom navigation below `768px` so the raised camera button is anchored to the exact horizontal center of the bar and floats over a deliberately empty middle grid slot. Preserve the desktop navigation, current monochrome styling, camera height/raise/ring, capture behavior, and all screen content.

## Current-State Findings

- The bottom navigation is rendered in `src/App.tsx` inside `Header`.
- The mobile tab buttons are:
  - `.nav-fridge`
  - `.nav-stats`
  - `.camera-tab`
  - `.nav-friends`
  - `.nav-me`
- The legacy `.nav-scan` button remains in the DOM for desktop and is hidden on mobile.
- The camera button already uses absolute positioning with `left: 50%` and `translateX(-50%)` in the last mobile override.
- `src/index.css` contains three successive mobile navigation override blocks near the end of the file. Earlier blocks alternately position the camera as a grid item and as an absolutely positioned child. The final cascade currently wins, but the duplicated rules make the center position and slot spacing fragile.
- The camera button owns the existing device-camera behavior in `src/App.tsx`; that logic does not need to change.

## Implementation

### 1. Add an explicit empty center spacer

Update the mobile-navigation markup in `src/App.tsx`:

- Add a non-interactive, `aria-hidden` spacer element such as `.nav-camera-spacer`.
- Keep it as a sibling of the four text tabs and the camera button.
- Do not place the camera button inside the spacer.
- Keep the camera input and its existing receipt-file event flow unchanged.
- Hide the spacer on desktop.

The mobile semantic structure will be:

1. fridge tab
2. stats tab
3. empty spacer
4. friends tab
5. me tab
6. absolutely positioned camera button floating over slot 3

### 2. Establish one authoritative mobile grid

In `src/index.css`, consolidate the mobile bottom-bar rules so one final `@media (max-width: 767px)` block owns the complete bar layout:

- Fixed full-width bar at `bottom: 0`.
- `position: relative` on the bar so the camera’s absolute positioning resolves against the bar itself.
- Five equal columns using `grid-template-columns: repeat(5, minmax(0, 1fr))`.
- Explicit slot assignments:
  - fridge: column 1
  - stats: column 2
  - spacer: column 3
  - friends: column 4
  - me: column 5
- Preserve `12px` left/right bar padding.
- Preserve the existing `64px` content area and current bottom safe-area handling.
- Keep all labels centered, one-line, and vertically centered.

Remove or neutralize the earlier conflicting mobile declarations that:

- use a fixed-width `84px` center column,
- position `.camera-tab` as a relative grid item,
- or redefine camera transforms independently.

Desktop `nav` rules remain untouched.

### 3. Anchor the camera to the bar center

Define the mobile `.camera-tab` once:

- `position: absolute`
- `left: 50%`
- `transform: translateX(-50%)`
- Preserve its current `top`, width, height, black fill, white ring, icon size, and z-index.
- Preserve the active press transform by combining translation and scaling:
  - `translateX(-50%) scale(0.95)`
- Ensure the bar has `overflow: visible`.

This makes the button center independent of:

- grid-column widths,
- tab label widths,
- DOM order,
- and side padding.

### 4. Guarantee label clearance

Keep the four labels in their equal slots and verify the center spacer remains empty:

- No text or icon in column 3.
- No mobile `scan` label.
- `stats` and `friends` stay centered in columns 2 and 4.
- Preserve the current `13px` text, `0.06em` letter spacing, active underline, inactive opacity, and `44px` minimum target.
- At a `390px` viewport with `12px` bar padding, confirm the nearest label bounds remain at least `12px` from the outer white camera ring.

If the actual text bounds are closer than `12px`, reduce only the horizontal inline padding inside the neighboring tab buttons; do not move the camera off center or introduce unequal grid columns.

### 5. Preserve content clearance

Retain the existing mobile page bottom padding and pinned-action offsets unless the cleaned bar block changes their computed values.

Confirm that:

- rows and illustrations remain above the fixed bar,
- the receipt action remains above the safe area,
- and tooltip/pinned-action offsets still use the same final bar height.

## Verification

1. Run `pnpm build`.
2. In the mobile preview at `390px` width, verify:
   - the black circle’s horizontal center matches the viewport center,
   - the bar center slot is visibly empty beneath it,
   - fridge, stats, friends, and me are all fully visible,
   - stats and friends each have at least `12px` clear space from the white ring,
   - the top border remains visible on both sides of the ring,
   - the press state scales around the same center without shifting,
   - and the camera still opens the scan flow and device capture.
3. Check a wide viewport to confirm desktop navigation and scan-receipt link are unchanged.

## Files

- `src/App.tsx`
  - Add the explicit mobile center spacer only.
  - Preserve camera input and navigation behavior.
- `src/index.css`
  - Consolidate and correct mobile bottom-bar positioning rules.
  - Do not alter desktop rules, colors, icon drawing, or other screen layouts.
