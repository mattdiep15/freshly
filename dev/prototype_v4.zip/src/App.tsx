import { useEffect, useRef, useState } from 'react'

type Screen = 'home' | 'fridge' | 'add' | 'stats' | 'friends'
type FoodStatus = 'fresh' | 'soon' | 'expired'
type FridgeFilter = 'all' | FoodStatus

type FoodItem = {
  name: string
  days: string
  status: FoodStatus
  tip: string
  senses: string
  icon: string
  extended?: boolean
  deferred?: boolean
  wasteLbs?: number
}

const foodItems: FoodItem[] = [
  {
    name: 'leftover pasta',
    days: '1 day',
    status: 'expired',
    tip: 'cool quickly and use within four days.',
    senses: 'discard if slimy or unusually sour.',
    icon: 'pasta',
    wasteLbs: 0.4,
  },
  {
    name: 'chicken thighs',
    days: '2 days',
    status: 'expired',
    tip: 'keep sealed on the lowest shelf.',
    senses: 'fresh smells mild and feels firm.',
    icon: 'drumstick',
  },
  {
    name: 'shrimp',
    days: '3 days',
    status: 'expired',
    tip: 'keep sealed on ice in the coldest spot.',
    senses: 'fresh shrimp smell clean and feel firm.',
    icon: 'shrimp',
  },
  {
    name: 'strawberries',
    days: '1 day',
    status: 'soon',
    tip: 'keep dry and wash only before eating.',
    senses: 'fresh berries smell sweet and stay bright.',
    icon: 'strawberry',
  },
  {
    name: 'spinach',
    days: '2 days',
    status: 'soon',
    tip: 'add a dry paper towel to the bag.',
    senses: 'fresh leaves are crisp with no sour smell.',
    icon: 'spinach',
  },
  {
    name: 'salmon',
    days: '2 days',
    status: 'soon',
    tip: 'keep tightly wrapped on the lowest shelf.',
    senses: 'fresh salmon smells mild and looks glossy.',
    icon: 'fish',
  },
  {
    name: 'bananas',
    days: '3 days',
    status: 'fresh',
    tip: 'keep on the counter away from other fruit.',
    senses: 'good bananas smell sweet with firm skins.',
    icon: 'banana',
  },
  {
    name: 'avocado',
    days: '4 days',
    status: 'fresh',
    tip: 'refrigerate once it feels slightly soft.',
    senses: 'ripe avocado yields gently without mushiness.',
    icon: 'avocado',
  },
  {
    name: 'bread',
    days: '5 days',
    status: 'fresh',
    tip: 'keep sealed or freeze half the loaf.',
    senses: 'fresh bread smells warm with no visible mold.',
    icon: 'bread',
  },
  {
    name: 'oat milk',
    days: '6 days',
    status: 'fresh',
    tip: 'store in the coldest part, not the door.',
    senses: 'fresh oat milk smells neutral and pours smooth.',
    icon: 'milk-carton',
  },
  {
    name: 'broccoli',
    days: '6 days',
    status: 'fresh',
    tip: 'keep loosely wrapped in the crisper.',
    senses: 'fresh broccoli is firm with tight florets.',
    icon: 'broccoli',
  },
  {
    name: 'butter',
    days: '14 days',
    status: 'fresh',
    tip: 'keep covered away from strong-smelling foods.',
    senses: 'fresh butter smells clean and looks even.',
    icon: 'butter',
  },
]

const statusLabel: Record<FoodStatus, string> = {
  fresh: 'fresh',
  soon: 'use soon',
  expired: 'expired',
}

function Artwork({ name, className = '' }: { name: string; className?: string }) {
  if (name.startsWith('fullness-')) {
    return (
      <picture>
        <source media="(max-width: 767px)" srcSet={`/illustrations/trimmed/${name}.png`} />
        <img className={className} src={`/illustrations/${name}.png`} alt="" aria-hidden="true" />
      </picture>
    )
  }

  const source = name.startsWith('fullness-')
    ? `/illustrations/${name}.png`
    : `/illustrations/trimmed/${name}.png`

  return (
    <img
      className={className}
      src={source}
      alt=""
      aria-hidden="true"
      onError={(event) => {
        event.currentTarget.style.visibility = 'hidden'
      }}
    />
  )
}

function Leekly({
  scene = false,
  variant,
  className = '',
}: {
  scene?: boolean
  variant?: 'point' | 'photo'
  className?: string
}) {
  const fileName = variant === 'point' ? 'leekly-point' : variant === 'photo' ? 'photoleek' : scene ? 'leekly-fridge' : 'leekly'

  return (
    <img
      className={className}
      src={`/illustrations/mascot/${fileName}.png`}
      alt=""
      aria-hidden="true"
    />
  )
}

function EmptyState({ message }: { message: string }) {
  return (
    <div className="empty-state">
      <Leekly scene className="empty-state-art" />
      <p>{message}</p>
    </div>
  )
}

function Header({
  screen,
  onNavigate,
}: {
  screen: Screen
  onNavigate: (screen: Screen) => void
}) {
  const cameraInputRef = useRef<HTMLInputElement>(null)
  const pageTitle: Record<Screen, string> = {
    home: 'today',
    fridge: 'my fridge',
    add: 'scan',
    stats: 'stats',
    friends: 'friends',
  }

  return (
    <header className="topbar">
      <button className="brand" onClick={() => onNavigate('fridge')} aria-label="Freshy fridge">
        <img
          className="logo-mark"
          src="/brand/fridge-logo.png"
          alt=""
          aria-hidden="true"
        />
        <span>freshy</span>
      </button>
      <span className="mobile-page-title">{pageTitle[screen]}</span>
      <nav aria-label="Primary navigation">
        <button
          className={`nav-link nav-fridge ${screen === 'fridge' ? 'active' : ''}`}
          onClick={() => onNavigate('fridge')}
        >
          fridge
        </button>
        <button
          className={`nav-link nav-scan ${screen === 'add' ? 'active' : ''}`}
          onClick={() => onNavigate('add')}
        >
          <span className="desktop-label">scan receipt</span>
          <span className="mobile-label">scan</span>
        </button>
        <button
          className={`nav-link nav-stats ${screen === 'stats' ? 'active' : ''}`}
          onClick={() => onNavigate('stats')}
        >
          stats
        </button>
        <span className="nav-camera-spacer" aria-hidden="true" />
        <button
          className={`nav-link nav-friends ${screen === 'friends' ? 'active' : ''}`}
          onClick={() => onNavigate('friends')}
        >
          friends
        </button>
        <button
          className="camera-tab"
          aria-label="Scan a receipt"
          onClick={() => {
            onNavigate('add')
            cameraInputRef.current?.click()
          }}
        >
          <svg viewBox="0 0 32 26" aria-hidden="true">
            <path d="M3 7.5h6l2.2-3h9.4l2.3 3H29v16H3z" />
            <path d="M11 15.4c0-3 2.2-5.3 5.1-5.3s5.1 2.3 5.1 5.3-2.2 5.2-5.1 5.2-5.1-2.2-5.1-5.2z" />
          </svg>
        </button>
        <button
          className={`nav-link nav-me ${screen === 'home' ? 'active' : ''}`}
          onClick={() => onNavigate('home')}
        >
          me
        </button>
        <input
          ref={cameraInputRef}
          className="camera-tab-input"
          type="file"
          accept="image/*"
          capture="environment"
          onChange={(event) => {
            const file = event.target.files?.[0]
            if (file) window.dispatchEvent(new CustomEvent('freshy-camera-file', { detail: file }))
            event.currentTarget.value = ''
          }}
        />
      </nav>
    </header>
  )
}

function HomeScreen({ onNavigate }: { onNavigate: (screen: Screen) => void }) {
  const [checked, setChecked] = useState<number[]>([])
  const tasks = [
    ['cook chicken thighs', 'try with spinach tonight', 'try with spinach', 'drumstick'],
    ['snack on strawberries', 'before tomorrow morning', 'before tomorrow morning', 'strawberry'],
    ['use up spinach', 'toss into dinner', 'toss into dinner', 'spinach'],
  ]

  const toggle = (index: number) => {
    setChecked((current) =>
      current.includes(index) ? current.filter((item) => item !== index) : [...current, index],
    )
  }

  return (
    <main className="home-screen">
      <section className="home-intro">
        <div>
          <p className="eyebrow">monday, october 21</p>
          <h1>use soon.</h1>
          <p className="hero-subtitle">three small things to save today.</p>
        </div>
        <Leekly scene className="home-mascot" />
        <button className="add-button" onClick={() => onNavigate('add')}>
          <span className="add-symbol">+</span>
          <span className="add-label"><span>add an</span> <span>item</span></span>
        </button>
      </section>

      <section className="daily-list" aria-label="Use soon list">
        {tasks.map(([title, note, mobileNote, icon], index) => {
          const isChecked = checked.includes(index)
          return (
            <label className={`daily-task ${isChecked ? 'is-checked' : ''}`} key={title}>
              <input type="checkbox" checked={isChecked} onChange={() => toggle(index)} />
              <span className="large-check" aria-hidden="true">
                {isChecked ? '✓' : ''}
              </span>
              <span className="task-number">0{index + 1}</span>
              <Artwork name={icon} className="task-icon" />
              <span className="task-copy">
                <strong>{title}</strong>
                <small>
                  <span className="desktop-task-note">{note}</span>
                  <span className="mobile-task-note">{mobileNote}</span>
                </small>
              </span>
            </label>
          )
        })}
      </section>

      <button className="quiet-link" onClick={() => onNavigate('fridge')}>
        everything in my fridge <span>→</span>
      </button>
    </main>
  )
}

function FoodCard({
  item,
  expanded,
  filteredOut = false,
  onExpand,
  onReviewExpired,
}: {
  item: FoodItem
  expanded: boolean
  filteredOut?: boolean
  onExpand: () => void
  onReviewExpired: (item: FoodItem) => void
}) {
  return (
    <article
      className={`food-card food-card--${item.status} ${expanded ? 'is-expanded' : ''} ${filteredOut ? 'is-filtered-out' : ''}`}
      onMouseEnter={() => {
        if (window.matchMedia('(min-width: 768px)').matches) onExpand()
      }}
    >
      <button
        className="card-summary"
        onClick={() => item.deferred ? onReviewExpired(item) : onExpand()}
        aria-expanded={expanded}
      >
        <Artwork name={item.icon} className="food-icon" />
        <span className="card-info">
          <span className="card-title">{item.name}</span>
          <span className="card-meta">
            <span className="status-pill">
              {item.status === 'expired' ? (
                <>
                  <span className="expired-label-desktop">{`expired ${item.days} ago`}</span>
                  <span className="expired-label-mobile">expired</span>
                </>
              ) : statusLabel[item.status]}
            </span>
            {item.extended && <span className="extended-tag">extended</span>}
            {item.status !== 'expired' && <span className="days-left">{item.days}</span>}
            {item.status === 'expired' && (
              <span className="expired-days-mobile">{item.days} ago</span>
            )}
            {item.deferred && <span className="check-in-tag">check in</span>}
          </span>
        </span>
        <span className="expand-mark">{expanded ? '−' : '+'}</span>
      </button>
      <div className="card-details">
        <div className="illustration-slot">
          <Artwork name={item.icon} className="expanded-food-icon" />
        </div>
        <div className="detail-line">
          <span>store</span>
          <p>{item.tip}</p>
        </div>
        <div className="detail-line">
          <span>check</span>
          <p>{item.senses}</p>
        </div>
        <button
          className="used-button"
          onClick={item.status === 'expired' ? () => onReviewExpired(item) : undefined}
        >
          {item.status === 'expired' ? 'review expired item' : 'mark as used'}
        </button>
      </div>
    </article>
  )
}

function FridgeScreen({
  items,
  filter,
  onFilterChange,
  onReviewExpired,
}: {
  items?: FoodItem[]
  filter: FridgeFilter
  onFilterChange: (filter: FridgeFilter) => void
  onReviewExpired: (item: FoodItem) => void
}) {
  const fridgeItems = Array.isArray(items) ? items : foodItems
  const [expanded, setExpanded] = useState<string | null>(null)
  const [filterCompact, setFilterCompact] = useState(false)
  const filterSentinelRef = useRef<HTMLDivElement>(null)
  const stages = {
    10: {
      label: 'nearly empty.',
      stocked: 'fruit, grains',
      empty: 'vegetables, protein, dairy, frozen foods',
    },
    40: {
      label: 'getting low.',
      stocked: 'fruit, protein, grains',
      empty: 'vegetables, dairy, frozen foods',
    },
    70: {
      label: 'well stocked.',
      stocked: 'vegetables, fruit, protein, dairy, grains',
      empty: 'frozen foods',
    },
    100: {
      label: 'fully stocked.',
      stocked: 'vegetables, fruit, protein, dairy, grains',
      empty: 'frozen foods',
    },
  } as const
  const [fullness, setFullness] = useState<keyof typeof stages>(70)
  const [showGroups, setShowGroups] = useState(false)
  const fullnessPreviewRef = useRef<HTMLDivElement>(null)
  const statusCounts = fridgeItems.reduce(
    (counts, item) => ({ ...counts, [item.status]: counts[item.status] + 1 }),
    { expired: 0, soon: 0, fresh: 0 },
  )
  const filterOptions: Array<{ value: FridgeFilter; label: string; count: number }> = [
    { value: 'all', label: 'all', count: fridgeItems.length },
    { value: 'expired', label: 'expired', count: statusCounts.expired },
    { value: 'soon', label: 'use soon', count: statusCounts.soon },
    { value: 'fresh', label: 'fresh', count: statusCounts.fresh },
  ]
  const visibleCount = filter === 'all' ? fridgeItems.length : statusCounts[filter]
  const activeLabel = filterOptions.find((option) => option.value === filter)?.label ?? 'items'
  const emptyMessages: Record<FoodStatus, string> = {
    expired: 'all clear!',
    soon: 'nothing close to expiring.',
    fresh: 'time to restock.',
  }
  const changeFilter = (nextFilter: FridgeFilter) => {
    setExpanded(null)
    onFilterChange(nextFilter === filter ? 'all' : nextFilter)
  }

  useEffect(() => {
    if (!showGroups) return

    const closeOutside = (event: PointerEvent) => {
      if (window.innerWidth >= 768) return
      const target = event.target as Node
      if (fullnessPreviewRef.current?.contains(target)) return
      if ((target as Element).closest?.('.stage-toggle')) return
      setShowGroups(false)
    }

    document.addEventListener('pointerdown', closeOutside)
    return () => document.removeEventListener('pointerdown', closeOutside)
  }, [showGroups])

  useEffect(() => {
    const sentinel = filterSentinelRef.current
    const scroller = sentinel?.closest('.app-shell')
    if (!sentinel || !scroller) return

    const updateCompactState = () => {
      if (window.innerWidth >= 768) {
        setFilterCompact(false)
        return
      }
      const topbar = scroller.querySelector<HTMLElement>('.topbar')
      const stickyTop = scroller.getBoundingClientRect().top + (topbar?.offsetHeight ?? 0)
      setFilterCompact(sentinel.getBoundingClientRect().top <= stickyTop)
    }

    updateCompactState()
    scroller.addEventListener('scroll', updateCompactState, { passive: true })
    window.addEventListener('resize', updateCompactState)
    return () => {
      scroller.removeEventListener('scroll', updateCompactState)
      window.removeEventListener('resize', updateCompactState)
    }
  }, [])

  return (
    <main className="fridge-screen">
      <section className="page-heading">
        <div
          ref={fullnessPreviewRef}
          className="fullness-preview"
          onMouseEnter={() => {
            if (window.innerWidth >= 768) setShowGroups(true)
          }}
          onMouseLeave={() => {
            if (window.innerWidth >= 768) setShowGroups(false)
          }}
        >
          <button
            type="button"
            className="fullness-art"
            aria-label={`Show food groups for ${fullness}% stocked`}
            aria-expanded={showGroups}
            onClick={() => setShowGroups((value) => !value)}
          >
            {([10, 40, 70, 100] as const).map((stage) => (
              <img
                key={stage}
                className={`fullness-stage ${fullness === stage ? 'is-visible' : ''}`}
                src={`/illustrations/fullness/stage-${stage}.png`}
                alt=""
                aria-hidden="true"
              />
            ))}
          </button>
          {showGroups && (
            <div className="stock-tooltip" onClick={() => setShowGroups(false)}>
              <p><strong>stocked</strong><span>{stages[fullness].stocked}</span></p>
              <p><strong>empty</strong><span>{stages[fullness].empty || 'nothing empty.'}</span></p>
              <small className="stock-tooltip-hint">tap to close</small>
            </div>
          )}
        </div>
        <div className="fridge-title">
          <div className="fridge-title-copy">
            <p className="eyebrow">sorted by urgency</p>
            <h1>everything in my fridge.</h1>
            <Leekly variant="point" className="mobile-fridge-leek" />
          </div>
          <p className="stock-label">{stages[fullness].label}</p>
          <div className="stage-toggle" aria-label="Prototype fullness preview">
            {([10, 40, 70, 100] as const).map((stage) => (
              <button
                type="button"
                key={stage}
                className={fullness === stage ? 'active' : ''}
                aria-pressed={fullness === stage}
                onClick={() => setFullness(stage)}
              >
                {stage}
              </button>
            ))}
          </div>
        </div>
      </section>
      <div className="fridge-list-stage">
        <div className="fridge-list-main">
          <div className="fridge-count-header">
            <div className="fridge-count-title">
              <strong>{filter === 'all' ? `${fridgeItems.length} items` : `${visibleCount} ${activeLabel}`}</strong>
              {filter !== 'all' && (
                <button type="button" onClick={() => changeFilter('all')}>clear</button>
              )}
            </div>
            <div className="filter-sticky-sentinel" ref={filterSentinelRef} aria-hidden="true" />
            <div className={`fridge-filter-tabs ${filterCompact ? 'is-compact' : ''}`} role="group" aria-label="Filter fridge by status">
              {filterOptions.map((option) => {
                const selected = filter === option.value
                const disabled = option.value !== 'all' && option.count === 0
                return (
                  <button
                    type="button"
                    key={option.value}
                    className={selected ? 'is-selected' : ''}
                    disabled={disabled}
                    aria-pressed={selected}
                    onClick={() => changeFilter(option.value)}
                  >
                    <span className="filter-tab-label">{option.label}</span>
                    <span className="filter-tab-meta">
                      {option.value === 'all' ? (
                        <span className="filter-marker-spacer" aria-hidden="true" />
                      ) : (
                        <span className={`filter-marker filter-marker--${option.value}`} aria-hidden="true" />
                      )}
                      <span className="filter-tab-count">{option.count}</span>
                    </span>
                  </button>
                )
              })}
            </div>
          </div>
          <div className="food-list">
            {fridgeItems.map((item) => (
              <FoodCard
                key={item.name}
                item={item}
                expanded={expanded === item.name}
                filteredOut={filter !== 'all' && item.status !== filter}
                onExpand={() => setExpanded(expanded === item.name ? null : item.name)}
                onReviewExpired={onReviewExpired}
              />
            ))}
            {filter !== 'all' && visibleCount === 0 && (
              <div className="filter-empty-state">
                <Leekly className="filter-empty-leek" />
                <strong>nothing here.</strong>
                <p>{emptyMessages[filter]}</p>
              </div>
            )}
          </div>
        </div>
        <aside className="fridge-leek-gutter" aria-label="Fridge status">
          <div className={`fridge-status-bubble ${statusCounts.expired + statusCounts.soon === 0 ? 'is-all-fresh' : ''}`}>
            {statusCounts.expired + statusCounts.soon === 0
              ? 'all fresh!'
              : `${statusCounts.expired} expired, ${statusCounts.soon} use soon`}
          </div>
          <Leekly variant="point" className="leek-point fridge-leek-point" />
        </aside>
      </div>
      {fridgeItems.length === 0 && <EmptyState message="your fridge is ready for something fresh." />}
    </main>
  )
}

function AddScreen({ onDone }: { onDone: () => void }) {
  const [step, setStep] = useState(1)
  const [receipt, setReceipt] = useState<string | null>(null)
  const [reading, setReading] = useState(false)
  const parsedItems = ['eggs', 'bananas', 'cilantro', 'mystery greens']

  const handleReceipt = (file?: File) => {
    if (file) {
      setReceipt(URL.createObjectURL(file))
      setReading(true)
      window.setTimeout(() => {
        setReading(false)
        setStep(2)
      }, 850)
    }
  }

  useEffect(() => {
    const receiveCameraFile = (event: Event) => {
      handleReceipt((event as CustomEvent<File>).detail)
    }
    window.addEventListener('freshy-camera-file', receiveCameraFile)
    return () => window.removeEventListener('freshy-camera-file', receiveCameraFile)
  }, [])

  return (
    <main className="add-screen">
      {reading && (
        <section className="receipt-loading">
          <Leekly variant="photo" className="loading-photoleek" />
          <p>reading your receipt...</p>
        </section>
      )}
      {!reading && step === 1 && (
        <section className="step-panel scan-step">
          <p className="eyebrow">scan receipt</p>
          <h1>show us your receipt.</h1>
          <div className="receipt-options">
            <label className="receipt-choice">
              <input
                type="file"
                accept="image/*"
                capture="environment"
                onChange={(event) => handleReceipt(event.target.files?.[0])}
              />
              <Leekly variant="photo" className="scan-mascot" />
              <span className="camera-choice-copy">
                <strong>take a photo</strong>
              </span>
            </label>
            <label className="receipt-choice upload-choice">
              <input
                type="file"
                accept="image/*,.pdf"
                onChange={(event) => handleReceipt(event.target.files?.[0])}
              />
              <img
                className="file-leek"
                src="/illustrations/mascot/new/file.png"
                alt=""
                aria-hidden="true"
              />
              <span className="file-choice-copy">
                <svg className="upload-file-icon" viewBox="0 0 24 24" aria-hidden="true">
                  <path d="M5 2h9l5 5v15H5zM14 2v5h5" />
                </svg>
                <strong>upload from files</strong>
              </span>
            </label>
          </div>
        </section>
      )}
      {!reading && step === 2 && (
        <section className="step-panel receipt-step">
          <p className="eyebrow">receipt captured</p>
          <h1>take a quick look.</h1>
          <div className="receipt-preview">
            {receipt && <img src={receipt} alt="Captured receipt preview" />}
            <Leekly variant="photo" className="preview-photoleek" />
            <div>
              <button
                className="outline-button"
                onClick={() => {
                  setReceipt(null)
                  setStep(1)
                }}
              >
                retake
              </button>
              <button className="add-button" onClick={() => setStep(3)}>
                continue
              </button>
            </div>
          </div>
        </section>
      )}
      {!reading && step === 3 && (
        <section className="step-panel">
          <p className="eyebrow">looks like you bought</p>
          <h1>check the list.</h1>
          <div className="parsed-list">
            {parsedItems.map((item, index) => (
              <div className="parsed-row" key={item}>
                <span>{item}</span>
                <label>
                  good for
                  <input defaultValue={index === 0 ? '14 days' : index === 1 ? '5 days' : '7 days'} />
                </label>
              </div>
            ))}
          </div>
          <div className="tip-card">
            <span>unknown food tip</span>
            <strong>mystery greens</strong>
            <p>try storing the stems in a jar of water.</p>
          </div>
          <button className="add-button mobile-pinned-action" onClick={onDone}>
            add to fridge
          </button>
        </section>
      )}
    </main>
  )
}

function StatCircle({
  finalValue,
  decimals = 0,
  initialDelay,
  label,
  tooltip,
  positive = false,
}: {
  finalValue: number
  decimals?: number
  initialDelay: number
  label: string
  tooltip: string
  positive?: boolean
}) {
  const reduceMotionInitially = window.matchMedia('(prefers-reduced-motion: reduce)').matches
  const [displayValue, setDisplayValue] = useState(
    reduceMotionInitially ? finalValue.toFixed(decimals) : decimals ? '0.0' : '0',
  )
  const [draw, setDraw] = useState({ key: 0, duration: 0, delay: 0, active: false })
  const [showTooltip, setShowTooltip] = useState(false)
  const animationFrame = useRef<number | null>(null)
  const reducedMotion = useRef(reduceMotionInitially)

  const formatValue = (value: number) =>
    decimals ? value.toFixed(decimals) : String(Math.floor(value))

  const animate = (duration: number, delay: number) => {
    if (animationFrame.current !== null) cancelAnimationFrame(animationFrame.current)

    if (reducedMotion.current) {
      setDisplayValue(finalValue.toFixed(decimals))
      setDraw((current) => ({ ...current, active: false }))
      return
    }

    setDisplayValue(decimals ? '0.0' : '0')
    setDraw((current) => ({
      key: current.key + 1,
      duration,
      delay,
      active: true,
    }))

    const startsAt = performance.now() + delay
    const tick = (now: number) => {
      if (now < startsAt) {
        animationFrame.current = requestAnimationFrame(tick)
        return
      }

      const progress = Math.min((now - startsAt) / duration, 1)
      const eased = 1 - Math.pow(1 - progress, 3)
      setDisplayValue(progress === 1 ? finalValue.toFixed(decimals) : formatValue(finalValue * eased))

      if (progress < 1) {
        animationFrame.current = requestAnimationFrame(tick)
      } else {
        animationFrame.current = null
      }
    }

    animationFrame.current = requestAnimationFrame(tick)
  }

  useEffect(() => {
    animate(1400, initialDelay)
    return () => {
      if (animationFrame.current !== null) cancelAnimationFrame(animationFrame.current)
    }
  }, [])

  const replay = () => {
    animate(1000, 0)
    setShowTooltip(true)
  }

  return (
    <button
      className={`stat-circle ${positive ? 'positive' : ''}`}
      onMouseEnter={replay}
      onMouseLeave={() => setShowTooltip(false)}
      onClick={replay}
    >
      <span className="circle-art">
        <svg viewBox="0 0 300 300" aria-hidden="true">
          <path
            key={draw.key}
            className={`circle-stroke ${draw.active ? 'is-animating' : ''}`}
            style={{
              animationDuration: `${draw.duration}ms`,
              animationDelay: `${draw.delay}ms`,
            }}
            d="M153 12C224 9 283 65 288 137C294 211 239 278 165 287C91 296 24 247 13 174C2 101 48 33 119 16C133 12 145 11 158 13C166 14 171 16 177 20"
          />
        </svg>
        <strong>{displayValue}</strong>
      </span>
      <span className="stat-label">
        {label.split(' ').map((word, index) => (
          <span key={word}>
            {index > 0 && <br className="mobile-stat-break" />}
            {word}
            {index === 0 && <span className="desktop-stat-space"> </span>}
          </span>
        ))}
      </span>
      {showTooltip && <span className="stat-tooltip">{tooltip}</span>}
    </button>
  )
}

function StatsScreen({ rescued, wasted }: { rescued: number; wasted: number }) {
  const [statsLeek] = useState<'cool' | 'number-one'>(() =>
    Math.random() < 0.5 ? 'cool' : 'number-one',
  )
  const weeks = [
    ['this week', '9', '0.4'],
    ['last week', '11', '0.8'],
    ['oct 7–13', '8', '1.2'],
    ['sep 30–oct 6', '10', '1.8'],
  ]

  return (
    <main className="stats-page">
      <section className="compact-heading stats-heading">
        <div className="stats-leek-preview">
          <img
            className="stats-mascot"
            src={`/illustrations/mascot/new/${statsLeek}.png`}
            alt=""
            aria-hidden="true"
          />
        </div>
        <h1>your numbers.</h1>
      </section>
      <section className="stats-screen">
        <StatCircle
          finalValue={rescued}
          initialDelay={0}
          label="items rescued"
          tooltip="foods you finished before they expired"
          positive
        />
        <StatCircle
          finalValue={wasted}
          decimals={1}
          initialDelay={200}
          label="lbs wasted"
          tooltip="estimated food discarded this month"
        />
        <StatCircle
          finalValue={7}
          initialDelay={400}
          label="day streak"
          tooltip="days in a row with no expired food"
          positive
        />
      </section>
      <div className="thin-list week-list">
        <div className="thin-row list-labels">
          <span>week</span>
          <span>
            <span className="desktop-table-label">items rescued</span>
            <span className="mobile-table-label">rescued</span>
          </span>
          <span>
            <span className="desktop-table-label">lbs wasted</span>
            <span className="mobile-table-label">lbs</span>
          </span>
        </div>
        {weeks.map(([week, rescued, wasted]) => (
          <button className="thin-row" key={week}>
            <strong>{week}</strong>
            <span>{rescued}</span>
            <span>{wasted}<span className="desktop-unit"> lbs</span></span>
          </button>
        ))}
      </div>
    </main>
  )
}

function FriendsScreen() {
  const friends = [
    ['01', 'maya', '0.2', '18'],
    ['02', 'you', '0.4', '12'],
    ['03', 'theo', '0.7', '9'],
    ['04', 'dev', '1.1', '6'],
    ['05', 'nina', '1.4', '4'],
  ]

  return (
    <main className="friends-page">
      <section className="compact-heading heading-with-action friends-heading">
        <img
          className="friends-header-art"
          src="/illustrations/mascot/new/friends.png"
          alt=""
          aria-hidden="true"
        />
        <div>
          <p className="eyebrow">this week</p>
          <h1>you + friends.</h1>
        </div>
        <button className="outline-button">+ add a friend</button>
      </section>
      <div className="friends-stage">
        <div className="thin-list friends-list">
          <div className="thin-row list-labels friend-columns">
            <span>rank</span>
            <span>name</span>
            <span>
              <span className="desktop-table-label">lbs wasted</span>
              <span className="mobile-table-label">lbs</span>
            </span>
            <span>streak</span>
            <span>drawing</span>
          </div>
          {friends.map(([rank, name, wasted, streak]) => (
            <button className={`thin-row friend-columns ${name === 'you' ? 'is-you' : ''}`} key={name}>
              <span>{rank}</span>
              <strong>{name}</strong>
              <span>{wasted}<span className="desktop-unit"> lbs</span></span>
              <span>{streak}<span className="desktop-unit"> days</span></span>
              <span className="friend-drawing" aria-label="Future custom drawing" />
            </button>
          ))}
        </div>
      </div>
    </main>
  )
}

function SwipeTakeover({
  item,
  onDecision,
  onBack,
}: {
  item: FoodItem
  onDecision: (decision: 'used' | 'wasted' | 'extended') => void
  onBack: () => void
}) {
  const [step, setStep] = useState<1 | 2>(1)
  const [exit, setExit] = useState<'left' | 'right' | null>(null)
  const [entry, setEntry] = useState<'left' | 'right' | null>(null)
  const [closing, setClosing] = useState(false)
  const [visitedStepTwo, setVisitedStepTwo] = useState(false)
  const [dragX, setDragX] = useState(0)
  const [hasSwiped, setHasSwiped] = useState(false)
  const [stampDirection, setStampDirection] = useState<'left' | 'right' | null>(null)
  const dragStart = useRef<number | null>(null)
  const cardRef = useRef<HTMLDivElement>(null)

  const finish = (direction: 'left' | 'right') => {
    setDragX(0)
    setStampDirection(direction)
    setExit(direction)
    window.setTimeout(() => {
      if (step === 1 && direction === 'right') onDecision('used')
      else if (step === 1 && !item.extended) {
        setVisitedStepTwo(true)
        setStep(2)
        setExit(null)
        setEntry('right')
        setStampDirection(null)
      } else if (step === 2 && direction === 'right') onDecision('extended')
      else onDecision('wasted')
    }, 250)
  }

  const choose = (direction: 'left' | 'right') => {
    if (exit || stampDirection) return
    setStampDirection(direction)
    window.setTimeout(() => finish(direction), 300)
  }

  const goBack = () => {
    if (exit || closing) return
    if (step === 2) {
      setExit('right')
      window.setTimeout(() => {
        setStep(1)
        setExit(null)
        setEntry('left')
      }, 250)
    } else {
      setClosing(true)
      window.setTimeout(onBack, 200)
    }
  }

  useEffect(() => {
    const handleEscape = (event: KeyboardEvent) => {
      if (event.key === 'Escape') goBack()
    }
    window.addEventListener('keydown', handleEscape)
    return () => window.removeEventListener('keydown', handleEscape)
  })

  const release = (event: React.PointerEvent<HTMLDivElement>) => {
    if (dragStart.current === null) return
    const width = cardRef.current?.offsetWidth ?? 1
    if (Math.abs(dragX) >= width * 0.4) finish(dragX > 0 ? 'right' : 'left')
    else {
      setDragX(0)
      setStampDirection(null)
    }
    dragStart.current = null
    event.currentTarget.releasePointerCapture(event.pointerId)
  }

  const rotation = Math.max(-8, Math.min(8, (dragX / (cardRef.current?.offsetWidth || 1)) * 16))
  const cardWidth = cardRef.current?.offsetWidth || 1
  const stampOpacity = Math.min(Math.abs(dragX) / (cardWidth * 0.4), 1)

  return (
    <div className="swipe-takeover" role="dialog" aria-modal>
      <div
        key={step}
        ref={cardRef}
        className={`swipe-card swipe-card--step-${step} ${exit ? `swipe-${exit}` : ''} ${entry ? `swipe-enter-${entry}` : ''} ${closing ? 'swipe-close' : ''}`}
        style={!exit && !closing ? { transform: `translateX(${dragX}px) rotate(${rotation}deg)` } : undefined}
        onPointerDown={(event) => {
          dragStart.current = event.clientX - dragX
          event.currentTarget.setPointerCapture(event.pointerId)
        }}
        onPointerMove={(event) => {
          if (dragStart.current !== null) {
            const nextDrag = event.clientX - dragStart.current
            setDragX(nextDrag)
            if (Math.abs(nextDrag) > 8) setHasSwiped(true)
          }
        }}
        onPointerUp={release}
        onPointerCancel={release}
      >
        <button
          type="button"
          className="swipe-back"
          onPointerDown={(event) => event.stopPropagation()}
          onClick={goBack}
        >
          <span>←</span> back
        </button>
        <span className={`swipe-progress ${step === 1 && !visitedStepTwo ? 'is-hidden' : ''}`}>{step} of 2</span>
        <span
          className={`swipe-stamp swipe-stamp--left ${step === 2 ? '' : 'swipe-stamp--wasted'}`}
          style={{ opacity: stampDirection === 'left' ? 1 : dragX < 0 ? stampOpacity : 0 }}
        >
          {step === 2 ? 'toss' : 'wasted'}
        </span>
        <span
          className="swipe-stamp swipe-stamp--right"
          style={{ opacity: stampDirection === 'right' ? 1 : dragX > 0 ? stampOpacity : 0 }}
        >
          {step === 2 ? 'extended' : 'used'}
        </span>

        {step === 1 ? (
          <>
            <span className="status-pill">expired</span>
            <p>{item.name}</p>
            <Artwork name={item.icon} className="swipe-food-art" />
            <h1>did you use it?</h1>
            <div className="swipe-actions">
              <button onClick={() => choose('left')}>← wasted</button>
              <button className="used-choice" onClick={() => choose('right')}>used →</button>
            </div>
            <small className={`mobile-swipe-hint ${hasSwiped ? 'is-hidden' : ''}`}>
              swipe left or right
            </small>
          </>
        ) : (
          <>
            <span className="swipe-kicker">one more check</span>
            <div className="spoil-food-column">
              <span className="status-pill">expired</span>
              <p className="spoil-food-name">{item.name}</p>
              <div className="spoil-food-art">
                <Artwork name={item.icon} className="swipe-food-art swipe-food-art--check" />
              </div>
              <p className="spoil-expiry">expired {item.days} ago</p>
            </div>
            <div className="spoil-question-column">
              <h1>does it look spoiled?</h1>
              <div className="spoil-check-box">
                <strong>check</strong>
                <p>{item.senses}</p>
              </div>
              <p className="spoil-hint">our dates are cautious estimates. trust your eyes and nose.</p>
              <div className="swipe-actions">
                <button className="used-choice" onClick={() => choose('right')}>
                  <span className="swipe-label-desktop">no, 2 more days →</span>
                  <span className="swipe-label-mobile">2 more days →</span>
                </button>
                <button onClick={() => choose('left')}>
                  <span className="swipe-label-desktop">← yes, toss :(</span>
                  <span className="swipe-label-mobile">← toss it</span>
                </button>
              </div>
            </div>
          </>
        )}
      </div>
      <small className={hasSwiped ? 'is-hidden' : ''}>swipe left or right</small>
    </div>
  )
}

export default function App() {
  const [screen, setScreen] = useState<Screen>('home')
  const [items, setItems] = useState(foodItems)
  const [fridgeFilter, setFridgeFilter] = useState<FridgeFilter>('all')
  const [reviewItem, setReviewItem] = useState<FoodItem | null>(null)
  const [rescued, setRescued] = useState(12)
  const [wasted, setWasted] = useState(3.5)
  const [quietToast, setQuietToast] = useState<string | null>(null)
  const [pendingDecision, setPendingDecision] = useState<{
    decision: 'used' | 'wasted' | 'extended'
    item: FoodItem
  } | null>(null)
  const decisionTimer = useRef<number | null>(null)

  useEffect(() => {
    setItems(foodItems)
  }, [])

  useEffect(() => {
    if (!Array.isArray(items)) setItems(foodItems)
  }, [items])

  useEffect(() => () => {
    if (decisionTimer.current !== null) window.clearTimeout(decisionTimer.current)
  }, [])

  const commitDecision = (decision: 'used' | 'wasted' | 'extended', item: FoodItem) => {
    if (decision === 'used') setRescued((value) => value + 1)
    if (decision === 'wasted') {
      setWasted((value) => Number((value + (item.wasteLbs ?? 0.4)).toFixed(1)))
    }
    setPendingDecision(null)
    decisionTimer.current = null
  }

  const queueDecision = (decision: 'used' | 'wasted' | 'extended') => {
    if (!reviewItem) return
    const decidedItem = reviewItem

    if (decision === 'extended') {
      setItems((current) =>
        (Array.isArray(current) ? current : foodItems)
          .map((item) =>
            item.name === decidedItem.name
              ? { ...item, status: 'soon' as const, days: '2 days', extended: true, deferred: false }
              : item,
          )
          .sort((a, b) => ['expired', 'soon', 'fresh'].indexOf(a.status) - ['expired', 'soon', 'fresh'].indexOf(b.status)),
      )
    } else {
      setItems((current) =>
        (Array.isArray(current) ? current : foodItems).filter((item) => item.name !== decidedItem.name),
      )
    }

    setReviewItem(null)
    setPendingDecision({ decision, item: decidedItem })
    if (decisionTimer.current !== null) window.clearTimeout(decisionTimer.current)
    decisionTimer.current = window.setTimeout(() => commitDecision(decision, decidedItem), 5000)
  }

  const undoDecision = () => {
    if (!pendingDecision) return
    if (decisionTimer.current !== null) window.clearTimeout(decisionTimer.current)
    setItems((current) => {
      const withoutDecision = (Array.isArray(current) ? current : foodItems).filter(
        (item) => item.name !== pendingDecision.item.name,
      )
      return [pendingDecision.item, ...withoutDecision].sort(
        (a, b) => ['expired', 'soon', 'fresh'].indexOf(a.status) - ['expired', 'soon', 'fresh'].indexOf(b.status),
      )
    })
    setReviewItem(pendingDecision.item)
    setPendingDecision(null)
    decisionTimer.current = null
  }

  return (
    <div className="app-shell">
      <Header screen={screen} onNavigate={setScreen} />
      <div className="mobile-page-scroll">
        {screen === 'home' && <HomeScreen onNavigate={setScreen} />}
        {screen === 'fridge' && (
          <FridgeScreen
            items={items}
            filter={fridgeFilter}
            onFilterChange={setFridgeFilter}
            onReviewExpired={setReviewItem}
          />
        )}
        {screen === 'add' && <AddScreen onDone={() => setScreen('fridge')} />}
        {screen === 'stats' && <StatsScreen rescued={rescued} wasted={wasted} />}
        {screen === 'friends' && <FriendsScreen />}
        <div className="mobile-page-end-spacer" aria-hidden="true" />
      </div>
      {reviewItem && (
        <SwipeTakeover
          item={reviewItem}
          onDecision={queueDecision}
          onBack={() => {
            setItems((current) =>
              (Array.isArray(current) ? current : foodItems).map((item) =>
                item.name === reviewItem.name ? { ...item, deferred: true } : item,
              ),
            )
            setReviewItem(null)
            setQuietToast("no worries, we'll ask again later")
            window.setTimeout(() => setQuietToast(null), 2000)
          }}
        />
      )}
      {pendingDecision && (
        <button className="decision-toast" type="button" onClick={undoDecision}>
          {pendingDecision.decision === 'used'
            ? 'marked as used.'
            : pendingDecision.decision === 'wasted'
              ? 'tossed.'
              : 'extended 2 days.'}{' '}
          <u>undo</u>
        </button>
      )}
      {quietToast && <div className="extension-toast" role="status">{quietToast}</div>}
      <footer>
        <p>spoil less eat fresh!</p>
        <span>freshy © 2025</span>
      </footer>
    </div>
  )
}
