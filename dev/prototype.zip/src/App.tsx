import { useState } from 'react'

type Screen = 'home' | 'fridge' | 'add' | 'stats' | 'friends'
type FoodStatus = 'fresh' | 'soon' | 'expired'

type FoodItem = {
  name: string
  days: string
  status: FoodStatus
  tip: string
  senses: string
  illustration: string
}

const foodItems: FoodItem[] = [
  {
    name: 'chicken thighs',
    days: 'today',
    status: 'soon',
    tip: 'keep sealed on the lowest shelf.',
    senses: 'fresh smells mild and feels firm.',
    illustration: 'chicken sketch',
  },
  {
    name: 'strawberries',
    days: '1 day',
    status: 'soon',
    tip: 'keep dry and wash only before eating.',
    senses: 'fresh berries smell sweet and stay bright.',
    illustration: 'berry sketch',
  },
  {
    name: 'spinach',
    days: '2 days',
    status: 'soon',
    tip: 'add a dry paper towel to the bag.',
    senses: 'fresh leaves are crisp with no sour smell.',
    illustration: 'leaf sketch',
  },
  {
    name: 'oat milk',
    days: '6 days',
    status: 'fresh',
    tip: 'store in the coldest part, not the door.',
    senses: 'fresh oat milk smells neutral and pours smooth.',
    illustration: 'carton sketch',
  },
  {
    name: 'greek yogurt',
    days: '8 days',
    status: 'fresh',
    tip: 'seal tightly after every scoop.',
    senses: 'fresh yogurt smells tangy, never yeasty.',
    illustration: 'yogurt sketch',
  },
  {
    name: 'leftover pasta',
    days: 'expired',
    status: 'expired',
    tip: 'cool quickly and use within four days.',
    senses: 'discard if slimy or unusually sour.',
    illustration: 'pasta sketch',
  },
]

const statusLabel: Record<FoodStatus, string> = {
  fresh: 'fresh',
  soon: 'use soon',
  expired: 'expired',
}

function FridgeDoodle() {
  return (
    <svg viewBox="0 0 36 44" aria-hidden="true">
      <path d="M7 3.5h22v36H7zM7 18h22M24.5 9v5M24.5 23v5M11 39.5v2M25 39.5v2" />
      <path d="M4 7c1.2-1.1 1.5-2.4 1-4M31 35c1.7.2 2.5 1 3 2.5" />
    </svg>
  )
}

function Header({
  screen,
  onNavigate,
}: {
  screen: Screen
  onNavigate: (screen: Screen) => void
}) {
  return (
    <header className="topbar">
      <button className="brand" onClick={() => onNavigate('home')} aria-label="Freshy home">
        <span className="logo-mark">
          <FridgeDoodle />
        </span>
        <span>freshy</span>
      </button>
      <nav aria-label="Primary navigation">
        <button
          className={`nav-link ${screen === 'fridge' ? 'active' : ''}`}
          onClick={() => onNavigate('fridge')}
        >
          fridge
        </button>
        <button
          className={`nav-link ${screen === 'add' ? 'active' : ''}`}
          onClick={() => onNavigate('add')}
        >
          scan receipt
        </button>
        <button
          className={`nav-link ${screen === 'stats' ? 'active' : ''}`}
          onClick={() => onNavigate('stats')}
        >
          stats
        </button>
        <button
          className={`nav-link ${screen === 'friends' ? 'active' : ''}`}
          onClick={() => onNavigate('friends')}
        >
          friends
        </button>
      </nav>
    </header>
  )
}

function HomeScreen({ onNavigate }: { onNavigate: (screen: Screen) => void }) {
  const [checked, setChecked] = useState<number[]>([])
  const tasks = [
    ['cook chicken thighs', 'try with spinach tonight'],
    ['snack on strawberries', 'before tomorrow morning'],
    ['use up spinach', 'toss into dinner'],
  ]

  const toggle = (index: number) => {
    setChecked((current) =>
      current.includes(index) ? current.filter((item) => item !== index) : [...current, index],
    )
  }

  return (
    <main className="home-screen">
      <section className="home-intro">
        <div>
          <p className="eyebrow">monday, october 21</p>
          <h1>use soon.</h1>
          <p className="hero-subtitle">three small things to save today.</p>
        </div>
        <button className="add-button" onClick={() => onNavigate('add')}>
          <span>+</span> add an item
        </button>
      </section>

      <section className="daily-list" aria-label="Use soon list">
        {tasks.map(([title, note], index) => {
          const isChecked = checked.includes(index)
          return (
            <label className={`daily-task ${isChecked ? 'is-checked' : ''}`} key={title}>
              <input type="checkbox" checked={isChecked} onChange={() => toggle(index)} />
              <span className="large-check" aria-hidden="true">
                {isChecked ? '✓' : ''}
              </span>
              <span className="task-number">0{index + 1}</span>
              <span className="task-copy">
                <strong>{title}</strong>
                <small>{note}</small>
              </span>
            </label>
          )
        })}
      </section>

      <button className="quiet-link" onClick={() => onNavigate('fridge')}>
        everything in my fridge <span>→</span>
      </button>
    </main>
  )
}

function FoodCard({
  item,
  expanded,
  onExpand,
  onReviewExpired,
}: {
  item: FoodItem
  expanded: boolean
  onExpand: () => void
  onReviewExpired: () => void
}) {
  return (
    <article
      className={`food-card food-card--${item.status} ${expanded ? 'is-expanded' : ''}`}
      onMouseEnter={onExpand}
    >
      <button className="card-summary" onClick={onExpand} aria-expanded={expanded}>
        <span className="status-pill">{statusLabel[item.status]}</span>
        <span className="card-title">{item.name}</span>
        <span className="days-left">{item.days}</span>
        <span className="expand-mark">{expanded ? '−' : '+'}</span>
      </button>
      <div className="card-details">
        <div className="illustration-slot">
          <span>custom illustration</span>
          <strong>[{item.illustration}]</strong>
        </div>
        <div className="detail-line">
          <span>store</span>
          <p>{item.tip}</p>
        </div>
        <div className="detail-line">
          <span>check</span>
          <p>{item.senses}</p>
        </div>
        <button
          className="used-button"
          onClick={item.status === 'expired' ? onReviewExpired : undefined}
        >
          {item.status === 'expired' ? 'review expired item' : 'mark as used'}
        </button>
      </div>
    </article>
  )
}

function FridgeScreen({ onReviewExpired }: { onReviewExpired: () => void }) {
  const [expanded, setExpanded] = useState<string | null>(null)
  const [showAll, setShowAll] = useState(false)
  const visibleItems = showAll ? foodItems : foodItems.slice(0, 4)

  return (
    <main className="fridge-screen">
      <section className="page-heading">
        <div>
          <p className="eyebrow">sorted by urgency</p>
          <h1>everything in my fridge.</h1>
        </div>
        <p className="item-count">06 items</p>
      </section>
      <div className="food-list">
        {visibleItems.map((item) => (
          <FoodCard
            key={item.name}
            item={item}
            expanded={expanded === item.name}
            onExpand={() => setExpanded(expanded === item.name ? null : item.name)}
            onReviewExpired={onReviewExpired}
          />
        ))}
      </div>
      {!showAll && (
        <button className="quiet-link centered" onClick={() => setShowAll(true)}>
          see all 6 <span>→</span>
        </button>
      )}
    </main>
  )
}

function AddScreen({ onDone }: { onDone: () => void }) {
  const [step, setStep] = useState(1)
  const [receipt, setReceipt] = useState<string | null>(null)
  const parsedItems = ['eggs', 'bananas', 'cilantro', 'mystery greens']

  const handleReceipt = (file?: File) => {
    if (file) setReceipt(URL.createObjectURL(file))
  }

  return (
    <main className="add-screen">
      <div className="step-count">0{step} / 03</div>
      {step === 1 && (
        <section className="step-panel">
          <p className="eyebrow">scan receipt</p>
          <h1>show us your receipt.</h1>
          {!receipt ? (
            <div className="receipt-options">
              <label className="receipt-choice">
                <input
                  type="file"
                  accept="image/*"
                  capture="environment"
                  onChange={(event) => handleReceipt(event.target.files?.[0])}
                />
                <svg viewBox="0 0 32 32" aria-hidden="true">
                  <path d="M4 10h6l2-3h8l2 3h6v16H4z" />
                  <circle cx="16" cy="18" r="5" />
                </svg>
                <strong>take a photo</strong>
                <small>open your camera</small>
              </label>
              <label className="receipt-choice">
                <input
                  type="file"
                  accept="image/*,.pdf"
                  onChange={(event) => handleReceipt(event.target.files?.[0])}
                />
                <span className="receipt-icon">↑</span>
                <strong>upload from files</strong>
                <small>photo or pdf</small>
              </label>
            </div>
          ) : (
            <div className="receipt-preview">
              <img src={receipt} alt="Captured receipt preview" />
              <div>
                <button className="outline-button" onClick={() => setReceipt(null)}>
                  retake
                </button>
                <button className="add-button" onClick={() => setStep(2)}>
                  continue
                </button>
              </div>
            </div>
          )}
        </section>
      )}
      {step === 2 && (
        <section className="step-panel">
          <p className="eyebrow">looks like you bought</p>
          <h1>check the list.</h1>
          <div className="parsed-list">
            {parsedItems.map((item, index) => (
              <div className="parsed-row" key={item}>
                <span>{item}</span>
                <label>
                  good for
                  <input defaultValue={index === 0 ? '14 days' : index === 1 ? '5 days' : '7 days'} />
                </label>
              </div>
            ))}
          </div>
          <div className="tip-card">
            <span>unknown food tip</span>
            <strong>mystery greens</strong>
            <p>try storing the stems in a jar of water.</p>
          </div>
          <button className="add-button" onClick={() => setStep(3)}>
            everything looks right
          </button>
        </section>
      )}
      {step === 3 && (
        <section className="step-panel final-step">
          <p className="eyebrow">ready when you are</p>
          <h1>four items.<br />zero fuss.</h1>
          <button className="add-button large" onClick={onDone}>
            add to fridge <span>→</span>
          </button>
        </section>
      )}
    </main>
  )
}

function StatsScreen() {
  const weeks = [
    ['this week', '9', '0.4 lbs'],
    ['last week', '11', '0.8 lbs'],
    ['oct 7–13', '8', '1.2 lbs'],
    ['sep 30–oct 6', '10', '1.8 lbs'],
  ]

  return (
    <main className="stats-page">
      <section className="compact-heading">
        <p className="eyebrow">a quiet look back</p>
        <h1>your numbers.</h1>
      </section>
      <section className="stats-screen">
        <button className="stat-block positive">
          <span>items rescued</span>
          <strong>38</strong>
        </button>
        <button className="stat-block">
          <span>lbs wasted</span>
          <strong>4.2</strong>
        </button>
        <button className="stat-block positive">
          <span>day streak</span>
          <strong>12</strong>
        </button>
      </section>
      <div className="thin-list week-list">
        <div className="thin-row list-labels">
          <span>week</span>
          <span>items rescued</span>
          <span>lbs wasted</span>
        </div>
        {weeks.map(([week, rescued, wasted]) => (
          <button className="thin-row" key={week}>
            <strong>{week}</strong>
            <span>{rescued}</span>
            <span>{wasted}</span>
          </button>
        ))}
      </div>
    </main>
  )
}

function FriendsScreen() {
  const friends = [
    ['01', 'maya', '0.2 lbs', '18 days'],
    ['02', 'you', '0.4 lbs', '12 days'],
    ['03', 'theo', '0.7 lbs', '9 days'],
    ['04', 'dev', '1.1 lbs', '6 days'],
    ['05', 'nina', '1.4 lbs', '4 days'],
  ]

  return (
    <main className="friends-page">
      <section className="compact-heading heading-with-action">
        <div>
          <p className="eyebrow">this week</p>
          <h1>you + friends.</h1>
        </div>
        <button className="outline-button">+ add a friend</button>
      </section>
      <div className="thin-list friends-list">
        <div className="thin-row list-labels friend-columns">
          <span>rank</span>
          <span>name</span>
          <span>lbs wasted</span>
          <span>streak</span>
          <span>drawing</span>
        </div>
        {friends.map(([rank, name, wasted, streak]) => (
          <button className={`thin-row friend-columns ${name === 'you' ? 'is-you' : ''}`} key={name}>
            <span>{rank}</span>
            <strong>{name}</strong>
            <span>{wasted}</span>
            <span>{streak}</span>
            <span className="friend-drawing" aria-label="Future custom drawing" />
          </button>
        ))}
      </div>
    </main>
  )
}

function SwipeTakeover({ onClose }: { onClose: () => void }) {
  const [result, setResult] = useState<'used' | 'wasted' | null>(null)

  const choose = (choice: 'used' | 'wasted') => {
    setResult(choice)
    window.setTimeout(onClose, 650)
  }

  return (
    <div className={`swipe-takeover ${result ? `result-${result}` : ''}`} role="dialog" aria-modal>
      <p className="eyebrow">quick check-in</p>
      <div className={`swipe-card ${result ? `swipe-${result}` : ''}`}>
        <span className="status-pill">expired</span>
        <p>leftover pasta</p>
        <h1>{result === 'used' ? 'nice save.' : result === 'wasted' ? 'noted.' : 'did you use it?'}</h1>
        {!result && (
          <div className="swipe-actions">
            <button onClick={() => choose('wasted')}>← wasted</button>
            <button className="used-choice" onClick={() => choose('used')}>
              used →
            </button>
          </div>
        )}
      </div>
      {!result && <small>swipe left or right</small>}
    </div>
  )
}

export default function App() {
  const [screen, setScreen] = useState<Screen>('home')
  const [showSwipe, setShowSwipe] = useState(false)

  return (
    <div className="app-shell">
      <Header screen={screen} onNavigate={setScreen} />
      {screen === 'home' && <HomeScreen onNavigate={setScreen} />}
      {screen === 'fridge' && <FridgeScreen onReviewExpired={() => setShowSwipe(true)} />}
      {screen === 'add' && <AddScreen onDone={() => setScreen('fridge')} />}
      {screen === 'stats' && <StatsScreen />}
      {screen === 'friends' && <FriendsScreen />}
      {showSwipe && <SwipeTakeover onClose={() => setShowSwipe(false)} />}
      <footer>
        <p>keep it fresh. keep it simple.</p>
        <span>freshy © 2025</span>
      </footer>
    </div>
  )
}
