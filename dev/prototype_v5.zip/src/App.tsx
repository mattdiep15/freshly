import { Fragment, useEffect, useRef, useState } from 'react'

type Screen = 'fridge' | 'recipes' | 'add' | 'stats' | 'friends'
type FoodStatus = 'fresh' | 'soon' | 'expired'
type FridgeFilter = 'all' | FoodStatus
type FoodGroup = 'vegetables' | 'fruit' | 'protein' | 'dairy-eggs' | 'grains' | 'other'
type FoodUnit = 'items' | 'lbs' | 'bag' | 'carton' | 'container'
type StorageLocation = 'fridge' | 'freezer'

type FoodItem = {
  id?: string
  name: string
  days: string
  status: FoodStatus
  tip: string
  senses: string
  icon?: string
  group?: FoodGroup
  quantity?: number
  unit?: FoodUnit
  storage?: StorageLocation
  boughtOn?: string
  opened?: boolean
  goodForDays?: number
  extended?: boolean
  deferred?: boolean
  wasteLbs?: number
}

type ManualItemInput = {
  name: string
  icon?: string
  group: FoodGroup
  quantity: number
  unit: FoodUnit
  storage: StorageLocation
  boughtOn: string
  opened: boolean
  goodForDays: number
  tip: string
  senses: string
}

type ManualItemDraft = {
  draftId: string
  name: string
  selectedFoodName: string | null
  group: FoodGroup | null
  quantity: number
  unit: FoodUnit
  storage: StorageLocation
  boughtOn: string
  opened: boolean
  goodForDays: number
  showMoreDetails: boolean
}

type KnownFood = {
  name: string
  icon: string
  group: FoodGroup
  goodForDays: number
  unit: FoodUnit
  tip: string
  senses: string
}

type Recipe = {
  id: string
  name: string
  ingredients: string[]
  minutes: number
  dish: 'pot' | 'pan' | 'bowl'
  cookTool: 'pot' | 'pan'
  heat: string
  servings: number
  steps: Array<{
    phase: 'prep' | 'cook' | 'serve'
    text: string
    timedMinutes?: number
    whisk?: boolean
  }>
}

const knownFoods: KnownFood[] = [
  { name: 'eggs', icon: 'eggs', group: 'dairy-eggs', goodForDays: 14, unit: 'carton', tip: 'keep in their carton on a middle shelf.', senses: 'discard eggs with an unusual smell after cracking.' },
  { name: 'greek yogurt', icon: 'greek-yogurt', group: 'dairy-eggs', goodForDays: 7, unit: 'container', tip: 'keep sealed in the coldest part of the fridge.', senses: 'discard if moldy or unusually sour.' },
  { name: 'strawberries', icon: 'strawberry', group: 'fruit', goodForDays: 3, unit: 'container', tip: 'keep dry and wash only before eating.', senses: 'fresh berries smell sweet and stay bright.' },
  { name: 'spinach', icon: 'spinach', group: 'vegetables', goodForDays: 5, unit: 'bag', tip: 'add a dry paper towel to the bag.', senses: 'fresh leaves are crisp with no sour smell.' },
  { name: 'shrimp', icon: 'shrimp', group: 'protein', goodForDays: 2, unit: 'lbs', tip: 'keep sealed on ice in the coldest spot.', senses: 'fresh shrimp smell clean and feel firm.' },
  { name: 'salmon', icon: 'fish', group: 'protein', goodForDays: 2, unit: 'lbs', tip: 'keep tightly wrapped on the lowest shelf.', senses: 'fresh salmon smells mild and looks glossy.' },
  { name: 'chicken thighs', icon: 'drumstick', group: 'protein', goodForDays: 2, unit: 'lbs', tip: 'keep sealed on the lowest shelf.', senses: 'fresh chicken smells mild and feels firm.' },
  { name: 'bananas', icon: 'banana', group: 'fruit', goodForDays: 5, unit: 'items', tip: 'keep on the counter away from other fruit.', senses: 'good bananas smell sweet with firm skins.' },
  { name: 'avocado', icon: 'avocado', group: 'fruit', goodForDays: 4, unit: 'items', tip: 'refrigerate once it feels slightly soft.', senses: 'ripe avocado yields gently without mushiness.' },
  { name: 'oat milk', icon: 'milk-carton', group: 'dairy-eggs', goodForDays: 7, unit: 'carton', tip: 'store in the coldest part, not the door.', senses: 'fresh oat milk smells neutral and pours smooth.' },
  { name: 'leftover pasta', icon: 'pasta', group: 'grains', goodForDays: 4, unit: 'container', tip: 'cool quickly and use within four days.', senses: 'discard if slimy or unusually sour.' },
  { name: 'bread', icon: 'bread', group: 'grains', goodForDays: 5, unit: 'bag', tip: 'keep sealed or freeze half the loaf.', senses: 'fresh bread smells warm with no visible mold.' },
  { name: 'butter', icon: 'butter', group: 'dairy-eggs', goodForDays: 14, unit: 'container', tip: 'keep covered away from strong-smelling foods.', senses: 'fresh butter smells clean and looks even.' },
  { name: 'broccoli', icon: 'broccoli', group: 'vegetables', goodForDays: 6, unit: 'items', tip: 'keep loosely wrapped in the crisper.', senses: 'fresh broccoli is firm with tight florets.' },
  { name: 'garlic', icon: 'garlic', group: 'vegetables', goodForDays: 21, unit: 'items', tip: 'keep in a cool, dry, ventilated place.', senses: 'good garlic is firm and dry.' },
  { name: 'oats', icon: 'grains', group: 'grains', goodForDays: 30, unit: 'bag', tip: 'keep sealed in a cool, dry cupboard.', senses: 'discard if damp or unusually musty.' },
  { name: 'honey', icon: 'honey', group: 'other', goodForDays: 365, unit: 'container', tip: 'keep sealed at room temperature.', senses: 'natural crystallization is safe.' },
  { name: 'olive oil', icon: 'oil', group: 'other', goodForDays: 90, unit: 'container', tip: 'keep tightly closed away from heat and light.', senses: 'discard if it smells stale or waxy.' },
  { name: 'rice', icon: 'rice', group: 'grains', goodForDays: 30, unit: 'bag', tip: 'keep dry rice sealed in the pantry.', senses: 'discard if damp or unusually musty.' },
]

const foodKey = (item: FoodItem) => item.id ?? item.name
const todayISO = () => {
  const now = new Date()
  return new Date(now.getTime() - now.getTimezoneOffset() * 60000).toISOString().slice(0, 10)
}
const countStage = (count: number): 10 | 40 | 70 | 100 =>
  count <= 3 ? 10 : count <= 6 ? 40 : count <= 10 ? 70 : 100

const resolveFoodIconName = (name: string, explicitIcon?: string) => {
  if (explicitIcon) return explicitIcon
  const words = name.toLowerCase().trim().split(/[^a-z]+/).filter(Boolean)
  if (words.includes('garlic')) return 'garlic'
  if (words.some((word) => ['oats', 'oatmeal', 'wheat', 'barley', 'grains'].includes(word))) return 'grains'
  if (words.includes('honey')) return 'honey'
  if (words.includes('oil')) return 'oil'
  if (words.includes('rice')) return 'rice'
  return undefined
}

const createEmptyManualDraft = (): ManualItemDraft => ({
  draftId: crypto.randomUUID(),
  name: '',
  selectedFoodName: null,
  group: null,
  quantity: 1,
  unit: 'items',
  storage: 'fridge',
  boughtOn: todayISO(),
  opened: false,
  goodForDays: 7,
  showMoreDetails: window.innerWidth >= 768,
})

const foodItems: FoodItem[] = [
  {
    name: 'leftover pasta',
    days: '1 day',
    status: 'expired',
    tip: 'cool quickly and use within four days.',
    senses: 'discard if slimy or unusually sour.',
    icon: 'pasta',
    wasteLbs: 0.4,
  },
  {
    name: 'chicken thighs',
    days: '2 days',
    status: 'expired',
    tip: 'keep sealed on the lowest shelf.',
    senses: 'fresh smells mild and feels firm.',
    icon: 'drumstick',
  },
  {
    name: 'shrimp',
    days: '3 days',
    status: 'expired',
    tip: 'keep sealed on ice in the coldest spot.',
    senses: 'fresh shrimp smell clean and feel firm.',
    icon: 'shrimp',
  },
  {
    name: 'strawberries',
    days: '1 day',
    status: 'soon',
    tip: 'keep dry and wash only before eating.',
    senses: 'fresh berries smell sweet and stay bright.',
    icon: 'strawberry',
  },
  {
    name: 'spinach',
    days: '2 days',
    status: 'soon',
    tip: 'add a dry paper towel to the bag.',
    senses: 'fresh leaves are crisp with no sour smell.',
    icon: 'spinach',
  },
  {
    name: 'salmon',
    days: '2 days',
    status: 'soon',
    tip: 'keep tightly wrapped on the lowest shelf.',
    senses: 'fresh salmon smells mild and looks glossy.',
    icon: 'fish',
  },
  {
    name: 'bananas',
    days: '3 days',
    status: 'fresh',
    tip: 'keep on the counter away from other fruit.',
    senses: 'good bananas smell sweet with firm skins.',
    icon: 'banana',
  },
  {
    name: 'avocado',
    days: '4 days',
    status: 'fresh',
    tip: 'refrigerate once it feels slightly soft.',
    senses: 'ripe avocado yields gently without mushiness.',
    icon: 'avocado',
  },
  {
    name: 'bread',
    days: '5 days',
    status: 'fresh',
    tip: 'keep sealed or freeze half the loaf.',
    senses: 'fresh bread smells warm with no visible mold.',
    icon: 'bread',
  },
  {
    name: 'oat milk',
    days: '6 days',
    status: 'fresh',
    tip: 'store in the coldest part, not the door.',
    senses: 'fresh oat milk smells neutral and pours smooth.',
    icon: 'milk-carton',
  },
  {
    name: 'broccoli',
    days: '6 days',
    status: 'fresh',
    tip: 'keep loosely wrapped in the crisper.',
    senses: 'fresh broccoli is firm with tight florets.',
    icon: 'broccoli',
  },
  {
    name: 'butter',
    days: '14 days',
    status: 'fresh',
    tip: 'keep covered away from strong-smelling foods.',
    senses: 'fresh butter smells clean and looks even.',
    icon: 'butter',
  },
]

const recipes: Recipe[] = [
  {
    id: 'chicken-spinach-pasta',
    name: 'chicken and spinach pasta',
    ingredients: ['chicken thighs', 'spinach', 'leftover pasta', 'garlic', 'olive oil'],
    minutes: 25,
    dish: 'pot',
    cookTool: 'pot',
    heat: 'medium',
    servings: 2,
    steps: [
      { phase: 'prep', text: 'Slice the chicken and chop the garlic.' },
      { phase: 'cook', text: 'Cook chicken, garlic, and spinach, then fold in the pasta.', timedMinutes: 15 },
      { phase: 'serve', text: 'Divide between plates and finish with olive oil.' },
    ],
  },
  {
    id: 'strawberry-yogurt-bowl',
    name: 'strawberry yogurt bowl',
    ingredients: ['strawberries', 'greek yogurt', 'oats', 'honey'],
    minutes: 5,
    dish: 'bowl',
    cookTool: 'pot',
    heat: 'none',
    servings: 2,
    steps: [
      { phase: 'prep', text: 'Slice the strawberries.' },
      { phase: 'cook', text: 'Whisk the yogurt and honey until smooth.', whisk: true },
      { phase: 'serve', text: 'Spoon into bowls and top with strawberries and oats.' },
    ],
  },
  {
    id: 'garlic-spinach-omelette',
    name: 'garlic spinach omelette',
    ingredients: ['spinach', 'eggs', 'garlic', 'butter'],
    minutes: 10,
    dish: 'pan',
    cookTool: 'pan',
    heat: 'medium',
    servings: 2,
    steps: [
      { phase: 'prep', text: 'Whisk the eggs and chop the garlic.', whisk: true },
      { phase: 'cook', text: 'Wilt spinach and garlic, add eggs, and cook until set.', timedMinutes: 6 },
      { phase: 'serve', text: 'Fold the omelette and slide onto plates.' },
    ],
  },
  {
    id: 'salmon-rice-bowl',
    name: 'salmon rice bowl',
    ingredients: ['salmon', 'rice', 'spinach', 'soy sauce'],
    minutes: 20,
    dish: 'bowl',
    cookTool: 'pan',
    heat: 'medium',
    servings: 2,
    steps: [
      { phase: 'prep', text: 'Pat the salmon dry and portion the spinach.' },
      { phase: 'cook', text: 'Cook the salmon and wilt the spinach while the rice warms.', timedMinutes: 12 },
      { phase: 'serve', text: 'Build the bowls and finish with soy sauce.' },
    ],
  },
  {
    id: 'banana-oat-pancakes',
    name: 'banana oat pancakes',
    ingredients: ['bananas', 'oats', 'eggs', 'butter'],
    minutes: 20,
    dish: 'pan',
    cookTool: 'pan',
    heat: 'medium',
    servings: 2,
    steps: [
      { phase: 'prep', text: 'Mash the bananas, then whisk with eggs and oats.', whisk: true },
      { phase: 'cook', text: 'Cook small pancakes in a buttered pan.', timedMinutes: 12 },
      { phase: 'serve', text: 'Stack the pancakes and serve warm.' },
    ],
  },
]

const statusLabel: Record<FoodStatus, string> = {
  fresh: 'fresh',
  soon: 'use soon',
  expired: 'expired',
}

function StatusTag({ status }: { status: FoodStatus }) {
  return <span className={`status-tag status-tag--${status}`}>{statusLabel[status]}</span>
}

function FixedTag({ children, className = '' }: { children: React.ReactNode; className?: string }) {
  return <span className={`status-tag ${className}`}>{children}</span>
}

function RecipeDrawing({ name, className = '' }: { name: string; className?: string }) {
  return (
    <img
      className={`recipe-drawing ${className}`}
      src={`/illustrations/recipes/${name}.png`}
      alt=""
      aria-hidden="true"
    />
  )
}

function timingFromDays(status: FoodStatus, days: string) {
  if (days === 'today') return 'today'
  return status === 'expired' ? `${days} ago` : days
}

function statusFromGoodFor(days: number): FoodStatus {
  return days <= 0 ? 'expired' : days <= 2 ? 'soon' : 'fresh'
}

function timingFromGoodFor(days: number) {
  if (days === 0) return 'today'
  const amount = Math.abs(days)
  const value = `${amount} ${amount === 1 ? 'day' : 'days'}`
  return days < 0 ? `${value} ago` : value
}

function Artwork({ name, className = '' }: { name: string; className?: string }) {
  if (name.startsWith('fullness-')) {
    return (
      <picture>
        <source media="(max-width: 767px)" srcSet={`/illustrations/trimmed/${name}.png`} />
        <img className={className} src={`/illustrations/${name}.png`} alt="" aria-hidden="true" />
      </picture>
    )
  }

  const source = name.startsWith('fullness-')
    ? `/illustrations/${name}.png`
    : `/illustrations/trimmed/${name}.png`

  return (
    <img
      className={className}
      src={source}
      alt=""
      aria-hidden="true"
      onError={(event) => {
        event.currentTarget.style.visibility = 'hidden'
      }}
    />
  )
}

function FoodIcon({
  name,
  icon,
  className = '',
}: {
  name: string
  icon?: string
  className?: string
}) {
  const resolvedIcon = resolveFoodIconName(name, icon)
  if (resolvedIcon) return <Artwork name={resolvedIcon} className={className} />
  const letter = name.trim().charAt(0).toLowerCase() || '?'
  return <span className={`food-letter-placeholder ${className}`} aria-hidden="true">{letter}</span>
}

function Leekly({
  scene = false,
  variant,
  className = '',
}: {
  scene?: boolean
  variant?: 'point' | 'photo'
  className?: string
}) {
  const fileName = variant === 'point' ? 'leekly-point' : variant === 'photo' ? 'photoleek' : scene ? 'leekly-fridge' : 'leekly'

  return (
    <img
      className={className}
      src={`/illustrations/mascot/${fileName}.png`}
      alt=""
      aria-hidden="true"
    />
  )
}

function EmptyState({ message }: { message: string }) {
  return (
    <div className="empty-state">
      <Leekly scene className="empty-state-art" />
      <p>{message}</p>
    </div>
  )
}

function Header({
  screen,
  onNavigate,
}: {
  screen: Screen
  onNavigate: (screen: Screen) => void
}) {
  const cameraInputRef = useRef<HTMLInputElement>(null)
  const pageTitle: Record<Screen, string> = {
    fridge: 'my fridge',
    recipes: 'recipes',
    add: 'scan',
    stats: 'stats',
    friends: 'friends',
  }

  return (
    <header className="topbar">
      <button className="brand" onClick={() => onNavigate('fridge')} aria-label="Freshy fridge">
        <img
          className="logo-mark"
          src="/brand/fridge-logo.png"
          alt=""
          aria-hidden="true"
        />
        <span>freshy</span>
      </button>
      <span className="mobile-page-title">{pageTitle[screen]}</span>
      <nav aria-label="Primary navigation">
        <button
          className={`nav-link nav-fridge ${screen === 'fridge' ? 'active' : ''}`}
          onClick={() => onNavigate('fridge')}
        >
          fridge
        </button>
        <button
          className={`nav-link nav-recipes ${screen === 'recipes' ? 'active' : ''}`}
          onClick={() => onNavigate('recipes')}
        >
          recipes
        </button>
        <span className="nav-camera-spacer" aria-hidden="true" />
        <button
          className={`nav-link nav-stats ${screen === 'stats' ? 'active' : ''}`}
          onClick={() => onNavigate('stats')}
        >
          stats
        </button>
        <button
          className={`nav-link nav-friends ${screen === 'friends' ? 'active' : ''}`}
          onClick={() => onNavigate('friends')}
        >
          friends
        </button>
        <button
          className="camera-tab"
          aria-label="Scan a receipt"
          onClick={() => {
            onNavigate('add')
            cameraInputRef.current?.click()
          }}
        >
          <svg viewBox="0 0 32 26" aria-hidden="true">
            <path d="M3 7.5h6l2.2-3h9.4l2.3 3H29v16H3z" />
            <path d="M11 15.4c0-3 2.2-5.3 5.1-5.3s5.1 2.3 5.1 5.3-2.2 5.2-5.1 5.2-5.1-2.2-5.1-5.2z" />
          </svg>
        </button>
        <input
          ref={cameraInputRef}
          className="camera-tab-input"
          type="file"
          accept="image/*"
          capture="environment"
          onChange={(event) => {
            const file = event.target.files?.[0]
            if (file) window.dispatchEvent(new CustomEvent('freshy-camera-file', { detail: file }))
            event.currentTarget.value = ''
          }}
        />
      </nav>
    </header>
  )
}

function UseSoonSuggestions({ items }: { items: FoodItem[] }) {
  const [checked, setChecked] = useState<string[]>([])
  const soonItems = items.filter((item) => item.status === 'soon').slice(0, 3)
  const dateLabel = new Intl.DateTimeFormat('en-US', {
    weekday: 'long',
    month: 'long',
    day: 'numeric',
  }).format(new Date()).toLowerCase()
  const taskCopy: Record<string, [string, string, string]> = {
    'chicken thighs': ['cook chicken thighs', 'try with spinach tonight', 'try with spinach'],
    strawberries: ['snack on strawberries', 'before tomorrow morning', 'before tomorrow morning'],
    spinach: ['use up spinach', 'toss into dinner', 'toss into dinner'],
    salmon: ['cook the salmon', 'make it the center of dinner', 'make it for dinner'],
  }

  const toggle = (key: string) => {
    setChecked((current) =>
      current.includes(key) ? current.filter((item) => item !== key) : [...current, key],
    )
  }

  return (
    <section className="fridge-suggestions" aria-labelledby="use-soon-heading">
      <div className="suggestions-intro">
        <div>
          <p className="eyebrow">{dateLabel}</p>
          <h2 id="use-soon-heading">use soon.</h2>
          <p className="hero-subtitle">three small things to save today.</p>
        </div>
        <Leekly scene className="suggestions-mascot" />
      </div>

      {soonItems.length > 0 ? (
        <div className="daily-list suggestions-list" aria-label="Use soon list">
        {soonItems.map((item, index) => {
          const key = foodKey(item)
          const [title, note, mobileNote] = taskCopy[item.name] ?? [
            `use up ${item.name}`,
            `within ${item.days}`,
            `within ${item.days}`,
          ]
          const isChecked = checked.includes(key)
          return (
            <label className={`daily-task ${isChecked ? 'is-checked' : ''}`} key={key}>
              <input type="checkbox" checked={isChecked} onChange={() => toggle(key)} />
              <span className="check-hit" aria-hidden="true">
                <span className="large-check">
                  {isChecked ? '✓' : ''}
                </span>
              </span>
              <span className="task-number">0{index + 1}</span>
              <FoodIcon name={item.name} icon={item.icon} className="task-icon" />
              <span className="task-copy">
                <strong>{title}</strong>
                <small>
                  <span className="desktop-task-note">{note}</span>
                  <span className="mobile-task-note">{mobileNote}</span>
                </small>
              </span>
            </label>
          )
        })}
        </div>
      ) : (
        <div className="suggestions-empty">
          <Leekly className="suggestions-empty-leek" />
          <p>nothing to save today.</p>
        </div>
      )}
    </section>
  )
}

function FoodCard({
  item,
  expanded,
  filteredOut = false,
  highlighted = false,
  onExpand,
  onReviewExpired,
}: {
  item: FoodItem
  expanded: boolean
  filteredOut?: boolean
  highlighted?: boolean
  onExpand: () => void
  onReviewExpired: (item: FoodItem) => void
}) {
  const previousStatus = useRef(item.status)
  const [statusTransition, setStatusTransition] = useState<'expiring' | 'restoring' | null>(null)

  useEffect(() => {
    const previous = previousStatus.current
    previousStatus.current = item.status
    if (previous === item.status) return
    const transition = item.status === 'expired' ? 'expiring' : previous === 'expired' ? 'restoring' : null
    if (!transition) return
    setStatusTransition(transition)
    const timer = window.setTimeout(() => setStatusTransition(null), 400)
    return () => window.clearTimeout(timer)
  }, [item.status])

  return (
    <article
      className={`food-card food-card--${item.status} ${item.status === 'expired' ? 'expired-surface' : ''} ${statusTransition ? `is-${statusTransition}` : ''} ${expanded ? 'is-expanded' : ''} ${filteredOut ? 'is-filtered-out' : ''} ${highlighted ? 'is-newly-added' : ''}`}
      onMouseEnter={() => {
        if (window.matchMedia('(min-width: 768px)').matches) onExpand()
      }}
    >
      <button
        className="card-summary"
        onClick={() => item.deferred ? onReviewExpired(item) : onExpand()}
        aria-expanded={expanded}
      >
        <span className="food-icon-slot">
          <FoodIcon name={item.name} icon={item.icon} className="food-icon" />
        </span>
        <span className="card-info">
          <span className="card-title">{item.name}</span>
          <span className="card-meta">
            <StatusTag status={item.status} />
            <span className="status-timing">{timingFromDays(item.status, item.days)}</span>
            {item.extended && <span className="extended-tag">extended</span>}
            {item.deferred && <span className="check-in-tag">check in</span>}
          </span>
        </span>
        <span className="expand-mark">{expanded ? '−' : '+'}</span>
      </button>
      <div className="card-details">
        <div className="detail-main">
          <div className="illustration-slot">
            <FoodIcon name={item.name} icon={item.icon} className="expanded-food-icon" />
          </div>
          <div className="detail-copy">
            <div className="detail-line">
              <span>store</span>
              <p>{item.tip}</p>
            </div>
            <div className="detail-line">
              <span>check</span>
              <p>{item.senses}</p>
            </div>
          </div>
        </div>
        <button
          className="used-button"
          onClick={item.status === 'expired' ? () => onReviewExpired(item) : undefined}
        >
          {item.status === 'expired' ? 'review expired item' : 'mark as used'}
        </button>
      </div>
    </article>
  )
}

function FridgeScreen({
  items,
  filter,
  highlightedItemIds,
  onFilterChange,
  onAddItem,
  onReviewExpired,
}: {
  items?: FoodItem[]
  filter: FridgeFilter
  highlightedItemIds: string[]
  onFilterChange: (filter: FridgeFilter) => void
  onAddItem: () => void
  onReviewExpired: (item: FoodItem) => void
}) {
  const fridgeItems = Array.isArray(items) ? items : foodItems
  const [expanded, setExpanded] = useState<string | null>(null)
  const [filterCompact, setFilterCompact] = useState(false)
  const filterSentinelRef = useRef<HTMLDivElement>(null)
  const stages = {
    10: {
      label: 'nearly empty.',
      stocked: 'fruit, grains',
      empty: 'vegetables, protein, dairy, frozen foods',
    },
    40: {
      label: 'getting low.',
      stocked: 'fruit, protein, grains',
      empty: 'vegetables, dairy, frozen foods',
    },
    70: {
      label: 'well stocked.',
      stocked: 'vegetables, fruit, protein, dairy, grains',
      empty: 'frozen foods',
    },
    100: {
      label: 'fully stocked.',
      stocked: 'vegetables, fruit, protein, dairy, grains',
      empty: 'frozen foods',
    },
  } as const
  const derivedFullness = countStage(fridgeItems.length)
  const [fullness, setFullness] = useState<keyof typeof stages>(derivedFullness)
  const [showGroups, setShowGroups] = useState(false)
  const fullnessPreviewRef = useRef<HTMLDivElement>(null)
  const statusCounts = fridgeItems.reduce(
    (counts, item) => ({ ...counts, [item.status]: counts[item.status] + 1 }),
    { expired: 0, soon: 0, fresh: 0 },
  )
  const expiredGroups = Array.from(new Set(
    fridgeItems
      .filter((item) => item.status === 'expired')
      .map((item) => item.group ?? knownFoods.find((food) => food.icon === item.icon)?.group ?? 'other'),
  )).map((group) => group === 'dairy-eggs' ? 'dairy and eggs' : group)
  const filterOptions: Array<{ value: FridgeFilter; label: string; count: number }> = [
    { value: 'all', label: 'all', count: fridgeItems.length },
    { value: 'expired', label: 'expired', count: statusCounts.expired },
    { value: 'soon', label: 'use soon', count: statusCounts.soon },
    { value: 'fresh', label: 'fresh', count: statusCounts.fresh },
  ]
  const visibleCount = filter === 'all' ? fridgeItems.length : statusCounts[filter]
  const activeLabel = filterOptions.find((option) => option.value === filter)?.label ?? 'items'
  const emptyMessages: Record<FoodStatus, string> = {
    expired: 'all clear!',
    soon: 'nothing close to expiring.',
    fresh: 'time to restock.',
  }
  const changeFilter = (nextFilter: FridgeFilter) => {
    setExpanded(null)
    onFilterChange(nextFilter === filter ? 'all' : nextFilter)
  }

  useEffect(() => {
    setFullness(derivedFullness)
  }, [derivedFullness])

  useEffect(() => {
    if (!showGroups) return

    const closeOutside = (event: PointerEvent) => {
      if (window.innerWidth >= 768) return
      const target = event.target as Node
      if (fullnessPreviewRef.current?.contains(target)) return
      if ((target as Element).closest?.('.stage-toggle')) return
      setShowGroups(false)
    }

    document.addEventListener('pointerdown', closeOutside)
    return () => document.removeEventListener('pointerdown', closeOutside)
  }, [showGroups])

  useEffect(() => {
    const sentinel = filterSentinelRef.current
    const scroller = sentinel?.closest('.app-shell')
    if (!sentinel || !scroller) return

    const updateCompactState = () => {
      if (window.innerWidth >= 768) {
        setFilterCompact(false)
        return
      }
      const topbar = scroller.querySelector<HTMLElement>('.topbar')
      const stickyTop = scroller.getBoundingClientRect().top + (topbar?.offsetHeight ?? 0)
      setFilterCompact(sentinel.getBoundingClientRect().top <= stickyTop)
    }

    updateCompactState()
    scroller.addEventListener('scroll', updateCompactState, { passive: true })
    window.addEventListener('resize', updateCompactState)
    return () => {
      scroller.removeEventListener('scroll', updateCompactState)
      window.removeEventListener('resize', updateCompactState)
    }
  }, [])

  return (
    <main className="fridge-screen">
      <section className="page-heading">
        <div
          ref={fullnessPreviewRef}
          className="fullness-preview"
          onMouseEnter={() => {
            if (window.innerWidth >= 768) setShowGroups(true)
          }}
          onMouseLeave={() => {
            if (window.innerWidth >= 768) setShowGroups(false)
          }}
        >
          <button
            type="button"
            className="fullness-art"
            aria-label={`Show food groups for ${fullness}% stocked`}
            aria-expanded={showGroups}
            onClick={() => setShowGroups((value) => !value)}
          >
            {([10, 40, 70, 100] as const).map((stage) => (
              <img
                key={stage}
                className={`fullness-stage ${fullness === stage ? 'is-visible' : ''}`}
                src={`/illustrations/fullness/stage-${stage}.png`}
                alt=""
                aria-hidden="true"
              />
            ))}
          </button>
          {showGroups && (
            <div className="stock-tooltip" onClick={() => setShowGroups(false)}>
              <p><strong>stocked</strong><span>{stages[fullness].stocked}</span></p>
              <p><strong>empty</strong><span>{stages[fullness].empty || 'nothing empty.'}</span></p>
              {expiredGroups.length > 0 && (
                <p className="expired-groups"><i aria-hidden="true" /><strong>expired</strong><span>{expiredGroups.join(', ')}</span></p>
              )}
              <small className="stock-tooltip-hint">tap to close</small>
            </div>
          )}
        </div>
        <div className="fridge-title">
          <div className="fridge-title-copy">
            <p className="eyebrow">sorted by urgency</p>
            <h1>everything in my fridge.</h1>
            <Leekly variant="point" className="mobile-fridge-leek" />
          </div>
          <p className="stock-label">{stages[fullness].label}</p>
          <div className="stage-toggle" aria-label="Prototype fullness preview">
            {([10, 40, 70, 100] as const).map((stage) => (
              <button
                type="button"
                key={stage}
                className={fullness === stage ? 'active' : ''}
                aria-pressed={fullness === stage}
                onClick={() => setFullness(stage)}
              >
                {stage}
              </button>
            ))}
          </div>
        </div>
      </section>
      <div className="fridge-list-stage">
        <div className="fridge-list-main">
          <div className="fridge-count-header">
            <div className="fridge-count-title">
              <div className="fridge-count-copy">
                <strong>{filter === 'all' ? `${fridgeItems.length} items` : `${visibleCount} ${activeLabel}`}</strong>
                {filter !== 'all' && (
                  <button type="button" onClick={() => changeFilter('all')}>clear</button>
                )}
              </div>
              <button type="button" className="fridge-add-item" onClick={onAddItem}>+ add item</button>
            </div>
            <div className="filter-sticky-sentinel" ref={filterSentinelRef} aria-hidden="true" />
            <div className={`fridge-filter-tabs ${filterCompact ? 'is-compact' : ''}`} role="group" aria-label="Filter fridge by status">
              {filterOptions.map((option) => {
                const selected = filter === option.value
                const disabled = option.value !== 'all' && option.count === 0
                return (
                  <button
                    type="button"
                    key={option.value}
                    className={selected ? 'is-selected' : ''}
                    disabled={disabled}
                    aria-pressed={selected}
                    onClick={() => changeFilter(option.value)}
                  >
                    <span className="filter-tab-label">{option.label}</span>
                    <span className="filter-tab-meta">
                      {option.value === 'all' ? (
                        <span className="filter-marker-spacer" aria-hidden="true" />
                      ) : (
                        <span className={`filter-marker filter-marker--${option.value}`} aria-hidden="true" />
                      )}
                      <span className="filter-tab-count">{option.count}</span>
                    </span>
                  </button>
                )
              })}
            </div>
          </div>
          <div className="food-list">
            {fridgeItems.map((item) => (
              <FoodCard
                key={foodKey(item)}
                item={item}
                expanded={expanded === foodKey(item)}
                filteredOut={filter !== 'all' && item.status !== filter}
                highlighted={highlightedItemIds.includes(foodKey(item))}
                onExpand={() => setExpanded(expanded === foodKey(item) ? null : foodKey(item))}
                onReviewExpired={onReviewExpired}
              />
            ))}
            {filter !== 'all' && visibleCount === 0 && (
              <div className="filter-empty-state">
                <Leekly className="filter-empty-leek" />
                <strong>nothing here.</strong>
                <p>{emptyMessages[filter]}</p>
              </div>
            )}
          </div>
        </div>
        <aside className="fridge-leek-gutter" aria-label="Fridge status">
          <div className={`fridge-status-bubble ${statusCounts.expired + statusCounts.soon === 0 ? 'is-all-fresh' : ''}`}>
            {statusCounts.expired + statusCounts.soon === 0
              ? 'all fresh!'
              : (
                <>
                  {statusCounts.expired > 0 && <span className="expired-count">{statusCounts.expired} expired</span>}
                  {statusCounts.expired > 0 && statusCounts.soon > 0 && ', '}
                  {statusCounts.soon > 0 && `${statusCounts.soon} use soon`}
                </>
              )}
          </div>
          <Leekly variant="point" className="leek-point fridge-leek-point" />
        </aside>
      </div>
      {fridgeItems.length === 0 && <EmptyState message="your fridge is ready for something fresh." />}
      <UseSoonSuggestions items={fridgeItems} />
    </main>
  )
}

function LegacyManualEntryCard({
  onCancel,
  onSubmit,
}: {
  onCancel: () => void
  onSubmit: (item: ManualItemInput) => void
}) {
  const [name, setName] = useState('')
  const [selectedFood, setSelectedFood] = useState<KnownFood | null>(null)
  const [group, setGroup] = useState<FoodGroup | null>(null)
  const [quantity, setQuantity] = useState(1)
  const [unit, setUnit] = useState<FoodUnit>('items')
  const [storage, setStorage] = useState<StorageLocation>('fridge')
  const [boughtOn, setBoughtOn] = useState(todayISO())
  const [opened, setOpened] = useState(false)
  const [goodForDays, setGoodForDays] = useState(7)
  const [suggestionsOpen, setSuggestionsOpen] = useState(false)
  const [activeSuggestion, setActiveSuggestion] = useState(0)
  const [showMoreDetails, setShowMoreDetails] = useState(() => window.innerWidth >= 768)
  const cardRef = useRef<HTMLDivElement>(null)
  const normalizedName = name.trim().toLowerCase()
  const suggestions = normalizedName
    ? knownFoods
        .filter((food) => food.name.includes(normalizedName))
        .sort((a, b) => Number(!a.name.startsWith(normalizedName)) - Number(!b.name.startsWith(normalizedName)))
    : knownFoods
  const isValid = name.trim().length > 0 && goodForDays > 0

  const selectFood = (food: KnownFood) => {
    setName(food.name)
    setSelectedFood(food)
    setGroup(food.group)
    setUnit(food.unit)
    setGoodForDays(food.goodForDays)
    setSuggestionsOpen(false)
  }

  useEffect(() => {
    const closeSuggestions = (event: PointerEvent) => {
      if (!cardRef.current?.contains(event.target as Node)) setSuggestionsOpen(false)
    }
    document.addEventListener('pointerdown', closeSuggestions)
    return () => document.removeEventListener('pointerdown', closeSuggestions)
  }, [])

  const submit = () => {
    if (!isValid) return
    onSubmit({
      name: name.trim().toLowerCase(),
      icon: selectedFood?.icon,
      group: group ?? 'other',
      quantity,
      unit,
      storage,
      boughtOn,
      opened,
      goodForDays,
      tip: selectedFood?.tip ?? 'try storing the stems in a jar of water.',
      senses: selectedFood?.senses ?? 'trust your eyes and nose before using it.',
    })
  }

  return (
    <div
      className="manual-entry-card"
      ref={cardRef}
      onFocusCapture={(event) => {
        window.setTimeout(() => event.target instanceof HTMLElement && event.target.scrollIntoView({ block: 'nearest' }), 120)
      }}
    >
      <div className="manual-entry-header">
        <button type="button" className="manual-back" onClick={onCancel}>← back</button>
        <div className="manual-title-row">
          <h1>add an item</h1>
          <div className="manual-preview">
            <FoodIcon name={name} icon={selectedFood?.icon} className="manual-preview-art" />
          </div>
        </div>
      </div>
      <div className={`manual-entry-body ${showMoreDetails ? 'has-more-details' : ''}`}>
        <label className="manual-field manual-name-field">
          <span>food name</span>
          <input
            role="combobox"
            aria-expanded={suggestionsOpen}
            aria-controls="food-suggestions"
            aria-autocomplete="list"
            value={name}
            autoComplete="off"
            onFocus={() => setSuggestionsOpen(true)}
            onKeyDown={(event) => {
              if (!suggestionsOpen || suggestions.length === 0) return
              if (event.key === 'ArrowDown') {
                event.preventDefault()
                setActiveSuggestion((value) => (value + 1) % suggestions.length)
              } else if (event.key === 'ArrowUp') {
                event.preventDefault()
                setActiveSuggestion((value) => (value - 1 + suggestions.length) % suggestions.length)
              } else if (event.key === 'Enter') {
                event.preventDefault()
                selectFood(suggestions[activeSuggestion] ?? suggestions[0])
              } else if (event.key === 'Escape') {
                setSuggestionsOpen(false)
              }
            }}
            onChange={(event) => {
              const nextName = event.target.value
              setName(nextName)
              setActiveSuggestion(0)
              setSuggestionsOpen(true)
              const exact = knownFoods.find((food) => food.name === nextName.trim().toLowerCase()) ?? null
              if (exact) selectFood(exact)
              else setSelectedFood(null)
            }}
          />
          {suggestionsOpen && suggestions.length > 0 && (
            <div className="food-suggestions" id="food-suggestions" role="listbox">
              {suggestions.map((food, index) => (
                <button
                  type="button"
                  role="option"
                  aria-selected={index === activeSuggestion}
                  className={index === activeSuggestion ? 'is-active' : ''}
                  key={food.name}
                  onPointerDown={(event) => event.preventDefault()}
                  onClick={() => selectFood(food)}
                >
                  <FoodIcon name={food.name} icon={food.icon} className="suggestion-food-icon" />
                  <span>{food.name}</span>
                </button>
              ))}
            </div>
          )}
        </label>

        <fieldset className="manual-field manual-chip-field">
          <legend>food group</legend>
          <div>
            {([
              ['vegetables', 'vegetables'],
              ['fruit', 'fruit'],
              ['protein', 'protein'],
              ['dairy-eggs', 'dairy and eggs'],
              ['grains', 'grains'],
              ['other', 'other'],
            ] as Array<[FoodGroup, string]>).map(([value, label]) => (
              <button type="button" className={group === value ? 'is-selected' : ''} key={value} onClick={() => setGroup(value)}>{label}</button>
            ))}
          </div>
        </fieldset>

        <div className="manual-paired-row manual-quantity-row">
          <div className="manual-field">
            <span>quantity</span>
            <div className="manual-stepper">
              <button type="button" onClick={() => setQuantity((value) => Math.max(0.1, Number((value - 1).toFixed(1))))}>−</button>
              <input type="number" min="0.1" step={unit === 'lbs' ? '0.1' : '1'} value={quantity} onChange={(event) => setQuantity(Math.max(0.1, Number(event.target.value) || 1))} />
              <button type="button" onClick={() => setQuantity((value) => Number((value + 1).toFixed(1)))}>+</button>
            </div>
          </div>
          <label className="manual-field">
            <span>unit</span>
            <select value={unit} onChange={(event) => setUnit(event.target.value as FoodUnit)}>
              {(['items', 'lbs', 'bag', 'carton', 'container'] as FoodUnit[]).map((value) => <option key={value}>{value}</option>)}
            </select>
          </label>
        </div>

        {!showMoreDetails && (
          <div className="manual-field good-for-field good-for-collapsed">
            <span>good for</span>
            <div className="manual-stepper good-for-stepper">
              <button type="button" onClick={() => setGoodForDays((value) => Math.max(1, value - 1))}>−</button>
              <input value={`${goodForDays} ${goodForDays === 1 ? 'day' : 'days'}`} onFocus={(event) => event.currentTarget.select()} onChange={(event) => {
                const value = Number.parseInt(event.target.value, 10)
                if (Number.isFinite(value)) setGoodForDays(Math.max(1, Math.min(365, value)))
              }} />
              <button type="button" onClick={() => setGoodForDays((value) => Math.min(365, value + 1))}>+</button>
            </div>
            <small>our estimate. change it if you know better.</small>
          </div>
        )}

        <button type="button" className="manual-more-details" onClick={() => setShowMoreDetails((value) => !value)}>
          {showMoreDetails ? 'less details −' : 'more details +'}
        </button>

        {showMoreDetails && (
          <div className="manual-progressive-fields">
            <div className="manual-paired-row">
              <fieldset className="manual-field manual-toggle-field">
                <legend>where it's stored</legend>
                <div>
                  {(['fridge', 'freezer'] as StorageLocation[]).map((value) => (
                    <button type="button" className={storage === value ? 'is-selected' : ''} key={value} onClick={() => setStorage(value)}>{value}</button>
                  ))}
                </div>
              </fieldset>
              <fieldset className="manual-field manual-toggle-field">
                <legend>opened already?</legend>
                <div>
                  <button type="button" className={!opened ? 'is-selected' : ''} onClick={() => setOpened(false)}>no</button>
                  <button type="button" className={opened ? 'is-selected' : ''} onClick={() => setOpened(true)}>yes</button>
                </div>
              </fieldset>
            </div>
            <div className="manual-paired-row">
              <label className="manual-field">
                <span>bought on</span>
                <input type="date" max={todayISO()} value={boughtOn} onChange={(event) => setBoughtOn(event.target.value)} />
              </label>
              <div className="manual-field good-for-field good-for-expanded">
                <span>good for</span>
                <div className="manual-stepper good-for-stepper">
                  <button type="button" onClick={() => setGoodForDays((value) => Math.max(1, value - 1))}>−</button>
                  <input value={`${goodForDays} ${goodForDays === 1 ? 'day' : 'days'}`} onFocus={(event) => event.currentTarget.select()} onChange={(event) => {
                    const value = Number.parseInt(event.target.value, 10)
                    if (Number.isFinite(value)) setGoodForDays(Math.max(1, Math.min(365, value)))
                  }} />
                  <button type="button" onClick={() => setGoodForDays((value) => Math.min(365, value + 1))}>+</button>
                </div>
                <small>our estimate. change it if you know better.</small>
              </div>
            </div>
          </div>
        )}

        {name.trim() && !selectedFood && (
          <div className="manual-unknown-tip">
            <span>unknown food tip</span>
            <strong>{name.trim()}</strong>
            <p>try storing the stems in a jar of water.</p>
          </div>
        )}
      </div>
      <div className="manual-entry-actions">
        <button type="button" className="manual-cancel" onClick={onCancel}>cancel</button>
        <button type="button" className="manual-submit" disabled={!isValid} onClick={submit}>add to fridge</button>
      </div>
    </div>
  )
}

function ManualItemSection({
  draft,
  index,
  onChange,
  onRemove,
}: {
  draft: ManualItemDraft
  index: number
  onChange: (draft: ManualItemDraft) => void
  onRemove?: () => void
}) {
  const [suggestionsOpen, setSuggestionsOpen] = useState(false)
  const [activeSuggestion, setActiveSuggestion] = useState(0)
  const normalizedName = draft.name.trim().toLowerCase()
  const selectedFood = knownFoods.find((food) => food.name === draft.selectedFoodName) ?? null
  const suggestions = normalizedName
    ? knownFoods.filter((food) => food.name.includes(normalizedName))
    : knownFoods
  const update = (patch: Partial<ManualItemDraft>) => onChange({ ...draft, ...patch })
  const selectFood = (food: KnownFood) => {
    update({
      name: food.name,
      selectedFoodName: food.name,
      group: food.group,
      unit: food.unit,
      goodForDays: food.goodForDays,
    })
    setSuggestionsOpen(false)
  }

  return (
    <section className={`manual-item-section ${draft.goodForDays <= 0 ? 'expired-surface' : ''}`} data-draft-id={draft.draftId}>
      <div className="manual-item-heading">
        <div className="manual-heading-copy">
          <h1>{index === 0 ? 'add an item' : `item ${index + 1}`}</h1>
          {onRemove && <button type="button" className="manual-remove" onClick={onRemove} aria-label={`Remove item ${index + 1}`}>remove</button>}
          <span className="entry-status-meta">
            <StatusTag status={statusFromGoodFor(draft.goodForDays)} />
            <span className="status-timing">{timingFromGoodFor(draft.goodForDays)}</span>
          </span>
        </div>
        <div className="manual-preview">
          <div className="manual-preview-slot" key={resolveFoodIconName(draft.name, selectedFood?.icon) ?? draft.name.trim().toLowerCase()}>
            {draft.name.trim() ? (
              <FoodIcon name={draft.name} icon={selectedFood?.icon} className="manual-preview-art" />
            ) : (
              <span className="manual-preview-art food-letter-placeholder" aria-hidden="true" />
            )}
          </div>
        </div>
      </div>

      <div className="manual-section-fields">
        <label className="manual-field manual-name-field">
          <span>food name</span>
          <input
            data-manual-name
            role="combobox"
            aria-expanded={suggestionsOpen}
            aria-controls={`food-suggestions-${draft.draftId}`}
            value={draft.name}
            autoComplete="off"
            onFocus={() => setSuggestionsOpen(true)}
            onBlur={() => window.setTimeout(() => setSuggestionsOpen(false), 100)}
            onKeyDown={(event) => {
              if (!suggestionsOpen || suggestions.length === 0) return
              if (event.key === 'ArrowDown') {
                event.preventDefault()
                setActiveSuggestion((value) => (value + 1) % suggestions.length)
              } else if (event.key === 'ArrowUp') {
                event.preventDefault()
                setActiveSuggestion((value) => (value - 1 + suggestions.length) % suggestions.length)
              } else if (event.key === 'Enter') {
                event.preventDefault()
                selectFood(suggestions[activeSuggestion] ?? suggestions[0])
              } else if (event.key === 'Escape') setSuggestionsOpen(false)
            }}
            onChange={(event) => {
              const name = event.target.value
              const exact = knownFoods.find((food) => food.name === name.trim().toLowerCase())
              if (exact) selectFood(exact)
              else {
                update({ name, selectedFoodName: null })
                setSuggestionsOpen(true)
                setActiveSuggestion(0)
              }
            }}
          />
          {suggestionsOpen && suggestions.length > 0 && (
            <div className="food-suggestions" id={`food-suggestions-${draft.draftId}`} role="listbox">
              {suggestions.map((food, suggestionIndex) => (
                <button
                  type="button"
                  role="option"
                  aria-selected={suggestionIndex === activeSuggestion}
                  className={suggestionIndex === activeSuggestion ? 'is-active' : ''}
                  key={food.name}
                  onPointerDown={(event) => event.preventDefault()}
                  onClick={() => selectFood(food)}
                >
                  <FoodIcon name={food.name} icon={food.icon} className="suggestion-food-icon" />
                  <span>{food.name}</span>
                </button>
              ))}
            </div>
          )}
        </label>

        <fieldset className="manual-field manual-chip-field">
          <legend>food group</legend>
          <div>
            {([
              ['vegetables', 'vegetables'], ['fruit', 'fruit'], ['protein', 'protein'],
              ['dairy-eggs', 'dairy and eggs'], ['grains', 'grains'], ['other', 'other'],
            ] as Array<[FoodGroup, string]>).map(([value, label]) => (
              <button type="button" className={draft.group === value ? 'is-selected' : ''} key={value} onClick={() => update({ group: value })}>{label}</button>
            ))}
          </div>
        </fieldset>

        <div className="manual-paired-row manual-quantity-row">
          <div className="manual-field">
            <span>quantity</span>
            <div className="manual-stepper">
              <button type="button" onClick={() => update({ quantity: Math.max(0.1, draft.quantity - 1) })}>−</button>
              <input type="number" min="0.1" value={draft.quantity} onChange={(event) => update({ quantity: Math.max(0.1, Number(event.target.value) || 1) })} />
              <button type="button" onClick={() => update({ quantity: draft.quantity + 1 })}>+</button>
            </div>
          </div>
          <label className="manual-field">
            <span>unit</span>
            <select value={draft.unit} onChange={(event) => update({ unit: event.target.value as FoodUnit })}>
              {(['items', 'lbs', 'bag', 'carton', 'container'] as FoodUnit[]).map((value) => <option key={value}>{value}</option>)}
            </select>
          </label>
        </div>

        <div className="manual-field good-for-field">
          <span>good for</span>
          <div className="manual-stepper good-for-stepper">
            <button type="button" onClick={() => update({ goodForDays: Math.max(-365, draft.goodForDays - 1) })}>−</button>
            <input value={`${draft.goodForDays} ${draft.goodForDays === 1 ? 'day' : 'days'}`} onFocus={(event) => event.currentTarget.select()} onChange={(event) => {
              const value = Number.parseInt(event.target.value, 10)
              if (Number.isFinite(value)) update({ goodForDays: Math.max(-365, Math.min(365, value)) })
            }} />
            <button type="button" onClick={() => update({ goodForDays: Math.min(365, draft.goodForDays + 1) })}>+</button>
          </div>
          <small>our estimate. change it if you know better.</small>
        </div>

        <button type="button" className="manual-more-details" onClick={() => update({ showMoreDetails: !draft.showMoreDetails })}>
          {draft.showMoreDetails ? 'less details −' : 'more details +'}
        </button>

        {draft.showMoreDetails && (
          <div className="manual-progressive-fields">
            <div className="manual-paired-row">
              <fieldset className="manual-field manual-toggle-field">
                <legend>where it's stored</legend>
                <div>{(['fridge', 'freezer'] as StorageLocation[]).map((value) => <button type="button" className={draft.storage === value ? 'is-selected' : ''} key={value} onClick={() => update({ storage: value })}>{value}</button>)}</div>
              </fieldset>
              <fieldset className="manual-field manual-toggle-field">
                <legend>opened already?</legend>
                <div>
                  <button type="button" className={!draft.opened ? 'is-selected' : ''} onClick={() => update({ opened: false })}>no</button>
                  <button type="button" className={draft.opened ? 'is-selected' : ''} onClick={() => update({ opened: true })}>yes</button>
                </div>
              </fieldset>
            </div>
            <label className="manual-field">
              <span>bought on</span>
              <input type="date" max={todayISO()} value={draft.boughtOn} onChange={(event) => update({ boughtOn: event.target.value })} />
            </label>
          </div>
        )}

        {draft.name.trim() && !selectedFood && (
          <div className="manual-unknown-tip">
            <span>unknown food tip</span>
            <strong>{draft.name.trim()}</strong>
            <p>try storing the stems in a jar of water.</p>
          </div>
        )}
      </div>
    </section>
  )
}

function ManualEntryCard({
  onCancel,
  onSubmit,
}: {
  onCancel: () => void
  onSubmit: (items: ManualItemInput[]) => void
}) {
  const [drafts, setDrafts] = useState<ManualItemDraft[]>(() => [createEmptyManualDraft()])
  const cardRef = useRef<HTMLDivElement>(null)
  const lastDraft = drafts[drafts.length - 1]
  const validDraft = (draft: ManualItemDraft) => draft.name.trim().length > 0
  const allValid = drafts.length > 0 && drafts.every(validDraft)

  const appendDraft = () => {
    if (!validDraft(lastDraft)) return
    const next = createEmptyManualDraft()
    setDrafts((current) => [...current, next])
    window.setTimeout(() => {
      const input = cardRef.current?.querySelector<HTMLElement>(`[data-draft-id="${next.draftId}"] [data-manual-name]`)
      input?.scrollIntoView({ block: 'center' })
      input?.focus()
    }, 0)
  }

  const submit = () => {
    if (!allValid) return
    onSubmit(drafts.map((draft) => {
      const food = knownFoods.find((known) => known.name === draft.selectedFoodName)
      return {
        name: draft.name.trim().toLowerCase(),
        icon: resolveFoodIconName(draft.name, food?.icon),
        group: draft.group ?? 'other',
        quantity: draft.quantity,
        unit: draft.unit,
        storage: draft.storage,
        boughtOn: draft.boughtOn,
        opened: draft.opened,
        goodForDays: draft.goodForDays,
        tip: food?.tip ?? 'try storing the stems in a jar of water.',
        senses: food?.senses ?? 'trust your eyes and nose before using it.',
      }
    }))
  }

  return (
    <div className="manual-entry-card manual-entry-card--multi" ref={cardRef} onFocusCapture={(event) => {
      window.setTimeout(() => event.target instanceof HTMLElement && event.target.scrollIntoView({ block: 'nearest' }), 120)
    }}>
      <div className="manual-card-top">
        <button type="button" className="manual-back" onClick={onCancel}>← back</button>
      </div>
      {drafts.map((draft, index) => (
        <ManualItemSection
          key={draft.draftId}
          draft={draft}
          index={index}
          onChange={(next) => setDrafts((current) => current.map((item) => item.draftId === next.draftId ? next : item))}
          onRemove={index === 0 ? undefined : () => setDrafts((current) => current.filter((item) => item.draftId !== draft.draftId))}
        />
      ))}
      <button type="button" className="manual-add-another" disabled={!validDraft(lastDraft)} onClick={appendDraft}>+ add another item</button>
      <div className="manual-entry-actions">
        <button type="button" className="manual-cancel" onClick={onCancel}>cancel</button>
        <button type="button" className="manual-submit" disabled={!allValid} onClick={submit}>add to fridge</button>
      </div>
    </div>
  )
}

function AddScreen({
  onDone,
  onAddItem,
}: {
  onDone: () => void
  onAddItem: (items: ManualItemInput[]) => void
}) {
  const [step, setStep] = useState(1)
  const [manual, setManual] = useState(false)
  const [receipt, setReceipt] = useState<string | null>(null)
  const [reading, setReading] = useState(false)
  const parsedItems: Array<{ name: string; icon?: string }> = [
    { name: 'eggs', icon: 'eggs' },
    { name: 'bananas', icon: 'banana' },
    { name: 'cilantro', icon: 'spinach' },
    { name: 'mystery greens' },
  ]
  const [parsedDays, setParsedDays] = useState([14, 5, 7, 7])

  const updateParsedDays = (index: number, value: number) => {
    setParsedDays((current) =>
      current.map((days, itemIndex) => itemIndex === index ? Math.max(-365, Math.min(365, value)) : days),
    )
  }

  const handleReceipt = (file?: File) => {
    if (file) {
      setReceipt(URL.createObjectURL(file))
      setReading(true)
      window.setTimeout(() => {
        setReading(false)
        setStep(2)
      }, 850)
    }
  }

  useEffect(() => {
    const receiveCameraFile = (event: Event) => {
      handleReceipt((event as CustomEvent<File>).detail)
    }
    window.addEventListener('freshy-camera-file', receiveCameraFile)
    return () => window.removeEventListener('freshy-camera-file', receiveCameraFile)
  }, [])

  return (
    <main className="add-screen">
      {manual && <ManualEntryCard onCancel={() => setManual(false)} onSubmit={onAddItem} />}
      {reading && (
        <section className="receipt-loading">
          <Leekly variant="photo" className="loading-photoleek" />
          <p>reading your receipt...</p>
        </section>
      )}
      {!manual && !reading && step === 1 && (
        <section className="step-panel scan-step">
          <p className="eyebrow">scan receipt</p>
          <h1>show us your receipt.</h1>
          <div className="receipt-options">
            <label className="receipt-choice">
              <input
                type="file"
                accept="image/*"
                capture="environment"
                onChange={(event) => handleReceipt(event.target.files?.[0])}
              />
              <Leekly variant="photo" className="scan-mascot" />
              <span className="camera-choice-copy">
                <strong>take a photo</strong>
              </span>
            </label>
            <label className="receipt-choice upload-choice">
              <input
                type="file"
                accept="image/*,.pdf"
                onChange={(event) => handleReceipt(event.target.files?.[0])}
              />
              <img
                className="file-leek"
                src="/illustrations/mascot/new/file.png"
                alt=""
                aria-hidden="true"
              />
              <span className="file-choice-copy">
                <strong>upload from files</strong>
              </span>
            </label>
          </div>
          <button type="button" className="add-button manual-entry-trigger" onClick={() => setManual(true)}>+ add manually</button>
        </section>
      )}
      {!manual && !reading && step === 2 && (
        <section className="step-panel receipt-step">
          <p className="eyebrow">receipt captured</p>
          <h1>take a quick look.</h1>
          <div className="receipt-preview">
            {receipt && <img src={receipt} alt="Captured receipt preview" />}
            <div>
              <button
                className="outline-button"
                onClick={() => {
                  setReceipt(null)
                  setStep(1)
                }}
              >
                retake
              </button>
              <button className="add-button" onClick={() => setStep(3)}>
                continue
              </button>
            </div>
          </div>
        </section>
      )}
      {!manual && !reading && step === 3 && (
        <section className="step-panel parsed-step">
          <p className="eyebrow">looks like you bought</p>
          <h1>check the list.</h1>
          <div className="parsed-scroll">
            <div className="parsed-list">
              {parsedItems.map((item, index) => (
                <Fragment key={item.name}>
                  <div className={`parsed-row parsed-row--mobile ${parsedDays[index] <= 0 ? 'expired-surface' : ''}`}>
                    <span className="parsed-art-slot">
                      <FoodIcon name={item.name} icon={item.icon} className="parsed-food-art" />
                    </span>
                    <span className="parsed-item-copy">
                      <strong>{item.name}</strong>
                      <span className="entry-status-meta">
                        <StatusTag status={statusFromGoodFor(parsedDays[index])} />
                        <span className="status-timing">{timingFromGoodFor(parsedDays[index])}</span>
                      </span>
                    </span>
                    <span className="days-stepper">
                      <button
                        type="button"
                        aria-label={`Decrease days for ${item.name}`}
                        onClick={() => updateParsedDays(index, parsedDays[index] - 1)}
                      >
                        −
                      </button>
                      <input
                        aria-label={`Days ${item.name} stays good`}
                        value={`${parsedDays[index]} ${parsedDays[index] === 1 ? 'day' : 'days'}`}
                        onFocus={(event) => event.currentTarget.select()}
                        onChange={(event) => {
                          const value = Number.parseInt(event.target.value, 10)
                          if (Number.isFinite(value)) updateParsedDays(index, value)
                        }}
                      />
                      <button
                        type="button"
                        aria-label={`Increase days for ${item.name}`}
                        onClick={() => updateParsedDays(index, parsedDays[index] + 1)}
                      >
                        +
                      </button>
                    </span>
                  </div>
                  <div className={`parsed-row parsed-row--desktop ${parsedDays[index] <= 0 ? 'expired-surface' : ''}`}>
                    <span className="parsed-desktop-name">
                      <FoodIcon name={item.name} icon={item.icon} className="parsed-desktop-art" />
                      <span>{item.name}</span>
                    </span>
                    <span className="entry-status-meta">
                      <StatusTag status={statusFromGoodFor(parsedDays[index])} />
                      <span className="status-timing">{timingFromGoodFor(parsedDays[index])}</span>
                    </span>
                    <label>
                      good for
                      <input
                        value={`${parsedDays[index]} days`}
                        onChange={(event) => {
                          const value = Number.parseInt(event.target.value, 10)
                          if (Number.isFinite(value)) updateParsedDays(index, value)
                        }}
                      />
                    </label>
                  </div>
                </Fragment>
              ))}
            </div>
            <div className="tip-card">
              <span>unknown food tip</span>
              <strong>mystery greens</strong>
              <p>try storing the stems in a jar of water.</p>
            </div>
          </div>
          <button className="add-button mobile-pinned-action" onClick={onDone}>
            add to fridge
          </button>
        </section>
      )}
    </main>
  )
}

function RecipesScreen({ items }: { items: FoodItem[] }) {
  const [selectedKeys, setSelectedKeys] = useState<string[]>([])
  const [expandedRecipeId, setExpandedRecipeId] = useState<string | null>(null)
  const [expandedIngredientsId, setExpandedIngredientsId] = useState<string | null>(null)
  const [cooking, setCooking] = useState<{ recipeId: string; stepIndex: number } | null>(null)
  const [secondsLeft, setSecondsLeft] = useState(0)
  const soonItems = items.filter((item) => item.status === 'soon')
  const fridgeNames = new Set(items.map((item) => item.name.toLowerCase()))
  const selectedNames = soonItems
    .filter((item) => selectedKeys.includes(foodKey(item)))
    .map((item) => item.name.toLowerCase())
  const urgency = (item: FoodItem) => item.days === 'today' ? 0 : Number.parseInt(item.days, 10) || 99
  const recipeScore = (recipe: Recipe) => {
    const matches = soonItems.filter((item) => recipe.ingredients.includes(item.name.toLowerCase()))
    return {
      count: matches.length,
      nearest: matches.length > 0 ? Math.min(...matches.map(urgency)) : 99,
    }
  }
  const visibleRecipes = recipes
    .filter((recipe) => selectedNames.every((name) => recipe.ingredients.includes(name)))
    .map((recipe, index) => ({ recipe, index, score: recipeScore(recipe) }))
    .sort((a, b) => b.score.count - a.score.count || a.score.nearest - b.score.nearest || a.index - b.index)
  const cookingRecipe = cooking ? recipes.find((recipe) => recipe.id === cooking.recipeId) ?? null : null
  const cookingStep = cookingRecipe && cooking ? cookingRecipe.steps[cooking.stepIndex] : null
  const cookingComplete = Boolean(cookingRecipe && cooking && cooking.stepIndex >= cookingRecipe.steps.length)

  const toggleChip = (item: FoodItem) => {
    const key = foodKey(item)
    setSelectedKeys((current) =>
      current.includes(key) ? current.filter((itemKey) => itemKey !== key) : [...current, key],
    )
  }

  const ingredientIcon = (ingredient: string) =>
    items.find((item) => item.name.toLowerCase() === ingredient)?.icon
    ?? knownFoods.find((food) => food.name === ingredient)?.icon

  useEffect(() => {
    setSecondsLeft((cookingStep?.timedMinutes ?? 0) * 60)
  }, [cooking?.recipeId, cooking?.stepIndex])

  useEffect(() => {
    if (!cookingStep?.timedMinutes || secondsLeft <= 0) return
    const timer = window.setInterval(() => setSecondsLeft((value) => Math.max(0, value - 1)), 1000)
    return () => window.clearInterval(timer)
  }, [cookingStep?.timedMinutes, secondsLeft > 0])

  const countdown = `${String(Math.floor(secondsLeft / 60)).padStart(2, '0')}:${String(secondsLeft % 60).padStart(2, '0')}`

  return (
    <main className="recipes-page">
      <section className="recipes-heading">
        <div>
          <p className="eyebrow">based on your fridge</p>
          <h1>what to cook.</h1>
        </div>
        <RecipeDrawing name="chef-leek" className="recipes-chef" />
      </section>

      {soonItems.length > 0 && (
        <div className="ingredient-chips" aria-label="Filter recipes by ingredients">
          {soonItems.map((item) => {
            const key = foodKey(item)
            const selected = selectedKeys.includes(key)
            return (
              <button
                type="button"
                key={key}
                className={selected ? 'is-selected' : ''}
                aria-pressed={selected}
                onClick={() => toggleChip(item)}
              >
                <FoodIcon name={item.name} icon={item.icon} className="ingredient-chip-art" />
                <span>{item.name}</span>
              </button>
            )
          })}
        </div>
      )}

      <section className="recipe-list" aria-label="Recipes">
        {visibleRecipes.map(({ recipe, score }) => {
          const expanded = expandedRecipeId === recipe.id
          return (
            <article className={`recipe-row ${expanded ? 'is-expanded' : ''}`} key={recipe.id}>
              <button
                type="button"
                className="recipe-summary"
                aria-expanded={expanded}
                onClick={() => setExpandedRecipeId(expanded ? null : recipe.id)}
              >
                <span className="recipe-thumbnail-slot">
                  <RecipeDrawing name={recipe.dish} className="recipe-thumbnail" />
                </span>
                <span className="recipe-copy">
                  <strong>{recipe.name}</strong>
                  <small className="desktop-recipe-ingredients">
                    <span>uses</span>
                    {recipe.ingredients.slice(0, 2).map((ingredient) => (
                      <span className="recipe-used-ingredient" key={ingredient}>
                        <FoodIcon name={ingredient} icon={ingredientIcon(ingredient)} className="recipe-used-icon" />
                        {ingredient}
                      </span>
                    ))}
                  </small>
                  <span className="mobile-recipe-line">
                    <RecipeDrawing name="timer" />
                    <b>{recipe.minutes} min</b>
                    <span className="mobile-used-ingredients">
                      · uses
                      {recipe.ingredients.slice(0, 2).map((ingredient) => (
                        <span className="recipe-used-ingredient" key={ingredient}>
                          <FoodIcon name={ingredient} icon={ingredientIcon(ingredient)} className="recipe-used-icon" />
                          {ingredient}
                        </span>
                      ))}
                    </span>
                  </span>
                </span>
                <span className="recipe-row-meta">
                  <span className="recipe-time"><RecipeDrawing name="timer" />{recipe.minutes} min</span>
                  <FixedTag className="recipe-expiring-tag">uses {score.count} expiring</FixedTag>
                </span>
                <span className="recipe-expand-mark" aria-hidden="true">{expanded ? '−' : '+'}</span>
              </button>
              <div className="recipe-details">
                <div className="recipe-meta-row">
                  <span><RecipeDrawing name="timer" />{recipe.minutes} min</span>
                  <span><RecipeDrawing name="flame" />{recipe.heat}</span>
                  <span>
                    <RecipeDrawing name="plate" />
                    <span className="desktop-servings">{recipe.servings} servings</span>
                    <span className="mobile-servings">{recipe.servings}</span>
                  </span>
                </div>
                <FixedTag className="recipe-mobile-expiring-tag">uses {score.count} expiring</FixedTag>
                <div className="recipe-ingredients">
                  <h2 className="desktop-ingredients-title">ingredients</h2>
                  <button
                    type="button"
                    className="mobile-ingredients-toggle"
                    aria-expanded={expandedIngredientsId === recipe.id}
                    onClick={() => setExpandedIngredientsId(expandedIngredientsId === recipe.id ? null : recipe.id)}
                  >
                    <span>ingredients {recipe.ingredients.length}</span>
                    <span>{expandedIngredientsId === recipe.id ? '−' : '+'}</span>
                  </button>
                  <ul className={expandedIngredientsId === recipe.id ? 'is-expanded' : ''}>
                    {recipe.ingredients.map((ingredient) => {
                      const icon = ingredientIcon(ingredient)
                      const hasIngredient = fridgeNames.has(ingredient)
                      return (
                        <li key={ingredient}>
                          <span className="recipe-ingredient-art">
                            <FoodIcon name={ingredient} icon={icon} />
                          </span>
                          <span>{ingredient}</span>
                          {hasIngredient ? <span className="ingredient-check" aria-label="In your fridge">✓</span> : <span className="need-tag">need</span>}
                        </li>
                      )
                    })}
                  </ul>
                </div>
                <div className="recipe-steps">
                  <h2>steps</h2>
                  <ol>
                    {recipe.steps.map((step, index) => (
                      <li key={step.phase}>
                        <span className="phase-icon">
                          <RecipeDrawing name={step.phase === 'prep' ? 'cutting-board' : step.phase === 'cook' ? recipe.cookTool : 'plate'} />
                        </span>
                        <span className="phase-copy">
                          <strong>{step.phase}</strong>
                          <span><b>{String(index + 1).padStart(2, '0')}</b>{step.text}</span>
                        </span>
                        {step.whisk && <RecipeDrawing name="whisk" className="step-whisk" />}
                      </li>
                    ))}
                  </ol>
                </div>
                <button type="button" className="start-cooking" onClick={() => setCooking({ recipeId: recipe.id, stepIndex: 0 })}>start cooking</button>
              </div>
            </article>
          )
        })}
        {visibleRecipes.length === 0 && (
          <div className="recipes-empty">
            <RecipeDrawing name="chef-leek" className="recipes-empty-chef" />
            <strong>nothing to match yet.</strong>
            <p>add items to your fridge to see recipes.</p>
          </div>
        )}
      </section>
      {cookingRecipe && cooking && (cookingStep || cookingComplete) && (
        <section className="cooking-takeover" role="dialog" aria-modal="true" aria-label={`Cooking ${cookingRecipe.name}`}>
          <div className="cooking-card">
            <div className="cooking-top-row">
              <button type="button" className="cooking-close" onClick={() => setCooking(null)}>← back</button>
              <span className="cooking-progress">{cookingComplete ? 'complete' : `step ${cooking.stepIndex + 1} of ${cookingRecipe.steps.length}`}</span>
              <span className="cooking-top-phase-icon">
                <RecipeDrawing name={cookingComplete ? 'plate' : cookingStep!.phase === 'prep' ? 'cutting-board' : cookingStep!.phase === 'cook' ? cookingRecipe.cookTool : 'plate'} />
              </span>
            </div>
            <span className="cooking-phase">{cookingComplete ? 'serve' : cookingStep!.phase}</span>
            <RecipeDrawing
              name={cookingComplete ? 'plate' : cookingStep!.timedMinutes ? 'timer' : cookingStep!.phase === 'prep' ? 'cutting-board' : cookingStep!.phase === 'cook' ? cookingRecipe.cookTool : 'plate'}
              className="cooking-step-art"
            />
            {!cookingComplete && cookingStep!.timedMinutes && <strong className="cooking-countdown">{countdown}</strong>}
            <h2>{cookingComplete ? 'enjoy!' : cookingStep!.text}</h2>
            <div className="cooking-actions">
              {cookingComplete ? (
                <button type="button" className="cooking-next cooking-done" onClick={() => setCooking(null)}>done</button>
              ) : (
                <>
                  <button
                    type="button"
                    disabled={cooking.stepIndex === 0}
                    onClick={() => setCooking({ ...cooking, stepIndex: cooking.stepIndex - 1 })}
                  >
                    ← previous
                  </button>
                  <button
                    type="button"
                    className="cooking-next"
                    onClick={() => setCooking({ ...cooking, stepIndex: cooking.stepIndex + 1 })}
                  >
                    next →
                  </button>
                </>
              )}
            </div>
          </div>
        </section>
      )}
    </main>
  )
}

function StatCircle({
  finalValue,
  decimals = 0,
  initialDelay,
  label,
  tooltip,
  positive = false,
}: {
  finalValue: number
  decimals?: number
  initialDelay: number
  label: string
  tooltip: string
  positive?: boolean
}) {
  const reduceMotionInitially = window.matchMedia('(prefers-reduced-motion: reduce)').matches
  const [displayValue, setDisplayValue] = useState(
    reduceMotionInitially ? finalValue.toFixed(decimals) : decimals ? '0.0' : '0',
  )
  const [draw, setDraw] = useState({ key: 0, duration: 0, delay: 0, active: false })
  const [showTooltip, setShowTooltip] = useState(false)
  const animationFrame = useRef<number | null>(null)
  const reducedMotion = useRef(reduceMotionInitially)

  const formatValue = (value: number) =>
    decimals ? value.toFixed(decimals) : String(Math.floor(value))

  const animate = (duration: number, delay: number) => {
    if (animationFrame.current !== null) cancelAnimationFrame(animationFrame.current)

    if (reducedMotion.current) {
      setDisplayValue(finalValue.toFixed(decimals))
      setDraw((current) => ({ ...current, active: false }))
      return
    }

    setDisplayValue(decimals ? '0.0' : '0')
    setDraw((current) => ({
      key: current.key + 1,
      duration,
      delay,
      active: true,
    }))

    const startsAt = performance.now() + delay
    const tick = (now: number) => {
      if (now < startsAt) {
        animationFrame.current = requestAnimationFrame(tick)
        return
      }

      const progress = Math.min((now - startsAt) / duration, 1)
      const eased = 1 - Math.pow(1 - progress, 3)
      setDisplayValue(progress === 1 ? finalValue.toFixed(decimals) : formatValue(finalValue * eased))

      if (progress < 1) {
        animationFrame.current = requestAnimationFrame(tick)
      } else {
        animationFrame.current = null
      }
    }

    animationFrame.current = requestAnimationFrame(tick)
  }

  useEffect(() => {
    animate(1400, initialDelay)
    return () => {
      if (animationFrame.current !== null) cancelAnimationFrame(animationFrame.current)
    }
  }, [])

  const replay = () => {
    animate(1000, 0)
    setShowTooltip(true)
  }

  return (
    <button
      className={`stat-circle ${positive ? 'positive' : ''}`}
      onMouseEnter={replay}
      onMouseLeave={() => setShowTooltip(false)}
      onClick={replay}
    >
      <span className="circle-art">
        <svg viewBox="0 0 300 300" aria-hidden="true">
          <path
            key={draw.key}
            className={`circle-stroke ${draw.active ? 'is-animating' : ''}`}
            style={{
              animationDuration: `${draw.duration}ms`,
              animationDelay: `${draw.delay}ms`,
            }}
            d="M153 12C224 9 283 65 288 137C294 211 239 278 165 287C91 296 24 247 13 174C2 101 48 33 119 16C133 12 145 11 158 13C166 14 171 16 177 20"
          />
        </svg>
        <strong>{displayValue}</strong>
      </span>
      <span className="stat-label">
        {label.split(' ').map((word, index) => (
          <span key={word}>
            {index > 0 && <br className="mobile-stat-break" />}
            {word}
            {index === 0 && <span className="desktop-stat-space"> </span>}
          </span>
        ))}
      </span>
      {showTooltip && <span className="stat-tooltip">{tooltip}</span>}
    </button>
  )
}

function StatsScreen({ rescued, wasted }: { rescued: number; wasted: number }) {
  const [statsLeek] = useState<'cool' | 'number-one'>(() =>
    Math.random() < 0.5 ? 'cool' : 'number-one',
  )
  const weeks = [
    ['this week', '9', '0.4'],
    ['last week', '11', '0.8'],
    ['oct 7–13', '8', '1.2'],
    ['sep 30–oct 6', '10', '1.8'],
  ]

  return (
    <main className="stats-page">
      <section className="compact-heading stats-heading">
        <div className="stats-leek-preview">
          <img
            className="stats-mascot"
            src={`/illustrations/mascot/new/${statsLeek}.png`}
            alt=""
            aria-hidden="true"
          />
        </div>
        <h1>your numbers.</h1>
      </section>
      <section className="stats-screen">
        <StatCircle
          finalValue={rescued}
          initialDelay={0}
          label="items rescued"
          tooltip="foods you finished before they expired"
          positive
        />
        <StatCircle
          finalValue={wasted}
          decimals={1}
          initialDelay={200}
          label="lbs wasted"
          tooltip="estimated food discarded this month"
        />
        <StatCircle
          finalValue={7}
          initialDelay={400}
          label="day streak"
          tooltip="days in a row with no expired food"
          positive
        />
      </section>
      <div className="thin-list week-list">
        <div className="thin-row list-labels">
          <span>week</span>
          <span>
            <span className="desktop-table-label">items rescued</span>
            <span className="mobile-table-label">rescued</span>
          </span>
          <span>
            <span className="desktop-table-label">lbs wasted</span>
            <span className="mobile-table-label">lbs</span>
          </span>
        </div>
        {weeks.map(([week, rescued, wasted]) => (
          <button className="thin-row" key={week}>
            <strong>{week}</strong>
            <span>{rescued}</span>
            <span>{wasted}<span className="desktop-unit"> lbs</span></span>
          </button>
        ))}
      </div>
    </main>
  )
}

function FriendsScreen() {
  const baseFriends = [
    ['01', 'maya', '0.2', '18'],
    ['02', 'you', '0.4', '12'],
    ['03', 'theo', '0.7', '9'],
    ['04', 'dev', '1.1', '6'],
    ['05', 'nina', '1.4', '4'],
  ]
  const [addFriendOpen, setAddFriendOpen] = useState(false)
  const [query, setQuery] = useState('')
  const [searchState, setSearchState] = useState<'idle' | 'searching' | 'match' | 'none' | 'friend' | 'requested' | 'self' | 'error'>('idle')
  const [selectedName, setSelectedName] = useState('')
  const [sentName, setSentName] = useState('')
  const [pendingFriends, setPendingFriends] = useState<string[]>([])
  const [incomingVisible, setIncomingVisible] = useState(true)
  const [copied, setCopied] = useState(false)
  const normalizedQuery = query.trim().toLowerCase()
  const canSend = normalizedQuery.length >= 3

  useEffect(() => {
    if (!addFriendOpen || sentName) return
    setSelectedName('')
    if (!normalizedQuery) {
      setSearchState('idle')
      return
    }
    if (normalizedQuery.length < 3) {
      setSearchState('searching')
      return
    }
    setSearchState('searching')
    const timer = window.setTimeout(() => {
      if (['you', 'you@freshy.app'].includes(normalizedQuery)) setSearchState('self')
      else if (['maya', 'dev', 'nina'].includes(normalizedQuery)) setSearchState('friend')
      else if (normalizedQuery === 'sam') setSearchState('requested')
      else if ('lena'.startsWith(normalizedQuery) || normalizedQuery === 'lena@freshy.app') setSearchState('match')
      else setSearchState('none')
    }, 400)
    return () => window.clearTimeout(timer)
  }, [addFriendOpen, normalizedQuery, sentName])

  const closeCard = () => {
    setAddFriendOpen(false)
    setQuery('')
    setSearchState('idle')
    setSelectedName('')
    setSentName('')
  }

  const copyInvite = async () => {
    try {
      await navigator.clipboard.writeText('https://freshy.app/invite/you')
      setCopied(true)
      window.setTimeout(() => setCopied(false), 2000)
    } catch {
      setSearchState('error')
    }
  }

  const shareInvite = async () => {
    if (navigator.share) {
      try {
        await navigator.share({ title: 'join me on freshy', url: 'https://freshy.app/invite/you' })
      } catch {
        return
      }
    } else {
      await copyInvite()
    }
  }

  const sendRequest = () => {
    if (!canSend) return
    if (normalizedQuery === 'offline') {
      setSearchState('error')
      return
    }
    if (searchState === 'self' || searchState === 'friend' || searchState === 'requested' || searchState === 'none') return
    const name = selectedName || normalizedQuery.split('@')[0]
    setPendingFriends((current) => current.includes(name) ? current : [...current, name])
    setSentName(name)
  }

  const friends = [
    ...baseFriends,
    ...pendingFriends.map((name, index) => [
      String(baseFriends.length + index + 1).padStart(2, '0'),
      name,
      '—',
      '—',
    ]),
  ]

  return (
    <main className="friends-page">
      <section className="compact-heading heading-with-action friends-heading">
        <img
          className="friends-header-art"
          src="/illustrations/mascot/new/friends.png"
          alt=""
          aria-hidden="true"
        />
        <div>
          <p className="eyebrow">this week</p>
          <h1>you + friends.</h1>
        </div>
        <button className="outline-button" onClick={() => setAddFriendOpen(true)}>+ add a friend</button>
      </section>
      <div className="friends-stage">
        {incomingVisible && (
          <div className="incoming-request">
            <span><strong>theo</strong> wants to be friends</span>
            <div>
              <button type="button" className="accept-request" onClick={() => setIncomingVisible(false)}>accept</button>
              <button type="button" onClick={() => setIncomingVisible(false)}>ignore</button>
            </div>
          </div>
        )}
        <div className="thin-list friends-list">
          <div className="thin-row list-labels friend-columns">
            <span>rank</span>
            <span>name</span>
            <span>
              <span className="desktop-table-label">lbs wasted</span>
              <span className="mobile-table-label">lbs</span>
            </span>
            <span>streak</span>
            <span>drawing</span>
          </div>
          {friends.map(([rank, name, wasted, streak]) => {
            const pending = pendingFriends.includes(name)
            return (
            <button className={`thin-row friend-columns ${name === 'you' ? 'is-you' : ''} ${pending ? 'is-pending' : ''}`} key={name}>
              <span>{rank}</span>
              <strong>{name}{pending && <small className="pending-tag">pending</small>}</strong>
              <span>{wasted}<span className="desktop-unit"> lbs</span></span>
              <span>{streak}<span className="desktop-unit"> days</span></span>
              <span className="friend-drawing" aria-label="Future custom drawing" />
            </button>
          )})}
        </div>
      </div>
      {addFriendOpen && (
        <div className="add-friend-overlay" role="presentation" onMouseDown={(event) => {
          if (event.target === event.currentTarget) closeCard()
        }}>
          <section className="add-friend-card" role="dialog" aria-modal="true" aria-labelledby="add-friend-title">
            {!sentName ? (
              <>
                <header>
                  <button type="button" onClick={closeCard}>← back</button>
                  <h2 id="add-friend-title">add a friend</h2>
                </header>
                <label className="friend-search-field">
                  <span>username or email</span>
                  <input
                    autoFocus
                    maxLength={40}
                    value={query}
                    placeholder="e.g. maya"
                    onChange={(event) => setQuery(event.target.value.slice(0, 40))}
                  />
                </label>
                <button type="button" className="send-friend-request" disabled={!canSend} onClick={sendRequest}>send request</button>
                <div className="friend-search-feedback" aria-live="polite">
                  {searchState === 'searching' && <p>searching...</p>}
                  {searchState === 'match' && (
                    <button type="button" className="friend-match-row" onClick={() => {
                      setQuery('lena')
                      setSelectedName('lena')
                    }}>
                      <span className="friend-result-drawing" aria-hidden="true" />
                      <span><strong>lena</strong><small>on freshy</small></span>
                    </button>
                  )}
                  {searchState === 'none' && <p>no one with that name. send an invite link instead.</p>}
                  {searchState === 'friend' && <p>already friends with {normalizedQuery}.</p>}
                  {searchState === 'requested' && <p>request sent to {normalizedQuery}.</p>}
                  {searchState === 'self' && <p>that's you!</p>}
                  {searchState === 'error' && <p>couldn't send. try again.</p>}
                </div>
                <div className="friend-or-divider"><span>or</span></div>
                <div className={`invite-actions ${searchState === 'none' ? 'is-highlighted' : ''}`}>
                  <button type="button" onClick={copyInvite}>{copied ? '✓ copied!' : 'copy invite link'}</button>
                  <button type="button" className="mobile-share-button" onClick={shareInvite}>share</button>
                </div>
              </>
            ) : (
              <div className="friend-request-success">
                <Leekly className="friend-success-leek" />
                <h2 id="add-friend-title">request sent.</h2>
                <p>we'll let you know when {sentName} accepts.</p>
                <button type="button" onClick={closeCard}>done</button>
              </div>
            )}
          </section>
        </div>
      )}
    </main>
  )
}

function SwipeTakeover({
  item,
  onDecision,
  onBack,
}: {
  item: FoodItem
  onDecision: (decision: 'used' | 'wasted' | 'extended') => void
  onBack: () => void
}) {
  const [step, setStep] = useState<1 | 2>(1)
  const [exit, setExit] = useState<'left' | 'right' | null>(null)
  const [entry, setEntry] = useState<'left' | 'right' | null>(null)
  const [closing, setClosing] = useState(false)
  const [visitedStepTwo, setVisitedStepTwo] = useState(false)
  const [dragX, setDragX] = useState(0)
  const [hasSwiped, setHasSwiped] = useState(false)
  const [stampDirection, setStampDirection] = useState<'left' | 'right' | null>(null)
  const dragStart = useRef<number | null>(null)
  const cardRef = useRef<HTMLDivElement>(null)

  const finish = (direction: 'left' | 'right') => {
    setDragX(0)
    setStampDirection(direction)
    setExit(direction)
    window.setTimeout(() => {
      if (step === 1 && direction === 'right') onDecision('used')
      else if (step === 1 && !item.extended) {
        setVisitedStepTwo(true)
        setStep(2)
        setExit(null)
        setEntry('right')
        setStampDirection(null)
      } else if (step === 2 && direction === 'right') onDecision('extended')
      else onDecision('wasted')
    }, 250)
  }

  const choose = (direction: 'left' | 'right') => {
    if (exit || stampDirection) return
    setStampDirection(direction)
    window.setTimeout(() => finish(direction), 300)
  }

  const goBack = () => {
    if (exit || closing) return
    if (step === 2) {
      setExit('right')
      window.setTimeout(() => {
        setStep(1)
        setExit(null)
        setEntry('left')
      }, 250)
    } else {
      setClosing(true)
      window.setTimeout(onBack, 200)
    }
  }

  useEffect(() => {
    const handleEscape = (event: KeyboardEvent) => {
      if (event.key === 'Escape') goBack()
    }
    window.addEventListener('keydown', handleEscape)
    return () => window.removeEventListener('keydown', handleEscape)
  })

  const release = (event: React.PointerEvent<HTMLDivElement>) => {
    if (dragStart.current === null) return
    const width = cardRef.current?.offsetWidth ?? 1
    if (Math.abs(dragX) >= width * 0.4) finish(dragX > 0 ? 'right' : 'left')
    else {
      setDragX(0)
      setStampDirection(null)
    }
    dragStart.current = null
    event.currentTarget.releasePointerCapture(event.pointerId)
  }

  const rotation = Math.max(-8, Math.min(8, (dragX / (cardRef.current?.offsetWidth || 1)) * 16))
  const cardWidth = cardRef.current?.offsetWidth || 1
  const stampOpacity = Math.min(Math.abs(dragX) / (cardWidth * 0.4), 1)

  return (
    <div className="swipe-takeover" role="dialog" aria-modal>
      <div
        key={step}
        ref={cardRef}
        className={`swipe-card swipe-card--step-${step} ${exit ? `swipe-${exit}` : ''} ${entry ? `swipe-enter-${entry}` : ''} ${closing ? 'swipe-close' : ''}`}
        style={!exit && !closing ? { transform: `translateX(${dragX}px) rotate(${rotation}deg)` } : undefined}
        onPointerDown={(event) => {
          dragStart.current = event.clientX - dragX
          event.currentTarget.setPointerCapture(event.pointerId)
        }}
        onPointerMove={(event) => {
          if (dragStart.current !== null) {
            const nextDrag = event.clientX - dragStart.current
            setDragX(nextDrag)
            if (Math.abs(nextDrag) > 8) setHasSwiped(true)
          }
        }}
        onPointerUp={release}
        onPointerCancel={release}
      >
        <button
          type="button"
          className="swipe-back"
          onPointerDown={(event) => event.stopPropagation()}
          onClick={goBack}
        >
          <span>←</span> back
        </button>
        <span className={`swipe-progress ${step === 1 && !visitedStepTwo ? 'is-hidden' : ''}`}>{step} of 2</span>
        <span
          className={`swipe-stamp swipe-stamp--left ${step === 2 ? '' : 'swipe-stamp--wasted'}`}
          style={{ opacity: stampDirection === 'left' ? 1 : dragX < 0 ? stampOpacity : 0 }}
        >
          {step === 2 ? 'toss' : 'wasted'}
        </span>
        <span
          className="swipe-stamp swipe-stamp--right"
          style={{ opacity: stampDirection === 'right' ? 1 : dragX > 0 ? stampOpacity : 0 }}
        >
          {step === 2 ? 'extended' : 'used'}
        </span>

        {step === 1 ? (
          <>
            <div className="swipe-food-panel expired-surface">
              <span className="swipe-status-meta"><StatusTag status="expired" /><span className="status-timing">{timingFromDays('expired', item.days)}</span></span>
              <p>{item.name}</p>
              <FoodIcon name={item.name} icon={item.icon} className="swipe-food-art" />
            </div>
            <h1>did you use it?</h1>
            <div className="swipe-actions">
              <button onClick={() => choose('left')}>← wasted</button>
              <button className="used-choice" onClick={() => choose('right')}>used →</button>
            </div>
            <small className={`mobile-swipe-hint ${hasSwiped ? 'is-hidden' : ''}`}>
              swipe left or right
            </small>
          </>
        ) : (
          <>
            <span className="swipe-kicker">one more check</span>
            <div className="spoil-food-column expired-surface">
              <span className="swipe-status-meta"><StatusTag status="expired" /><span className="status-timing">{timingFromDays('expired', item.days)}</span></span>
              <p className="spoil-food-name">{item.name}</p>
              <div className="spoil-food-art">
                <FoodIcon name={item.name} icon={item.icon} className="swipe-food-art swipe-food-art--check" />
              </div>
              <p className="spoil-expiry">{item.days === 'today' ? 'expired today' : `expired ${item.days} ago`}</p>
            </div>
            <div className="spoil-question-column">
              <h1>does it look spoiled?</h1>
              <div className="spoil-check-box">
                <strong>check</strong>
                <p>{item.senses}</p>
              </div>
              <p className="spoil-hint">our dates are cautious estimates. trust your eyes and nose.</p>
              <div className="swipe-actions">
                <button className="used-choice" onClick={() => choose('right')}>
                  <span className="swipe-label-desktop">no, 2 more days →</span>
                  <span className="swipe-label-mobile">2 more days →</span>
                </button>
                <button onClick={() => choose('left')}>
                  <span className="swipe-label-desktop">← yes, toss :(</span>
                  <span className="swipe-label-mobile">← toss it</span>
                </button>
              </div>
            </div>
          </>
        )}
      </div>
      <small className={hasSwiped ? 'is-hidden' : ''}>swipe left or right</small>
    </div>
  )
}

export default function App() {
  const [screen, setScreen] = useState<Screen>('fridge')
  const [items, setItems] = useState(foodItems)
  const [fridgeFilter, setFridgeFilter] = useState<FridgeFilter>('all')
  const [reviewItem, setReviewItem] = useState<FoodItem | null>(null)
  const [rescued, setRescued] = useState(12)
  const [wasted, setWasted] = useState(3.5)
  const [quietToast, setQuietToast] = useState<string | null>(null)
  const [highlightedItemIds, setHighlightedItemIds] = useState<string[]>([])
  const [addedItems, setAddedItems] = useState<FoodItem[]>([])
  const [pendingDecision, setPendingDecision] = useState<{
    decision: 'used' | 'wasted' | 'extended'
    item: FoodItem
  } | null>(null)
  const decisionTimer = useRef<number | null>(null)
  const addTimer = useRef<number | null>(null)

  useEffect(() => {
    setItems(foodItems)
  }, [])

  useEffect(() => {
    if (!Array.isArray(items)) setItems(foodItems)
  }, [items])

  useEffect(() => () => {
    if (decisionTimer.current !== null) window.clearTimeout(decisionTimer.current)
    if (addTimer.current !== null) window.clearTimeout(addTimer.current)
  }, [])

  const commitDecision = (decision: 'used' | 'wasted' | 'extended', item: FoodItem) => {
    if (decision === 'used') setRescued((value) => value + 1)
    if (decision === 'wasted') {
      setWasted((value) => Number((value + (item.wasteLbs ?? 0.4)).toFixed(1)))
    }
    setPendingDecision(null)
    decisionTimer.current = null
  }

  const queueDecision = (decision: 'used' | 'wasted' | 'extended') => {
    if (!reviewItem) return
    const decidedItem = reviewItem

    if (decision === 'extended') {
      setItems((current) =>
        (Array.isArray(current) ? current : foodItems)
          .map((item) =>
            foodKey(item) === foodKey(decidedItem)
              ? { ...item, status: 'soon' as const, days: '2 days', extended: true, deferred: false }
              : item,
          )
          .sort((a, b) => ['expired', 'soon', 'fresh'].indexOf(a.status) - ['expired', 'soon', 'fresh'].indexOf(b.status)),
      )
    } else {
      setItems((current) =>
        (Array.isArray(current) ? current : foodItems).filter((item) => foodKey(item) !== foodKey(decidedItem)),
      )
    }

    setReviewItem(null)
    setPendingDecision({ decision, item: decidedItem })
    if (decisionTimer.current !== null) window.clearTimeout(decisionTimer.current)
    decisionTimer.current = window.setTimeout(() => commitDecision(decision, decidedItem), 5000)
  }

  const undoDecision = () => {
    if (!pendingDecision) return
    if (decisionTimer.current !== null) window.clearTimeout(decisionTimer.current)
    setItems((current) => {
      const withoutDecision = (Array.isArray(current) ? current : foodItems).filter(
        (item) => foodKey(item) !== foodKey(pendingDecision.item),
      )
      return [pendingDecision.item, ...withoutDecision].sort(
        (a, b) => ['expired', 'soon', 'fresh'].indexOf(a.status) - ['expired', 'soon', 'fresh'].indexOf(b.status),
      )
    })
    setReviewItem(pendingDecision.item)
    setPendingDecision(null)
    decisionTimer.current = null
  }

  const addManualItems = (drafts: ManualItemInput[]) => {
    const today = new Date(`${todayISO()}T00:00:00`)
    const newItems = drafts.map((draft): FoodItem => {
      const bought = new Date(`${draft.boughtOn}T00:00:00`)
      const daysSinceBought = Math.max(0, Math.floor((today.getTime() - bought.getTime()) / 86400000))
      const remainingDays = draft.goodForDays - daysSinceBought
      const status: FoodStatus = remainingDays <= 0 ? 'expired' : remainingDays <= 2 ? 'soon' : 'fresh'
      return {
        ...draft,
        id: crypto.randomUUID(),
        days: remainingDays === 0 ? 'today' : `${Math.abs(remainingDays)} ${Math.abs(remainingDays) === 1 ? 'day' : 'days'}`,
        status,
      }
    })
    setItems((current) =>
      [...(Array.isArray(current) ? current : foodItems), ...newItems].sort(
        (a, b) => ['expired', 'soon', 'fresh'].indexOf(a.status) - ['expired', 'soon', 'fresh'].indexOf(b.status),
      ),
    )
    setFridgeFilter('all')
    setHighlightedItemIds(newItems.map(foodKey))
    window.setTimeout(() => setHighlightedItemIds([]), 300)
    setAddedItems(newItems)
    if (addTimer.current !== null) window.clearTimeout(addTimer.current)
    addTimer.current = window.setTimeout(() => {
      setAddedItems([])
      addTimer.current = null
    }, 3000)
    setScreen('fridge')
  }

  const undoAdd = () => {
    if (addedItems.length === 0) return
    if (addTimer.current !== null) window.clearTimeout(addTimer.current)
    const ids = new Set(addedItems.map(foodKey))
    setItems((current) => (Array.isArray(current) ? current : foodItems).filter((item) => !ids.has(foodKey(item))))
    setAddedItems([])
    setHighlightedItemIds([])
    addTimer.current = null
  }

  return (
    <div className="app-shell">
      <Header screen={screen} onNavigate={setScreen} />
      <div className="mobile-page-scroll">
        {screen === 'fridge' && (
          <FridgeScreen
            items={items}
            filter={fridgeFilter}
            highlightedItemIds={highlightedItemIds}
            onFilterChange={setFridgeFilter}
            onAddItem={() => setScreen('add')}
            onReviewExpired={setReviewItem}
          />
        )}
        {screen === 'recipes' && <RecipesScreen items={items} />}
        {screen === 'add' && <AddScreen onDone={() => setScreen('fridge')} onAddItem={addManualItems} />}
        {screen === 'stats' && <StatsScreen rescued={rescued} wasted={wasted} />}
        {screen === 'friends' && <FriendsScreen />}
        <div className="mobile-page-end-spacer" aria-hidden="true" />
      </div>
      {reviewItem && (
        <SwipeTakeover
          item={reviewItem}
          onDecision={queueDecision}
          onBack={() => {
            setItems((current) =>
              (Array.isArray(current) ? current : foodItems).map((item) =>
                foodKey(item) === foodKey(reviewItem) ? { ...item, deferred: true } : item,
              ),
            )
            setReviewItem(null)
            setQuietToast("no worries, we'll ask again later")
            window.setTimeout(() => setQuietToast(null), 2000)
          }}
        />
      )}
      {pendingDecision && (
        <button className="decision-toast" type="button" onClick={undoDecision}>
          {pendingDecision.decision === 'used'
            ? 'marked as used.'
            : pendingDecision.decision === 'wasted'
              ? 'tossed.'
              : 'extended 2 days.'}{' '}
          <u>undo</u>
        </button>
      )}
      {quietToast && <div className="extension-toast" role="status">{quietToast}</div>}
      {addedItems.length > 0 && (
        <button className="added-item-toast" type="button" onClick={undoAdd}>
          {addedItems.length === 1 ? `added ${addedItems[0].name}` : `added ${addedItems.length} items`} <u>undo</u>
        </button>
      )}
      <footer>
        <p>spoil less eat fresh!</p>
        <span>freshy © 2025</span>
      </footer>
    </div>
  )
}
