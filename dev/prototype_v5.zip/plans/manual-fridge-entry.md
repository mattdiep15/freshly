# Manual Fridge Entry and Add-Item Entry Points

## Goal

Add a consistent `+ add item` entry point from the fridge screen and a complete manual-entry path from the scan-receipt screen on desktop and mobile. Preserve the existing black/white visual system, `#258007` green actions, lowercase button typography with `0.04em` tracking, current hand-drawn artwork, filter behavior, mobile bottom-bar clearance, and receipt scanning flow.

## Confirmed Product Decisions

- Fridge additions remain in the app's existing React session state; no persistence or backend is introduced.
- Manual-item urgency is date-based:
  - `remainingDays = goodForDays - wholeDaysSinceBought`.
  - `remainingDays <= 0` → `expired`.
  - `remainingDays` of `1–2` → `soon`.
  - `remainingDays >= 3` → `fresh`.
  - The displayed `days` string uses `today` at zero, otherwise singular/plural `day(s)`.
  - `opened already?` is stored as metadata but does not silently change the user-visible estimate.
- Food-pile fullness is derived from the live inventory count:
  - `0–3` items → `10%`.
  - `4–6` items → `40%`.
  - `7–10` items → `70%`.
  - `11+` items → `100%`.
  - Add, undo, removal, and extension-related inventory changes update the derived stage immediately.
- The existing 10/40/70/100 controls can remain as a prototype preview override while the fridge screen is mounted, but any inventory mutation resets the displayed stage to the count-derived stage. This preserves the current control while making add/undo behavior deterministic.

## Data Model and Known-Food Catalog

### Extend `FoodItem`

Keep all existing fields and add optional manual-entry metadata:

- Stable `id` so duplicate food names can coexist and undo targets the exact item.
- `group`: `vegetables | fruit | protein | dairy-eggs | grains | other`.
- `quantity`: positive number.
- `unit`: `items | lbs | bag | carton | container`.
- `storage`: `fridge | freezer`.
- `boughtOn`: ISO date string (`YYYY-MM-DD`).
- `opened`: boolean.
- `goodForDays`: positive integer.
- Make `icon` optional so unknown foods can intentionally render a dashed placeholder instead of attempting a missing asset.
- Add a transient `highlighted` flag or keep a separate `highlightedItemId` in `App`; prefer separate UI state so presentation does not pollute inventory records.

Use item IDs rather than names for React keys, expand state, swipe-review targeting, filtering transitions, removal, and undo. Generate IDs client-side with `crypto.randomUUID()` and provide deterministic IDs for starter data.

### Create a typed known-food catalog

Define one catalog outside components and use it for autocomplete, defaults, preview artwork, storage guidance, and freshness checks:

| Food | Icon | Group | Default good-for | Default unit | Tip/check source |
|---|---|---|---:|---|---|
| eggs | `eggs` | dairy and eggs | 14 days | carton | existing/new egg guidance |
| greek yogurt | `greek-yogurt` | dairy and eggs | 7 days | container | standard yogurt storage/check guidance |
| strawberries | `strawberry` | fruit | 3 days | container | existing strawberry guidance |
| spinach | `spinach` | vegetables | 5 days | bag | existing spinach guidance |
| shrimp | `shrimp` | protein | 2 days | lbs | existing shrimp guidance |
| salmon | `fish` | protein | 2 days | lbs | existing salmon guidance |
| chicken thighs | `drumstick` | protein | 2 days | lbs | existing chicken guidance |
| bananas | `banana` | fruit | 5 days | items | existing banana guidance |
| avocado | `avocado` | fruit | 4 days | items | existing avocado guidance |
| oat milk | `milk-carton` | dairy and eggs | 7 days | carton | existing oat-milk guidance |
| leftover pasta | `pasta` | grains | 4 days | container | existing pasta guidance |
| bread | `bread` | grains | 5 days | bag | existing bread guidance |
| butter | `butter` | dairy and eggs | 14 days | container | existing butter guidance |
| broccoli | `broccoli` | vegetables | 6 days | items | existing broccoli guidance |

- Reuse the already-trimmed egg carton asset.
- Fetch the previously supplied yogurt attachment `03b32a8c-e9b8-4545-b6be-dfeb0d7f9fe5`, crop only surrounding whitespace to the linework, and save it as `public/illustrations/trimmed/greek-yogurt.png`; do not redraw, recolor, smooth, or otherwise alter it.
- Unknown food defaults:
  - group `other`
  - quantity `1`
  - unit `items`
  - storage `fridge`
  - bought today
  - opened `no`
  - good for `7 days`
  - no icon; render the existing dashed placeholder treatment
  - tip text uses the requested unknown-food guidance pattern, e.g. `try storing the stems in a jar of water.`

## App-Level State and Navigation

### Screen entry

- Keep the existing `Screen` route model.
- Add an `AddScreen` entry-mode prop controlled by `App`, e.g. `addEntry: 'options' | 'manual'`.
- Fridge `+ add item` sets `addEntry` to `options` and navigates to `add`.
- The existing camera tab also sets `addEntry` to `options`.
- `AddScreen` initializes/reset its local step from the entry mode whenever a new add session begins, avoiding stale receipt/manual state after returning from the fridge.
- The `+ add manually` action switches only the add screen's local mode to `manual`.
- Manual back/cancel returns to scan options and discards the draft.

### Save and undo

- `AddScreen` submits a normalized manual draft through `onAddItem(itemDraft)`.
- `App`:
  1. computes remaining days and status from the confirmed date rule,
  2. creates the `FoodItem`,
  3. inserts it into inventory,
  4. sorts with the existing urgency order (`expired`, `soon`, `fresh`) while preserving stable order within a status,
  5. sets the fridge filter to `all` so the new row is visible,
  6. stores the new ID in `highlightedItemId`,
  7. navigates to the fridge,
  8. shows an add toast for 3 seconds.
- Highlight the inserted row for 300ms with a subtle green rule/background treatment that does not recolor artwork.
- Add a dedicated add-toast state rather than overloading the existing waste/used decision toast:
  - text: `added {food name}`
  - 15px type
  - underlined `undo` action
  - 3-second timeout
- Undo removes the exact newly added ID, cancels the timeout, clears the toast/highlight, updates counts/filters/fullness, and leaves the user on the fridge.
- Ensure timer cleanup on unmount and when a later add replaces an active add toast.

## Fridge Screen

### Header row

- Refactor `fridge-count-title` into a full-width header row:
  - left cluster: current dynamic count label plus existing `clear` link when filtered,
  - right: `+ add item`.
- Keep filter tabs as the next row without changing their current desktop/mobile layout or sticky behavior.
- The add button remains visible for all filter selections.

### Add-button styling

- Shared lowercase button style: `font-size`, medium/regular weight, `letter-spacing: 0.04em`, no wrap.
- Desktop (`>=768px`):
  - 48px tall
  - 17px text
  - 28px horizontal padding
  - right aligned
- Mobile:
  - 44px tall
  - 15px text
  - 16px horizontal padding
  - count/clear cluster and button remain on one line; allow the left cluster to shrink, never the action label
- Solid `#258007`, white text.
- Active state uses `transform: scale(0.97)` with a 100ms transition.

### Row and pile updates

- Update `FoodCard` and swipe-review lookups to use `id`.
- Unknown items render the dashed placeholder in all artwork slots; known items use catalog artwork.
- Counts and filters continue deriving from the complete inventory.
- Derive the default pile stage from item count using the confirmed thresholds.
- Empty-state and desktop status bubble, if present, continue to use full-inventory counts, not filtered counts.

## Scan Options Screen

### Manual entry action

- Add `+ add manually` immediately after the two existing receipt cards.
- Desktop:
  - width equals the combined card grid, centered (use the grid container's actual width, not an unrelated fixed offset)
  - 56px tall
  - 24px top margin
- Mobile:
  - width fills the available page content with 16px page margins
  - 56px tall
  - 16px top margin
  - preserve the no-scroll scan-options screen
  - reduce receipt card/artwork height via a short-viewport media query only when needed
  - reserve at least `bottom bar zone + 52px` below the manual action
- Use solid green/white primary styling and the existing 17px lowercase, `0.04em` action text.

## Manual Entry Card

### Component structure

Create a focused `ManualEntryCard` component with a typed draft state and callbacks:

- `onBack()` / `onCancel()` discard draft and return to scan options.
- `onSubmit(draft)` emits only valid normalized data.
- Keep the draft local to the card so cancel/back cannot partially mutate inventory.

Suggested internal state:

```ts
type ManualItemDraft = {
  name: string
  catalogKey: string | null
  group: FoodGroup
  quantity: number
  unit: FoodUnit
  storage: StorageLocation
  boughtOn: string
  opened: boolean
  goodForDays: number
}
```

### Known-food matching and autocomplete

- Match catalog entries case-insensitively on trimmed input.
- Open a suggestion list as the user types; filter by substring, prioritize prefix matches, and preserve catalog order for ties.
- Keyboard support:
  - Arrow Up/Down changes active option.
  - Enter selects.
  - Escape closes.
  - Mouse/touch selection fills the draft.
- Selecting a known food fills icon, group, good-for days, default unit, tip, and check guidance.
- Continue allowing edits after selection.
- If the edited name no longer exactly matches the selected catalog food, clear `catalogKey`, switch preview to the dashed placeholder, and show the unknown-food tip.
- Close the dropdown on outside pointer-down and after selection.
- Use proper combobox/listbox roles and `aria-expanded`, `aria-controls`, `aria-activedescendant`.

### Desktop shell

- Render below the existing scan heading.
- Centered 560px width.
- 2px black border, 20px radius, 32px padding.
- Top row has back at left; title is below it with 28px display font.
- Preview is 96px at the top-right beside the title.
- Entire form remains in normal page flow.

### Mobile shell

- Use a fixed sheet inside the add-screen viewport:
  - left/right 16px
  - top `max(76px, env(safe-area-inset-top) + 20px)`
  - bottom `bottom bar zone + 52px`
  - 44px radius, 2px black border, white background, overflow hidden
- Header/back area and footer are fixed inside the sheet.
- Only the form body scrolls; hide its scrollbar using the project's mobile scrollbar rules.
- Add `scroll-padding` above and below, and on focus call `scrollIntoView({ block: 'nearest' })` after the keyboard/visual viewport changes so focused fields remain visible.
- Listen to `window.visualViewport` resize while the sheet is open and expose its height through a CSS variable if needed; remove listeners on cleanup.

### Header and preview

- Back control at top-left; it returns to options without saving.
- `add an item` uses 28px display font.
- 96px preview at top-right:
  - known item: exact hand-drawn catalog artwork with `object-fit: contain`
  - unknown/blank: dashed square
- Do not crop or recolor artwork in CSS.

### Fields

Use semantic labels and controls with 16px vertical field gaps:

1. **Food name**
   - 14px label
   - 52px input, 2px black border, 17px text
   - autocomplete behavior above
2. **Food group**
   - chips: vegetables, fruit, protein, dairy and eggs, grains, other
   - single-select; selected black/white, unselected white/black
   - known foods auto-select their catalog group
3. **Quantity**
   - number stepper with 44px minimum tap targets
   - unit select: items, lbs, bag, carton, container
   - clamp quantity to a positive practical range and permit typed decimal values for `lbs`
4. **Where it's stored**
   - two equal toggles: fridge/freezer
5. **Bought on**
   - native date input defaulting to local today
   - disallow future dates
6. **Opened already?**
   - two equal toggles: no/yes
7. **Good for**
   - reuse/extract the receipt-review stepper geometry so value text cannot be covered
   - singular/plural display
   - clamp 1–365
   - helper: `our estimate. change it if you know better.` at 13px

All text inputs and selects are 52px tall with 2px black outlines and 17px text. Avoid introducing a generic component library.

### Unknown-food tip

- Show only when the trimmed name is nonempty and has no exact catalog match.
- Reuse the straight mobile tip-card language and styling.
- Title `unknown food tip`, entered food name, and the fallback storage guidance.

### Footer actions

- Two equal columns, 12px gap, 56px high:
  - `cancel`: white, 2px black border
  - `add to fridge`: green/white
- Same lowercase 17px, `0.04em` action text.
- Desktop: normal bottom of card.
- Mobile: pinned flush to the sheet bottom, with outer corners created by the sheet's `overflow: hidden`, matching swipe-card footer behavior.
- Disable submit until:
  - trimmed name is nonempty,
  - `goodForDays` is a valid positive integer.
- Disabled submit stays visible at 40% opacity and is noninteractive.

## Styling and Responsive Constraints

- Scope all new mobile rules to `max-width: 767px` and desktop rules to `min-width: 768px`.
- Reuse `--ink`, `--paper`, and `--good`; do not hardcode a second green.
- Preserve existing fonts and imported artwork.
- Use the current app-level mobile scroller on option/fridge screens; manual form scrolling is intentionally isolated to the sheet body.
- No visible scrollbars.
- Maintain current fixed bottom navigation/camera stacking; the manual sheet and manual button must stop above the full zone.
- Do not modify existing fridge row dimensions, filter tab geometry, receipt-review rows, swipe cards, or desktop scan cards except where necessary to add the new actions.

## Implementation Sequence

1. Add IDs/manual metadata types and the known-food catalog.
2. Import and whitespace-trim the yogurt artwork asset.
3. Convert starter items and all inventory operations from name identity to ID identity.
4. Add app-level add-entry mode, add-item handler, highlight state, add toast, undo, and derived fullness helper.
5. Add the fridge header action and navigation wiring.
6. Add the scan-options manual action and responsive fit rules.
7. Implement `ManualEntryCard`, autocomplete, controls, validation, and unknown state.
8. Wire save/cancel/back and normalize draft into `FoodItem`.
9. Add desktop and mobile card/footer styling, safe-area handling, keyboard visibility behavior, and hidden-scrollbar form body.
10. Verify existing receipt, swipe, filter, undo, and navigation flows for regressions.

## Verification

### Automated/static

- Run `pnpm build`.
- Run `git diff --check`.
- Verify there are no missing-artwork network requests for every catalog food.
- Verify TypeScript catches exhaustive catalog/group/unit/storage mappings.

### Desktop checks (`>=768px`)

- Fridge header action is 48px tall, right-aligned, and remains visible under every filter.
- Filter tabs remain below and retain current behavior.
- Scan cards retain current sizing; manual action spans their combined width.
- Manual card is 560px, centered, nonoverlapping, and form controls match dimensions.
- Save inserts/sorts/highlights item; toast undo removes exact ID.

### Mobile checks

Test at least `390×844` and `360×640`, plus a keyboard-open state:

- Fridge header count/clear/add action stays on one line.
- Manual action fits on scan options without page scrolling or bottom-control overlap.
- Sheet clears safe area/island and bottom camera zone.
- Form body scrolls with no scrollbar; header/footer stay fixed.
- Focusing the lowest fields keeps them visible above the keyboard.
- Autocomplete works by touch and keyboard.
- Known selection updates preview/group/good-for defaults.
- Editing to unknown switches to placeholder and unknown tip.
- Stepper singular/plural and typed values are never clipped.
- Disabled/valid submit behavior is correct.
- Added row appears under `all`, in urgency order, with 300ms highlight.
- Toast remains visible above bottom controls for 3 seconds; undo removes the row and updates counts and pile stage.
- Last form field and footer never overlap the raised camera button.

### Regression checks

- Receipt photo/upload flow still reaches review and parsed-list steps.
- Existing add-to-fridge parsed receipt action still works.
- Swipe used/wasted/extend flow still targets the correct item after ID migration.
- Fridge filters, expansion, zero states, and sticky compact tabs still work.
- Desktop/mobile illustrations remain unchanged and are never recolored.
