# Fridge, Recipes, and Navigation Restructure

## Goal

Replace the old “me” destination with a Recipes page, move the useful “use soon” content into the bottom of the Fridge page, and rebuild desktop/mobile navigation in the requested order without changing the app’s established black/white visual language, `#258007` green rules, button typography, hand-drawn artwork, expired inversion, fridge grouping controls, or mobile camera-safe spacing.

## Confirmed Product Decisions

- Recipe ingredient chips are generated from **`soon` items only**. Expired items stay in the existing expired-review flow and do not become recipe-filter chips.
- Selecting multiple recipe chips uses **AND filtering**: a recipe must contain every selected ingredient.
- The add/scan workflow remains an internal `add` screen:
  - Desktop reaches it from the Fridge page’s existing green `+ add item` button.
  - Mobile retains the raised camera button and file input in the center nav slot.
- The recently restored fridge grouping/filter controls keep their existing dimensions, labels, counts, and small square markers. They are not converted to fixed status tags.

## Repository Facts and Scope

- The app is a single React/Vite implementation in `src/App.tsx`, with responsive styling in `src/index.css`.
- Navigation is controlled by local `Screen` state rather than a router.
- Fridge items already live at the `App` level and include `name`, `status`, `days`, `icon`, and stable `id`/name keys.
- The old `HomeScreen` contains the reusable heading, open-fridge Leekly, and three task-row visual pattern, but its tasks are hard-coded.
- `StatusTag` already supplies the fixed status-tag dimensions. Recipe urgency tags should share its base fixed-tag styling without changing the rule that food status tags contain only `expired`, `use soon`, or `fresh`.
- No test framework is configured. The prescribed broad verification command is `pnpm build`.
- Implementation should remain limited to `src/App.tsx` and `src/index.css`; no assets need to be redrawn, edited, or replaced.

## Implementation Plan

### 1. Reshape screen state and navigation

Update the screen model to:

```ts
type Screen = 'fridge' | 'recipes' | 'add' | 'stats' | 'friends'
```

- Remove `home` from the type, initial state, title map, render branches, and every navigation/reference.
- Initialize the app on `fridge`.
- Keep the brand/logo button pointing to `fridge`.
- Add `recipes` to the mobile page-title map.
- Keep `add` in the title map for the internal scan/manual workflow, but do not expose it as a desktop nav link.

Rebuild `Header` nav markup in this semantic order:

1. `fridge`
2. `recipes`
3. middle camera spacer/button
4. `stats`
5. `friends`

Desktop behavior:

- Hide the camera spacer, raised camera button, and camera file input from the visible desktop nav.
- Render the four text links in one row, 16px type, with 40px gaps.
- Keep the existing 2px active underline treatment, applying it to exactly one of the four destination links.
- On the internal `add` screen, no desktop destination is marked active.
- Remove all `scan receipt`, `scan`, and `me` nav markup and related active-state selectors.

Mobile behavior:

- Use an equal-width five-column bottom-bar grid.
- Place `fridge` and `recipes` in columns 1–2, an empty middle slot in column 3, and `stats` and `friends` in columns 4–5.
- Keep the raised camera button visually centered over column 3 and preserve the current camera input/event flow.
- Keep the existing fixed bottom bar, safe-area handling, focus states, and no-visible-scrollbar behavior.

### 2. Replace `HomeScreen` with a reusable fridge suggestions section

Delete `HomeScreen` and its navigation-only buttons/links. Introduce a focused component such as:

```ts
function UseSoonSuggestions({ items }: { items: FoodItem[] })
```

Data derivation:

- Filter `items` to `status === 'soon'`.
- Preserve the fridge’s existing urgency order and take at most the first three.
- Key checked state by `foodKey(item)`, not array index, so additions/removals/reordering do not attach completion state to the wrong food.
- If an item leaves `soon`, it naturally disappears from this section.

Task copy:

- Reuse the existing specific language for known demo foods:
  - chicken thighs: `cook chicken thighs` / `try with spinach tonight`
  - strawberries: `snack on strawberries` / `before tomorrow morning`
  - spinach: `use up spinach` / `toss into dinner`
- Add sensible known-food copy for current/demo soon items such as salmon.
- Use a deterministic fallback for newly added foods: `use up {name}` with a timing hint based on `item.days` (for example, `within 2 days`).
- Reuse each item’s existing `icon`; never transform or redraw the source asset.

Section placement and content:

- Render after the complete fridge list stage (including its desktop status gutter), inside `FridgeScreen`.
- Add a 1px top divider and then 48px top spacing on desktop / 32px on mobile.
- Generate the date label from the current local date with `Intl.DateTimeFormat` rather than retaining the stale hard-coded October date.
- Preserve:
  - heading `use soon.`
  - subtitle `three small things to save today.`
  - existing task row structure: number, checkbox, food artwork, title, hint
- Desktop heading is 56px; mobile heading is 40px.
- Use the existing open-fridge Leekly (`scene` variant), approximately 320px wide on desktop at the right of the heading and approximately 280px wide centered on mobile.
- Remove the old green circular add button, `go back to fridge`, and `everything in my fridge →`.
- When no `soon` items exist, replace the task list with the standalone Leekly at the established empty-state scale and the exact message `nothing to save today.`
- Keep the existing app-level mobile end spacer after the page so the section clears the raised camera button and bottom bar.

### 3. Add recipe data and a Recipes page

Define a local `Recipe` type and static recipe catalog near the other app data:

```ts
type Recipe = {
  id: string
  name: string
  ingredients: string[]
  minutes: number
  steps: string[]
}
```

Add these five recipes with complete ingredient and short step lists:

- chicken and spinach pasta
- strawberry yogurt bowl
- garlic spinach omelette
- salmon rice bowl
- banana oat pancakes

Use canonical lowercase ingredient names matching fridge names (`strawberries`, `spinach`, `salmon`, `bananas`, `chicken thighs`) so matching does not depend on display-string heuristics.

Create:

```ts
function RecipesScreen({ items }: { items: FoodItem[] })
```

Pass the live `items` state from `App`, ensuring manual additions, extensions, removals, and expired-review outcomes immediately affect chips, sorting, and urgency counts.

### 4. Build recipe header and ingredient chips

Header:

- Small wide-spaced label: `based on your fridge`, 14px.
- Heading: `what to cook.`, 56px desktop / 40px mobile.
- Left align both breakpoints.

Chip source and behavior:

- Generate one chip per live `soon` fridge item.
- Use `foodKey(item)` for selection identity and retain the item name for recipe matching.
- Each chip is 36px tall with a 1px outline and contains:
  - existing hand-drawn food artwork at 24px
  - lowercase item name
- Use `aria-pressed` and a selected class.
- Tapping toggles selection.
- Multiple selected chips require every selected ingredient to appear in a recipe.
- Allow chips to wrap naturally on both breakpoints; do not add a horizontal scrollbar.
- If there are no `soon` items, omit the chip row while still showing the full recipe catalog sorted with zero urgency scores.

### 5. Sort, filter, and render recipe rows

Derive, rather than store, the visible recipes:

1. Filter by all selected ingredient names.
2. For each recipe, calculate which live `soon` items it uses.
3. Sort descending by number of matched soon items.
4. Break ties using nearest remaining time:
   - parse `today` as most urgent, then numeric day strings
   - retain original catalog order as the final stable tie-breaker

Recipe list:

- Use thin stacked rows with 1px dividers.
- Collapsed row minimum height: approximately 88px desktop / 72px mobile.
- Left: dashed 56px square placeholder for future recipe artwork.
- Center:
  - recipe name at 24px desktop / 19px mobile
  - detail line at 14px and black at 70%, e.g. `uses chicken thighs, spinach · 25 min`
- Right: a fixed-size neutral urgency tag reading `uses {N} expiring`.
  - Extract a reusable fixed-tag base component/style from the existing `StatusTag`.
  - Keep `StatusTag` itself constrained to the three food-status labels.
  - Recipe tags share the fixed dimensions/corner/typography style but do not affect fridge grouping/filter buttons.
- Include an explicit `+`/`−` affordance consistent with fridge-row expansion.
- Make the row summary a button with `aria-expanded`.

Expansion:

- Track one `expandedRecipeId`; selecting a different recipe closes the previous one.
- Tapping the open recipe closes it.
- Expand in place below the summary, using the same max-height/opacity/divider transition pattern as fridge rows.
- Show two clearly labeled sections:
  - `ingredients`: the complete ingredient list
  - `steps`: numbered short steps
- Preserve reduced-motion behavior by disabling expansion transitions under the existing reduced-motion media query.

Empty filtering state:

- If selected chips produce no matches, show the standalone Leekly at about 120px and exact text `nothing to match yet.`
- Keep the selected chips visible so the user can remove filters.

### 6. Responsive styling and cleanup

Desktop:

- Add authoritative desktop nav styles for the four-link, 40px-gap layout.
- Lay out the fridge suggestion heading/art as a two-column composition while keeping task rows full-width below.
- Keep recipe rows aligned in stable placeholder/content/tag/control columns.

Mobile:

- Preserve the current mobile app-shell ownership of vertical scrolling.
- Do not introduce nested page scrolling for Fridge or Recipes.
- Keep scrollbar hiding on the app shell/page surfaces.
- Ensure long recipe names/details truncate or wrap inside the content column without moving the 56px placeholder or expand control.
- Add bottom padding/end spacing so the final recipe row clears the raised camera button by at least 40px and the Fridge suggestions section retains the existing camera-safe padding.
- Keep the current manual-entry and scan-screen special overflow rules intact.

CSS cleanup:

- Remove obsolete `.nav-me`, `.nav-scan`, `.home-screen`, home navigation button, and quiet-link rules when no longer referenced.
- Reuse the old task visuals under a suggestions-specific class or carefully shared task classes.
- Because `src/index.css` contains several historical responsive overrides, place final destination-specific rules in one authoritative section and remove conflicting obsolete selectors rather than stacking contradictory overrides.
- Do not modify:
  - mobile fridge row geometry/status strips
  - expired inversion/filtering
  - restored fridge grouping/filter button sizes and markers
  - illustration filters or source files
  - green `#258007` rules
  - lowercase, `0.04em` button typography

## Data Flow Summary

- `App.items` remains the single source of truth.
- `FridgeScreen` receives `items` and passes them to `UseSoonSuggestions`.
- `RecipesScreen` receives the same `items`.
- Suggestions derive the first three `soon` items.
- Recipe chips derive all `soon` items.
- Recipe urgency counts and sorting derive from those same `soon` items.
- Adding, extending, using, or wasting food updates `App.items`; both sections rerender without duplicate state synchronization.
- Only UI state remains local:
  - checked suggestion IDs
  - selected recipe-chip IDs
  - expanded recipe ID

## Edge Cases

- No soon items:
  - Fridge suggestions show standalone Leekly and `nothing to save today.`
  - Recipes show all demo recipes, no chips, and zero-expiring tags.
- Selected ingredients with no common recipe: show the recipe empty state while leaving chips interactive.
- Duplicate food names: chip selection uses `foodKey`, while recipe matching normalizes names; duplicate-name chips can be toggled independently but map to the same recipe ingredient.
- Missing food icon: render the existing placeholder treatment inside the 24px chip artwork slot.
- Item status changes while selected: if it leaves `soon`, remove its now-invalid chip key from effective filtering by deriving active selections against the current chip set.
- Add screen on desktop: remains reachable from `+ add item`; no desktop nav item is active.
- Add screen on mobile: camera capture remains reachable from the raised center button; manual flow remains reachable from the Fridge add button.
- Long ingredient/recipe text must not shift fixed row columns or create horizontal page scrolling.

## Verification

Run:

```sh
pnpm build
```

Then verify in the existing preview at representative widths below and above 768px:

### Navigation

- Desktop shows exactly `fridge`, `recipes`, `stats`, `friends`, in that order, with 40px gaps and a 2px active underline.
- Desktop has no visible scan or me link.
- Mobile has two labels on each side of the centered camera slot in the requested order.
- Camera capture still opens on mobile.
- Logo always returns to Fridge.
- No `me`, `home`, or obsolete scan-nav reference remains in rendered UI or screen branching.

### Fridge suggestions

- Section appears below the full fridge list with the correct divider and spacing.
- It shows at most three live `soon` items and updates after item additions/status changes.
- Checkbox completion remains attached to the correct item after list changes.
- Empty state appears when no soon items remain.
- No removed old-home buttons or links appear.
- Mobile artwork is centered and the last content clears the camera/bar.

### Recipes

- Chips come only from `soon` items.
- Chip artwork remains unchanged and is 24px.
- Multiple selected chips use AND matching.
- Sorting prioritizes recipes using more/nearer soon items.
- Only one recipe expands at a time; ingredients and steps are readable at both breakpoints.
- Urgency tags use the shared fixed tag geometry without changing fridge grouping controls.
- Empty match state works.
- Last row clears the mobile camera by at least 40px.

### Regression checks

- Fridge add/scan/manual-entry flow still works.
- Fridge filters retain their original sizes and small status markers.
- Mobile fridge row spacing, strips, fixed icon slots, and expired inversion are unchanged.
- Stats, Friends, add-friend flow, swipe review, toasts, and bottom safe-area spacing still render.
- Mobile pages have no visible scrollbar or horizontal overflow.
- Existing illustrations are referenced from the same files and are not edited.
