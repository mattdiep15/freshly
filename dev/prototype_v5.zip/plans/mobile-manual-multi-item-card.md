# Mobile Manual Entry Card: Full-Card Scrolling, Group Preview, and Multiple Items

## Goal

Fix the mobile (`<768px`) manual “add an item” experience so:

- The card begins below the visible logo-row divider and the back control is fully visible at scroll position zero.
- The preview sits at the far right of the item header rather than drifting toward the center.
- Known foods use their exact drawing; unknown foods use a representative drawing from the selected food group.
- The entire card—including back/title, all item sections, `+ add another item`, and cancel/save actions—scrolls as one surface.
- Users can add multiple manual items in one card and save them together.
- Desktop behavior and layout remain unchanged.

## Confirmed Interaction Decisions

- **Preview behavior:** exact known-food artwork wins. If no exact known food is selected, the preview uses a group fallback:
  - vegetables → broccoli
  - fruit → banana
  - protein → drumstick/chicken
  - dairy and eggs → eggs
  - grains → bread
  - other or no group → dashed placeholder
- **Multiple items:** `+ add another item` appends another complete blank manual-entry section inside the same card.
- **Scrolling:** the whole card is one scroll container. Header and action buttons are not pinned; the actions appear at the true bottom after all item sections and the add-another row.

## Root Cause to Address

The stylesheet currently contains multiple manual-entry mobile blocks in different positions. The compact rules appear before older rules with equal or greater specificity, so later legacy declarations override:

- card `top`/`bottom`
- fixed header/footer behavior
- preview positioning and size
- body-only scrolling
- padding and flex sizing

Do not add another isolated override on top. Consolidate the manual-entry styles:

1. Keep one shared desktop/base block.
2. Remove or neutralize superseded mobile declarations.
3. Place one authoritative mobile manual-entry block after the base rules.

This is required to make the layout stable instead of dependent on source-order accidents.

## Component and State Refactor

### Extract a reusable draft type

Create a UI draft type separate from `ManualItemInput`:

```ts
type ManualItemDraft = {
  draftId: string
  name: string
  selectedFoodName: string | null
  group: FoodGroup | null
  quantity: number
  unit: FoodUnit
  storage: StorageLocation
  boughtOn: string
  opened: boolean
  goodForDays: number
  showMoreDetails: boolean
}
```

Create `createEmptyManualDraft()` with current defaults:

- blank name
- no selected known food
- no group
- quantity `1`
- unit `items`
- storage `fridge`
- bought on local today
- opened `false`
- good for `7`
- details collapsed
- unique `draftId` via `crypto.randomUUID()`

### Refactor `ManualEntryCard`

Replace scalar form state with:

```ts
const [drafts, setDrafts] = useState<ManualItemDraft[]>([createEmptyManualDraft()])
```

The card owns:

- append draft
- remove draft
- update draft fields
- validate all drafts
- submit all drafts

Change the submit callback from:

```ts
onSubmit(item: ManualItemInput)
```

to:

```ts
onSubmit(items: ManualItemInput[])
```

Normalize every valid draft to `ManualItemInput` at submit time, using catalog tip/senses/icon for exact known foods and fallback guidance for unknown foods.

### Extract `ManualItemSection`

Create a focused child component for one item:

- controlled `draft`
- `index`
- `canRemove`
- `onChange(nextDraft)`
- `onRemove()`

Local-only UI state that should remain inside each section:

- autocomplete open/closed
- active suggestion index

The section renders:

1. Section header with title and preview.
2. Food name/autocomplete.
3. Group chips.
4. Quantity/unit.
5. Good-for.
6. More-details disclosure.
7. Optional storage/opened/date details.
8. Unknown tip when applicable.

For section one, title remains `add an item`. For later sections, use `item 2`, `item 3`, etc., in the same display type. Sections after the first get a small underlined `remove` action; the first cannot be removed.

## Card Position and Scroll Ownership

### Stop positioning from the viewport top

The logo row is already a sibling above `.mobile-page-scroll`. Use that layout relationship instead of hardcoding a viewport `top` value.

When the manual card is open on mobile:

- Keep the app shell at `100dvh` and prevent outer scrolling.
- Keep the topbar as the first flex child.
- Make `.mobile-page-scroll:has(.manual-entry-card)` the remaining flex area beneath the divider:
  - `flex: 1 1 auto`
  - `min-height: 0`
  - `overflow: hidden`
  - no generic bottom spacer/padding for this screen
  - reserve the fixed nav zone with an appropriate bottom margin
- Make `.add-screen:has(.manual-entry-card)` a `position: relative` container filling that remaining area.
- Position the card absolutely inside this container:
  - `top: 12px`
  - `left/right: 0` because the app wrapper already provides 16px side padding
  - `bottom: 52px` above the mobile page area's bottom-bar boundary

This guarantees the card begins exactly 12px below the actual rendered divider regardless of safe area, device, or logo-row height.

### Make the card the only scroller

Mobile `.manual-entry-card`:

- `overflow-x: hidden`
- `overflow-y: auto`
- `scrollbar-width: none`
- `-ms-overflow-style: none`
- hidden WebKit scrollbar
- `overscroll-behavior: contain`
- `-webkit-overflow-scrolling: touch`
- retain 44px radius, 2px border, and white background

Remove scrolling from `.manual-entry-body`; set it to `overflow: visible`.

The following all live in normal card flow and scroll together:

- back control
- each item title/preview
- all fields and details
- `+ add another item`
- cancel/add actions

Use `scroll-padding-top` and `scroll-padding-bottom` plus the existing focus `scrollIntoView({block: 'nearest'})` behavior so keyboard-focused fields remain visible.

## Header and Preview Layout

For each `ManualItemSection` on mobile:

- Section header is a full-width grid:
  - text column: `minmax(0, 1fr)`
  - preview column: `56px`
  - 16px gap
- Back appears above the first title, with at least 16px padding from the card top.
- Preview is explicitly in the second grid column and aligned to the right edge.
- Preview remains 56×56 on mobile.
- Known artwork uses `object-fit: contain` and is never recolored/cropped.
- Placeholder remains a 1px dashed square.
- Additional item headers omit the global back button and include their remove action in the text column.

This replaces absolute positioning and prevents the square from drifting toward the center.

## Preview Resolution

Add:

```ts
const groupFallbackIcons: Partial<Record<FoodGroup, string>> = {
  vegetables: 'broccoli',
  fruit: 'banana',
  protein: 'drumstick',
  'dairy-eggs': 'eggs',
  grains: 'bread',
}
```

Resolve preview icon in this order:

1. Exact selected catalog food icon.
2. Group fallback icon.
3. Dashed placeholder.

When food-name text no longer exactly matches the selected catalog item:

- clear `selectedFoodName`
- preserve the user-selected group
- immediately switch preview to the group fallback

When the user selects a group for an unknown food, update the preview immediately.

When a known food is selected:

- set exact name
- set selected catalog identity
- set catalog group/defaults
- show the exact food artwork instead of the generic group icon

## Multiple Item Flow

### Add-another row

After all current item sections and before the final actions, add a full-width row:

- label: `+ add another item`
- 56px minimum height
- 2px black top/bottom or full outline consistent with the card
- white background, black text
- 17px lowercase action style with `0.04em` tracking
- active state scales or darkens for 100ms

Behavior:

- Enabled only when the last draft has a nonempty food name and valid positive good-for value.
- If disabled, keep visible at 40% opacity and provide `aria-disabled`.
- On activation:
  1. append `createEmptyManualDraft()`
  2. wait for render
  3. scroll the new section header/name field into view
  4. focus its food-name input

### Removing added sections

- Sections after the first have a `remove` link.
- Removing a section does not affect the others.
- Focus moves to the preceding section's add-another row or name field.

### Final validation and save

- Bottom `add to fridge` remains disabled unless every draft has:
  - nonempty trimmed name
  - valid positive `goodForDays`
- Submit all drafts as one array.
- Preserve existing button text `add to fridge`; optionally show `add 2 items to fridge` only if desired later—do not change it in this task.

## App-Level Batch Save and Undo

Change `addManualItem` to `addManualItems(drafts)`:

1. Normalize each input using the existing date-based urgency calculation.
2. Generate one unique item ID per draft.
3. Append all items in one state update.
4. Sort once using urgency order.
5. Set filter to `all`.
6. Highlight every inserted ID for 300ms (change `highlightedItemId` to a `Set<string>` or array).
7. Navigate to fridge once.
8. Show:
   - `added eggs` for one item
   - `added 3 items` for multiple
9. Undo removes all IDs from that batch in one state update and updates fullness/counts once.

Represent the toast payload as a batch:

```ts
type AddedBatch = {
  items: FoodItem[]
  ids: string[]
}
```

Keep the existing 3-second timeout and cleanup.

## Mobile Action Row

Because the whole card scrolls:

- Remove `position: absolute`/pinned behavior from `.manual-entry-actions`.
- Keep the action row as the final card child after `+ add another item`.
- Keep two equal buttons and the attached-footer look:
  - 2px top divider
  - no outside gap
  - card overflow creates the bottom 44px curve
  - cancel white/black
  - add green/white
- The card's bottom padding must not create white space below the actions.
- At scroll end, the action row is completely visible above the reserved bottom zone.

## Desktop Preservation

All behavior/layout changes in this task are mobile-only except the internal batch-capable state model.

Desktop:

- Keep current centered 560px card.
- Keep current expanded field presentation.
- Keep current preview sizing and placement.
- Do not change desktop scroll behavior or action placement.
- Multiple item support may appear functionally on desktop because it shares state, but do not alter desktop geometry beyond rendering additional sections and the add-another row in normal flow.

If strict visual parity requires it, scope the additional-section separators and row styling so they blend with the existing desktop card without changing the first section.

## CSS Cleanup

Consolidate these selectors rather than leaving conflicting copies:

- `.add-screen:has(.manual-entry-card)`
- `.manual-entry-card`
- `.manual-entry-header`
- `.manual-title-row`
- `.manual-preview`
- `.manual-entry-body`
- `.manual-entry-actions`

Remove obsolete mobile declarations for:

- fixed viewport `top`
- body-only scrolling
- fixed/pinned action footer
- absolute preview positioning
- stale 96/116px header dimensions

Leave one authoritative mobile media block after the base manual-entry styles.

## Accessibility

- Keep autocomplete combobox/listbox roles per item with unique IDs derived from `draftId`.
- Give each preview meaningful hidden context through the food-name label; artwork remains decorative.
- Add `aria-label` to remove buttons (`Remove item 2`) and add-another.
- On append, announce `Item 2 added` through a polite live region.
- Preserve 44px minimum tap targets.
- Ensure disabled add-another/save controls expose native `disabled` where possible.

## Verification

### Static

- Run `pnpm build`.
- Run `git diff --check`.
- Confirm no duplicated active mobile manual-entry rules remain after cleanup.

### Mobile visual checks

Test at `390×844` and `360×640`:

- At card scroll position zero:
  - full back button visible
  - card begins 12px below logo divider
  - title visible
  - 56px preview aligned to the right edge
- Card bottom remains above the raised camera/bottom bar zone.
- Whole card scrolls; no inner body scroller and no visible scrollbar.
- Action row is reached at the true card bottom and is not pinned.
- Keyboard focus keeps active inputs visible.

### Preview checks

- Selecting `eggs` shows exact egg artwork and dairy/eggs group.
- Selecting `protein` with an unknown name shows chicken/drumstick fallback.
- Selecting `fruit` changes unknown preview to banana immediately.
- Selecting `other` restores dashed placeholder.
- Editing a known name into a nonmatch switches from exact icon to group fallback.

### Multi-item checks

- Add-another is disabled for an invalid last section.
- A valid first section can append item 2.
- Newly appended section scrolls/focuses into view.
- Item 2 can use different autocomplete/group/defaults independently.
- Removing item 2 preserves item 1.
- Saving two items inserts both once, sorts once, updates counts/fullness, and shows one batch toast.
- Undo removes both batch items.
- Cancel/back discards the entire draft array.

### Regression checks

- Desktop first-item card remains visually unchanged.
- Receipt photo/upload flow still works.
- Fridge filters and `+ add item` entry still work.
- Single-item save/toast/undo still work.
- Existing artwork is not altered or recolored.
